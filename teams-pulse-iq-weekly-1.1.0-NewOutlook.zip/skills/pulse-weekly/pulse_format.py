"""Shared formatting for the two renderings of the same measured day.

The dashboard and the mail draw the same indicators with the same grammar, so
the rules that decide what a figure looks like live here rather than being
written twice and drifting apart: how a value is printed, what counts sit behind
it, where its bar stops, and which colour its movement takes.

Nothing in this module measures anything. It reads `kpis.json` entries as the
assembler produced them.
"""
import re

LEVEL_RANK = {'poor': 0, 'watch': 1, 'unrated': 2, 'good': 3}
LEVEL_NOTE = {'good': 'within target', 'watch': 'approaching target',
              'poor': 'outside target', 'unrated': 'no published target'}

# Colours. The base is the level against target; the second colour is the
# distance travelled since the comparison day, red when it worsened and green when it
# recovered.
BASE = {'good': '#2da44e', 'watch': '#d4a72c', 'poor': '#cf222e',
        'unrated': '#b6bec7'}
DELTA = {'worse': '#cf222e', 'better': '#96d8a8'}
TRACK = '#eceef1'

# Short names for the tiles, where a full label would wrap twice.
SHORT_LABEL = {
    'feedback.rating': 'User rating', 'feedback.poor': 'One-star',
    'psr.audio': 'Audio', 'psr.video': 'Video', 'psr.vbss': 'Sharing',
    'clf.inbound': 'Inbound issues', 'clf.uplink': 'Outbound issues',
    'setup': 'Setup failure', 'drop': 'Dropped',
    'net.rtt': 'Latency', 'net.jitter': 'Jitter', 'net.loss': 'Packet loss',
    'transport.tcp': 'TCP fallback',
    'wifi.psr24': '2.4 GHz audio', 'wifi.share24': '2.4 GHz usage',
    'vdi.optimized': 'VDI optimised', 'clients.current': 'Clients current',
}


def period_label(value):
    """A period as the outputs print it.

    The daily run stores a single date; the weekly one stored a pair. Both are
    accepted so an older `kpis.json` still renders, and a pair that collapses to
    one day prints as one day.
    """
    if isinstance(value, str):
        return value
    if isinstance(value, (list, tuple)) and value:
        first, last = value[0], value[-1]
        return str(first) if first == last else f"{first} → {last}"
    return ''


def esc(text):
    return (str(text).replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;').replace('"', '&quot;'))


def fmt_value(kpi, value):
    if value is None:
        return '—'
    unit = kpi['unit']
    if unit == 'percent':
        return f"{value:.2f} %"
    if unit == 'ms':
        return f"{value:.0f} ms"
    if unit == 'rating':
        return f"{value:.2f} / 5"
    return fmt_count(value)


def fmt_delta(kpi):
    if kpi['delta'] is None:
        return ''
    unit = {'percent': ' pt', 'ms': ' ms', 'rating': ''}.get(kpi['unit'], '')
    sign = '+' if kpi['delta'] >= 0 else '−'
    return f"{sign}{abs(kpi['delta']):.2f}{unit}"


def fmt_count(value):
    return '—' if value is None else f"{value:,.0f}".replace(',', ' ')


def n(value):
    """A count that will not be split across two lines by its thousands space."""
    return fmt_count(value).replace(' ', '\u00a0')


def label_of(kpi):
    return SHORT_LABEL.get(kpi['key'], kpi['label'])


def arrow_mark(kpi):
    """Which way the value went, or nothing when it held steady.

    The arrow states the movement, never the judgement: a rate that rises always
    points up, and the colour beside it says whether that is bad.
    """
    if kpi['verdict'] not in ('worse', 'better'):
        return ''
    return '↑' if (kpi['delta'] or 0) > 0 else '↓'


def moved(kpi):
    """Worth reporting: it changed, or it is not sitting within target."""
    return (kpi['attention'] or kpi['verdict'] in ('worse', 'better')
            or kpi['level'] in ('poor', 'watch'))


def counts_phrase(kpi):
    """The absolute figures behind a rate, as a reader would say them.

    A share on its own hides its own weight: 2.34% to 3.77% sounds serious until
    you read it as 34 ratings becoming 71.
    """
    counts = kpi.get('counts')
    if not counts or not counts.get('now'):
        return kpi.get('detail') or ''
    now, before, noun = counts['now'], counts.get('before'), counts['noun']
    if now['n'] is None:
        text = f"{n(now['d'])} {noun}"
        if before and before['d'] != now['d']:
            text += f", was {n(before['d'])}"
        return text
    text = f"{n(now['n'])} of {n(now['d'])} {noun}"
    if before and before['n'] is not None and before['n'] != now['n']:
        text += f", was {n(before['n'])}"
    return text


def target_value(kpi):
    if not kpi.get('target'):
        return None
    try:
        return float(kpi['target'].rsplit(' ', 1)[1])
    except (ValueError, IndexError):
        return None


def target_note(kpi):
    return kpi['target'].replace('target ', '') if kpi.get('target') \
        else LEVEL_NOTE['unrated']


def bar_parts(kpi):
    """How to draw the bar, as percentages of its track, or None for no bar.

    The scale differs by direction on purpose, and every tile prints its own
    reference underneath:

    - lower is better: the track is the published target, so the bar reads as
      headroom. Audio at 0.33% against a 2% bar should look comfortable.
    - higher is better: the track is the whole scale (100%, or 5 for a rating)
      with a marker at the target, because a share of 93% has to look like 93%.
    - no published target: no bar at all. A drawn bar implies a scale, and
      inventing one is the thing this report refuses to do everywhere else.

    Returns (value_pct, movement_pct, target_marker_pct or None).
    """
    now, before = kpi['now'], kpi['before']
    if now is None or kpi['level'] == 'unrated':
        return None
    target = target_value(kpi)

    if kpi['direction'] == 'higher':
        scale = 5.0 if kpi['unit'] == 'rating' else 100.0
        mark = None if target is None else 100.0 * target / scale
    else:
        scale = max(target or 0.0, now, before or 0.0) or 1.0
        mark = None

    low = now if before is None else min(now, before)
    high = now if before is None else max(now, before)
    low_pct = max(0.0, min(100.0, 100.0 * low / scale))
    delta_pct = max(0.0, min(100.0 - low_pct, 100.0 * (high - low) / scale))
    return low_pct, delta_pct, mark


def delta_colour(kpi):
    return DELTA.get(kpi['verdict'], '#c9d1d9')


def sort_key(kpi):
    """Attention first, then what moved, then how far from target."""
    return (not kpi['attention'], not moved(kpi), LEVEL_RANK[kpi['level']],
            -abs(kpi['relative'] or 0))


# "568 of 42,973", in any of the separators a written sentence may use.
_QUOTED_PAIR = re.compile(r'([\d][\d,.\s\u00a0\u202f]*)\s+of\s+([\d][\d,.\s\u00a0\u202f]*)')
_QUOTED_RATE = re.compile(r'(\d+(?:\.\d+)?)\s*%')


def _count(text):
    digits = re.sub(r'[^\d]', '', text)
    return int(digits) if digits else None


def _add_pair_and_complement(pairs, num_val, den_val):
    if num_val is None or den_val is None:
        return
    n_int, d_int = round(num_val), round(den_val)
    if d_int <= 0:
        return
    pairs.add((n_int, d_int))
    if 0 <= n_int <= d_int:
        pairs.add((d_int - n_int, d_int))


def _collect_pairs(data):
    pairs = set()
    for kpi in data.get('kpis', []):
        counts = kpi.get('counts') or {}
        for side in ('now', 'before'):
            part = counts.get(side) or {}
            if part.get('d') is not None:
                if part.get('n') is not None:
                    _add_pair_and_complement(pairs, part['n'], part['d'])
                else:
                    # e.g. 5.00 / 5 across 35 ratings -> "35 of 35 ratings"
                    pairs.add((round(part['d']), round(part['d'])))

    modalities = ((data.get('headline') or {}).get('modalities')) or {}
    for mod in modalities.values():
        if not isinstance(mod, dict):
            continue
        for way in ('inbound', 'outbound'):
            way_obj = mod.get(way)
            if not isinstance(way_obj, dict):
                continue
            candidates = [way_obj] + [way_obj.get(s) for s in ('overall', 'wired', 'wifi')]
            for cand in candidates:
                if not isinstance(cand, dict):
                    continue
                counts = cand.get('counts') or {}
                for side in ('now', 'before'):
                    part = counts.get(side) or {}
                    _add_pair_and_complement(pairs, part.get('n'), part.get('d'))

    for sub in ((data.get('audio_subnets') or {}).get('detailed')) or []:
        _add_pair_and_complement(pairs, sub.get('poor'), sub.get('eligible'))
        _add_pair_and_complement(pairs, sub.get('poor'), sub.get('streams'))
        _add_pair_and_complement(pairs, sub.get('before_poor'), sub.get('before_eligible'))
        _add_pair_and_complement(pairs, sub.get('before_poor'), sub.get('before_streams'))
    return pairs


# Rate immediately preceding a parenthetical/clause count pair, not a signed or relative ("by X%") delta.
_LOCAL_RATE = re.compile(r'(?<!by )(?<![+\-\u2212\d.])(\d+(?:\.\d+)?)\s*%\s*\(?[\w\s,]{0,18}$', re.I)


def narrative_problems(data, narrative):
    """Written statements whose own figures contradict each other.

    Each quoted `N of M` pair is checked against all measured populations in
    `data` (including good/complement counts such as `35 of 35` five-star
    ratings, per-modality directions/connections, and current/prior subnets)
    and against any unsigned rate quoted immediately before that pair.

    Returns a list of (section, index, reason).
    """
    pairs = _collect_pairs(data)

    problems = []
    analysis = narrative.get('analysis') or {}
    for section in ('negative', 'positive'):
        for index, text in enumerate(analysis.get(section) or []):
            if not isinstance(text, str):
                continue
            for match in _QUOTED_PAIR.finditer(text):
                num, den = _count(match.group(1)), _count(match.group(2))
                if num is None or not den:
                    continue
                if (num, den) not in pairs:
                    problems.append((section, index,
                                     f'{num} of {den} is not a measured pair'))
                    continue
                prefix = text[max(0, match.start() - 36):match.start()]
                # Ignore rates separated by sentence/clause boundaries
                clause = re.split(r'[;:]|,\s+(?=[A-Za-z])', prefix)[-1]
                rate_match = _LOCAL_RATE.search(clause)
                if not rate_match:
                    continue
                rate_str = rate_match.group(1)
                claimed = float(rate_str)
                actual = 100.0 * num / den
                decimals = len(rate_str.split('.')[1]) if '.' in rate_str else 0
                tol = 0.55 if decimals == 0 else (0.06 if decimals == 1 else 0.015)
                if abs(claimed - actual) > tol:
                    problems.append(
                        (section, index,
                         f'{num} of {den} is {actual:.2f}%, but the sentence '
                         f'says {claimed:.2f}% — the counts belong to another '
                         f'indicator'))
    return problems


def sound_analysis(data, narrative):
    """The narrative with contradicted statements removed, and what was dropped.

    A wrong attribution is worse than a missing sentence: the measured tiles
    stay right either way, but a reader acts on the prose.
    """
    problems = narrative_problems(data, narrative)
    if not problems:
        return narrative, []
    dropped = {(section, index) for section, index, _ in problems}
    clean = dict(narrative)
    analysis = dict(narrative.get('analysis') or {})
    for section in ('negative', 'positive'):
        entries = analysis.get(section) or []
        analysis[section] = [text for index, text in enumerate(entries)
                             if (section, index) not in dropped]
    clean['analysis'] = analysis
    return clean, [reason for _, _, reason in problems]
