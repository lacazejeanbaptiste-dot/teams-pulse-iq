"""Assemble dashboard-data.json from raw query results — deterministic mapping.

Cowork's job stops at collection: it executes the register and writes every
result verbatim into raw_results.json. This script performs the whole mapping,
so the 85 metric slots, the ratios, the units, the populations and the fourteen
extension families are produced by tested code instead of hand transcription.

Nothing here invents a measurement. A slot with no matching row keeps
`value: null` and a reason naming the query that should have supplied it.

    python assemble_dashboard.py [--raw working/raw_results.json]
                                 [--out dashboard-data.json]

Expected raw_results.json shape:
    {"periods": {"current": ["YYYY-MM-DD","YYYY-MM-DD"], "previous": [...]},
     "focus_site": {"S": "<building>", "S1": "<building>"},
     "results": {"Q1_S": {"rows": [ {...}, ... ]}, ...}}

Row keys are exactly what the model returns, for example "CQD[Session Type]"
and "[Streams]".

"dax" is optional and only recorded when the executed text differs from the
register: otherwise the exact DAX is rebuilt from weekly-register.md, so the
evidence register and the investigation batches never carry an empty query.
"focus_site" is omitted when Q14 names no building; the site sections are then
closed as unsupported with a Building File recommendation, not left unfinished.
"""
import argparse
import collections
import json
import re
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

PERIOD_TAG = {"current": "S", "previous": "S1"}

# Client cohort -> the exact Second User Agent Category returned by the model.
CLIENTS = {
    "teams21windows": ["Microsoft Teams 2.1 Windows"],
    "teams21web": ["Microsoft Teams 2.1 Web"],
    "teamsrooms": ["Microsoft Teams Room 2.1 (Windows)", "Microsoft Teams Room (Android)"],
    "android": ["Microsoft Teams Android"],
    "ios": ["Microsoft Teams iOS"],
    "citrixvdi": ["Microsoft Teams Citrix VDI"],
}

# Classifier -> the (True, False, Null) aliases emitted by measure block @M3.
CLASSIFIERS = {
    "inbound_network": ("InT", "InF", "InN"),
    "uplink": ("UpT", "UpF", "UpN"),
    "media_modality": ("MoT", "MoF", "MoN"),
    "local_compute": ("LcT", "LcF", "LcN"),
    "local_input_device": ("LdT", "LdF", "LdN"),
    "compute_device_causing": ("CdT", "CdF", "CdN"),
    "input_device_causing": ("IdT", "IdF", "IdN"),
    "other_user_uplink": ("OuT", "OuF", "OuN"),
    "other_user_compute": ("OcT", "OcF", "OcN"),
    "other_user_device": ("OdT", "OdF", "OdN"),
}
AUDIO_ONLY = {"local_input_device", "input_device_causing", "other_user_device"}
CONF_ONLY = {"other_user_uplink", "other_user_compute", "other_user_device"}

MEDIA_GOOD = {"Audio": "AGood", "Video": "VGood", "VBSS": "SGood"}
MEDIA_POOR = {"Audio": "APoor", "Video": "VPoor", "VBSS": "SPoor"}

FAMILIES = ["reliability", "sites", "media-quality", "network-subnets", "transport",
            "wifi-bands", "compute-models", "clients", "vdi", "p2p-pairs",
            "regional-routing", "direction-comparison", "vpn", "frame-rates",
            "wifi-radio", "qos", "peripherals", "user-feedback"]

EXTENSIONS = ["sites", "clients", "vdi", "p2p-pairs", "regional-routing",
              "direction-comparison", "vpn", "frame-rates", "wifi-radio", "qos",
              "peripherals", "user-feedback", "reliability-inside", "media-classifiers"]


# ---------------------------------------------------------------- small helpers
_PERCENT_TEXT = re.compile(r"^\s*(-?[\d\s,.\u00a0\u202f]+?)\s*%\s*$")
_GROUPED = re.compile(r"^-?\d{1,3}(?:[,\s\u00a0\u202f]\d{3})+$")
_PLAIN = re.compile(r"^-?\d+(?:[.,]\d+)?$")


def _parse_number(text):
    cleaned = text.strip().replace("\u00a0", " ").replace("\u202f", " ")
    if not cleaned:
        return None
    if _GROUPED.match(cleaned):
        return int(re.sub(r"[,\s]", "", cleaned))
    compact = cleaned.replace(" ", "")
    if _PLAIN.match(compact):
        val = float(compact.replace(",", "."))
        return int(val) if val.is_integer() and "." not in compact and "," not in compact else val
    return None


def num(row, alias):
    """Measure value from a result row, or None.

    A rate may arrive as the string the report displays, such as "4%", and a
    count may arrive grouped as "15,411". Both are converted back to numbers.
    """
    value = row.get("[" + alias + "]")
    if value is None:
        value = row.get(alias)
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, str):
        match = _PERCENT_TEXT.match(value)
        if match:
            parsed = _parse_number(match.group(1))
            return None if parsed is None else float(parsed) / 100.0
        return _parse_number(value)
    return None


def dim(row, column):
    value = row.get("CQD[" + column + "]")
    if value is None:
        value = row.get("CQD " + column)
    if value is None:
        value = row.get(column)
    if value is None:
        return None
    text = str(value).strip()
    # A blank grouping value means "not reported"; keep it null rather than "".
    return text or None


def total(rows, alias):
    values = [num(r, alias) for r in rows]
    known = [v for v in values if v is not None]
    return sum(known) if known else None


def _normalize_col(col):
    if not isinstance(col, str):
        return col
    if col.startswith("CQD ") and not col.startswith("CQD["):
        return f"CQD[{col[4:]}]"
    if not col.startswith(("CQD[", "'CQD'[", "[")):
        return f"[{col}]"
    return col


def _normalize_cell(col, val):
    if not isinstance(val, str) or col.startswith(("CQD[", "'CQD'[")):
        return val
    parsed = _parse_number(val)
    return parsed if parsed is not None else val


def expand_results(results):
    """Accept either result shape, and work on the verbose one internally.

    A query result may arrive as a list of objects, or in the tabular shape
    `{"cols": [...], "rows": [[...], ...]}`. The tabular shape exists because
    repeating a column name such as `CQD[Second Reflexive Local IP Network]` on
    every row costs about three quarters of what an agent has to transcribe,
    for no added information. Both shapes carry exactly the same values.
    """
    expanded = {}
    for key, entry in (results or {}).items():
        if not isinstance(entry, dict):
            continue
        entry = dict(entry)
        rows = entry.get("rows")
        cols = entry.get("cols")
        if cols is not None:
            if not isinstance(cols, list) or not all(isinstance(c, str) for c in cols):
                raise SystemExit(f"{key}: cols must be a list of column names")
            norm_cols = [_normalize_col(c) for c in cols]
            widened = []
            for index, row in enumerate(rows or []):
                if not isinstance(row, list):
                    raise SystemExit(f"{key}: tabular rows must be arrays, row {index} is not")
                if len(row) != len(norm_cols):
                    raise SystemExit(f"{key}: row {index} has {len(row)} values "
                                     f"for {len(norm_cols)} columns")
                widened.append({c: _normalize_cell(c, v) for c, v in zip(norm_cols, row)})
            entry["rows"] = widened
            entry.pop("cols", None)
        elif isinstance(rows, list):
            entry["rows"] = [
                {_normalize_col(k): _normalize_cell(_normalize_col(k), v) for k, v in row.items()}
                if isinstance(row, dict) else row
                for row in rows
            ]
        expanded[key] = entry
    return expanded


def ratio(numerator, denominator, scale=100.0):
    if numerator is None or not denominator:
        return None
    return numerator / denominator * scale


def is_rfc1918(subnet):
    """True for the private 10/8 and 172.16/12 ranges a Building File maps.

    192.168/16 is left out on purpose: weekly-register.md treats it as a home
    network that is expected Outside.
    """
    parts = str(subnet or "").strip().split(".")
    if len(parts) < 2:
        return False
    if parts[0] == "10":
        return True
    return parts[0] == "172" and parts[1].isdigit() and 16 <= int(parts[1]) <= 31


# ------------------------------------------------------------ register expansion
# weekly-register.md defines every executed query literally. When a raw result
# carries no "dax" of its own, the exact text is rebuilt from it, so collection
# never has to echo the DAX back into raw_results.json.
_SUBSTITUTION = re.compile(r"^- `(@\w+)` \u2192 `(.+)`$", re.M)
_MEASURE_BLOCK = re.compile(r"^`(@\w+)` \(.*\)\n```\n(.+)\n```$", re.M)
_TEMPLATE = re.compile(r"^`(T\d)` \u2014 .*\n```dax\n(.+)\n```$", re.M)
_REGISTER_ROW = re.compile(r"^\| (Q\d+) \| (.+) \|$", re.M)
_TPL_CELL = re.compile(r"^(T\d)(?:\s+N=(\d+))?$")
_MACRO = re.compile(r"@\w+")
_FOCUS_MARKER = '"<focus site from Q14>"'
_PLACEHOLDERS = ("<GROUP>", "<FILTERS>", "<MEASURES>", "<N>", "<ORDER>")
_EMPTY_CELLS = {"", "-", "\u2013", "\u2014"}


def _weekly_register_path():
    here = Path(__file__).resolve().parent
    for candidate in (here / "weekly-register.md",
                      here.parent / "references" / "weekly-register.md",
                      Path("weekly-register.md")):
        if candidate.is_file():
            return candidate
    return None


def _cell(text):
    return text.strip().replace("`", "")


def parse_weekly_register(text):
    """Substitutions, measure blocks, templates and query rows, read literally."""
    text = text.replace("\r\n", "\n")
    macros = dict(_SUBSTITUTION.findall(text))
    macros.update(_MEASURE_BLOCK.findall(text))
    queries = {}
    for qid, body in _REGISTER_ROW.findall(text):
        cells = body.split(" | ")
        if len(cells) != 4:
            raise ValueError(f"{qid}: expected 4 register cells, found {len(cells)}")
        template = _TPL_CELL.match(cells[0].strip())
        if not template:
            raise ValueError(f"{qid}: unknown template cell {cells[0]!r}")
        measures, _, order = cells[3].partition(" \u2014 ORDER ")
        filters = cells[2].strip()
        queries[qid] = {
            "template": template.group(1), "n": template.group(2),
            "group": _cell(cells[1]),
            "filters": None if filters in _EMPTY_CELLS else _cell(filters),
            "measures": _cell(measures), "order": _cell(order) or None,
        }
    return {"macros": macros, "templates": dict(_TEMPLATE.findall(text)), "queries": queries}


_FALLBACK_REGISTER_TEXT = """
- `@D` \u2192 `TREATAS({"YYYY-MM-DD", ... 7 dates of the week being queried ...}, CQD[Date])`
- `@D14` \u2192 `TREATAS({... the 14 dates of S\u22121 and S ...}, CQD[Date])`
- `@T` \u2192 `FILTER(VALUES(CQD[Test Call Type]), CQD[Test Call Type] = "NonTest")`
- `@IN` \u2192 `FILTER(VALUES(CQD[Second Inside Corp]), CQD[Second Inside Corp] = "Inside")`

`@M1` (reliability counts)
```
"Streams",SUM(CQD[Total Stream Count]),"Calls",SUM(CQD[Total Call Count]),"CDR",SUM(CQD[Total CDR Available Stream Count]),"Failed",SUM(CQD[Total Call Setup Failed Stream Count]),"Established",SUM(CQD[Total Call Setup Succeeded Stream Count]),"Dropped",SUM(CQD[Total Call Dropped Stream Count])
```

`@M2` (media good/poor counts)
```
"AGood",SUM(CQD[Audio Good Stream Count]),"APoor",SUM(CQD[Audio Poor Stream Count]),"VGood",SUM(CQD[Video Good Stream Count]),"VPoor",SUM(CQD[Video Poor Stream Count]),"SGood",SUM(CQD[VBSS Good Stream Count]),"SPoor",SUM(CQD[VBSS Poor Stream Count])
```

`@M3` (the ten classifiers \u2014 True, False and Null counts \u2014 plus video freezes)
```
"InT",SUM(CQD[Detected Inbound Network Problem True Count]),"InF",SUM(CQD[Detected Inbound Network Problem False Count]),"InN",SUM(CQD[Detected Inbound Network Problem Null Count]),"UpT",SUM(CQD[Detected Uplink Problem True Count]),"UpF",SUM(CQD[Detected Uplink Problem False Count]),"UpN",SUM(CQD[Detected Uplink Problem Null Count]),"MoT",SUM(CQD[Detected Media Modality Problem True Count]),"MoF",SUM(CQD[Detected Media Modality Problem False Count]),"MoN",SUM(CQD[Detected Media Modality Problem Null Count]),"LcT",SUM(CQD[Detected Local Compute Problem True Count]),"LcF",SUM(CQD[Detected Local Compute Problem False Count]),"LcN",SUM(CQD[Detected Local Compute Problem Null Count]),"LdT",SUM(CQD[Detected Local Input Device Problem True Count]),"LdF",SUM(CQD[Detected Local Input Device Problem False Count]),"LdN",SUM(CQD[Detected Local Input Device Problem Null Count]),"CdT",SUM(CQD[Detected Compute Device Causing Problem True Count]),"CdF",SUM(CQD[Detected Compute Device Causing Problem False Count]),"CdN",SUM(CQD[Detected Compute Device Causing Problem Null Count]),"IdT",SUM(CQD[Detected Input Device Causing Problem True Count]),"IdF",SUM(CQD[Detected Input Device Causing Problem False Count]),"IdN",SUM(CQD[Detected Input Device Causing Problem Null Count]),"OuT",SUM(CQD[Detected Other User Uplink Problem True Count]),"OuF",SUM(CQD[Detected Other User Uplink Problem False Count]),"OuN",SUM(CQD[Detected Other User Uplink Problem Null Count]),"OcT",SUM(CQD[Detected Other User Compute Problem True Count]),"OcF",SUM(CQD[Detected Other User Compute Problem False Count]),"OcN",SUM(CQD[Detected Other User Compute Problem Null Count]),"OdT",SUM(CQD[Detected Other User Device Problem True Count]),"OdF",SUM(CQD[Detected Other User Device Problem False Count]),"OdN",SUM(CQD[Detected Other User Device Problem Null Count]),"Freeze",SUM(CQD[Video Poor Due to Freeze Count])
```

`@M4` (network values \u2014 pass-through, never re-aggregated)
```
"RTT",SUM(CQD[Avg Round Trip]),"RTTMax",SUM(CQD[Avg Round Trip Max]),"Jitter",SUM(CQD[Avg Jitter]),"JitterMax",SUM(CQD[Avg Jitter Max]),"Loss",SUM(CQD[Avg Packet Loss Rate]),"LossMax",SUM(CQD[Avg Packet Loss Rate Max])
```

`@M5` (endpoint compute \u2014 pass-through, never re-aggregated)
```
"SysCPU",SUM(CQD[Avg Second System CPU Resource Usage Average]),"ProcCPU",SUM(CQD[Avg Second Process CPU Resource Usage Average])
```

`@M6` (subnet investigation metrics \u2014 the aliases the investigation contract reads)
```
"Streams",SUM(CQD[Total Stream Count]),"CDR",SUM(CQD[Total CDR Available Stream Count]),"SetupFailed",SUM(CQD[Total Call Setup Failed Stream Count]),"Established",SUM(CQD[Total Call Setup Succeeded Stream Count]),"Dropped",SUM(CQD[Total Call Dropped Stream Count]),"JitterMs",SUM(CQD[Avg Jitter]),"JitterMaxAvgMs",SUM(CQD[Avg Jitter Max]),"PacketLoss",SUM(CQD[Avg Packet Loss Rate]),"PacketLossMaxAvg",SUM(CQD[Avg Packet Loss Rate Max]),"RoundTripMs",SUM(CQD[Avg Round Trip]),"RoundTripMaxAvgMs",SUM(CQD[Avg Round Trip Max])
```

`@M7` (compute-model investigation metrics)
```
"Streams",SUM(CQD[Total Stream Count]),"ComputeTrue",SUM(CQD[Detected Local Compute Problem True Count]),"ComputeFalse",SUM(CQD[Detected Local Compute Problem False Count]),"ComputeNull",SUM(CQD[Detected Local Compute Problem Null Count]),"SystemCpu",SUM(CQD[Avg Second System CPU Resource Usage Average]),"ProcessCpu",SUM(CQD[Avg Second Process CPU Resource Usage Average])
```

`@G1` (subnet investigation grouping \u2014 every dimension the contract reads)
```
CQD[Second Subnet], CQD[Second Reflexive Local IP Network], CQD[Second Building Name], CQD[Second Inside Corp], CQD[Second Network Connection Detail], CQD[Stream Direction], CQD[Second Transport Protocol], CQD[Second ASN Country]
```

`@F1` (media and scenario are both reported \u2014 never blank)
```
FILTER(VALUES(CQD[Media Type]), CQD[Media Type] IN {"Audio","Video","VBSS"}), FILTER(VALUES(CQD[Session Type]), CQD[Session Type] IN {"Conf","P2P"})
```

`@F2` (TCP family only \u2014 the transports the TCP concentration panel ranks)
```
FILTER(VALUES(CQD[Second Transport Protocol]), CQD[Second Transport Protocol] IN {"TCP","TLS","TurnTCP","MultiTurnTCP","CompoundTCP"})
```

`@F3` (everything that is not TCP family, blank transport included)
```
FILTER(VALUES(CQD[Second Transport Protocol]), NOT(CQD[Second Transport Protocol] IN {"TCP","TLS","TurnTCP","MultiTurnTCP","CompoundTCP"}))
```

`@F4` (Wi-Fi audio, a single reported band)
```
FILTER(VALUES(CQD[Second Network Connection Detail]), CQD[Second Network Connection Detail]="Wifi"), FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type] IN {"Conf","P2P"})
```

`T1` \u2014 grouped aggregate:
```dax
EVALUATE SUMMARIZECOLUMNS( <GROUP>, @D, @T, <FILTERS>, <MEASURES> )
```

`T2` \u2014 ranked aggregate (use the stated `N` and the full ordering clause):
```dax
EVALUATE TOPN( <N>, SUMMARIZECOLUMNS( <GROUP>, @D, @T, <FILTERS>, <MEASURES> ), <ORDER> )
```

| Q1 | T1 | `CQD[Session Type]` | \u2013 | `@M1` |
| Q2 | T1 | `CQD[Date]` | \u2013 | `@M1` |
| Q3 | T1 | `CQD[Date]` | `@IN` | `@M1` |
| Q4 | T1 | `CQD[Media Type], CQD[Session Type]` | \u2013 | `@M2, @M3` |
| Q5 | T1 | `CQD[Media Type], CQD[Session Type], CQD[Second Inside Corp], CQD[Second Network Connection Detail]` | \u2013 | `@M1, @M2` |
| Q6 | T1 | `CQD[Connectivity Ice Pair], CQD[Inside Corp Pair]` | `FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="P2P")` | `@M1, @M2` |
| Q7 | T1 | `CQD[Second User Agent Category], CQD[Session Type]` | \u2013 | `@M1, @M2, @M3, @M5` |
| Q8 | T1 | `CQD[Second Transport Protocol]` | \u2013 | `@M1` |
| Q9 | T1 | `CQD[Second Wifi Band], CQD[Second Wifi Radio Type], CQD[Session Type]` | `FILTER(VALUES(CQD[Second Network Connection Detail]), CQD[Second Network Connection Detail]="Wifi")` | `@M1, @M2, @M4` |
| Q10 | T1 | `CQD[Second Network Connection Detail], CQD[Stream Direction], CQD[Session Type]` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio")` | `@M4` |
| Q11 | T1 | `CQD[Second VPN Estimated], CQD[Second Network Mapped VPN]` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio")` | `@M1, @M2` |
| Q12 | T1 | `CQD[Second Client VDI Mode], CQD[Second Client VDI Is Optimized], CQD[Second Client VDI Provider Version]` | \u2013 | `@M1` |
| Q13 | T2 N=30 | `CQD[Second Client App Version Age], CQD[Second Client App Version]` | `FILTER(VALUES(CQD[Second User Agent Category]), CQD[Second User Agent Category]="Microsoft Teams 2.1 Windows")` | `@M1, @M2, "Users",SUM(CQD[Second User Count])` \u2014 ORDER `[Streams], DESC` |
| Q14 | T2 N=10 | `CQD[Second Building Name], CQD[Second Country]` | `@IN` | `@M1, @M2` \u2014 ORDER `[Streams], DESC` |
| Q15 | T1 | `CQD[Date]` | `@IN`, `FILTER(VALUES(CQD[Second Building Name]), CQD[Second Building Name]="<focus site from Q14>")` | `@M1` |
| Q16 | T1 | `CQD[CDR Response Reason], CQD[Second Inside Corp], CQD[Second Network Connection Detail]` | `FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="Conf")` | `@M1` |
| Q17 | T2 N=25 | `CQD[Second Subnet], CQD[Second Building Name], CQD[Second Network Connection Detail], CQD[Stream Direction]` | `@IN` | `@M1, @M2, @M4` \u2014 ORDER `[Dropped] + [APoor], DESC, [Streams], DESC` |
| Q18 | T2 N=30 | `CQD[Second Subnet], CQD[Second Inside Corp]` | `FILTER(VALUES(CQD[Second Inside Corp]), CQD[Second Inside Corp] <> "Inside")` | `"Streams",SUM(CQD[Total Stream Count]),"APoor",SUM(CQD[Audio Poor Stream Count])` \u2014 ORDER `[Streams], DESC, [APoor], DESC` |
| Q19 | T2 N=30 | `CQD[Second Building Name], CQD[First ASN Country], CQD[Second ASN Country]` | `FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="Conf")`, `FILTER(VALUES(CQD[Stream Direction]), CQD[Stream Direction]="First-to-Second")` | `@M1, @M4` \u2014 ORDER `[Streams], DESC` |
| Q20 | T1 | `CQD[Second Feedback Rating]` | \u2013 | `"RatingCount",SUM(CQD[Second Feedback Rating Count]),"PoorCount",SUM(CQD[Second Feedback Rating Poor Count])` |
| Q21 | T1 | `CQD[Media Type], CQD[Stream Direction]` | \u2013 | `"FrameRate",SUM(CQD[Avg Video Frame Rate]),"FrameLoss",SUM(CQD[Avg Video Local Frame Loss Percentage]),"Streams",SUM(CQD[Total Stream Count])` |
| Q22 | T1 | `CQD[Second QoS Applied], CQD[Second QoS Value], CQD[Stream Direction]` | \u2013 | `@M1` |
| Q23 | T2 N=20 | `CQD[Second Capture Dev Name], CQD[Second Capture Device Form Factor]` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio")` | `@M1, @M2` \u2014 ORDER `[APoor], DESC, [Streams], DESC` |
| Q24 | T1 | `CQD[Poor Reason], CQD[Session Type], CQD[Media Type]` | \u2013 | `@M1` |
| Q25 | T1 | `CQD[Media Failure Type], CQD[Session Type]` | \u2013 | `"Calls",SUM(CQD[Total Call Count])` |
| Q26 | T2 N=20 | `CQD[Second BSSID], CQD[Second Building Name]` | `FILTER(VALUES(CQD[Second Network Connection Detail]), CQD[Second Network Connection Detail]="Wifi")` | `@M1, @M2, "Roaming",SUM(CQD[Total Second Roaming Count])` \u2014 ORDER `[APoor], DESC, [Streams], DESC` |
| Q28 | T2 N=20 | `@G1` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="Conf"), @F3` | `@M6, "Good",SUM(CQD[Audio Good Stream Count]),"Poor",SUM(CQD[Audio Poor Stream Count])` \u2014 ORDER `[Streams], DESC, [Poor], DESC, CQD[Second Subnet], ASC, CQD[Second Reflexive Local IP Network], ASC, CQD[Stream Direction], ASC` |
| Q29 | T2 N=20 | `@G1` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="P2P"), @F3` | `@M6, "Good",SUM(CQD[Audio Good Stream Count]),"Poor",SUM(CQD[Audio Poor Stream Count])` \u2014 ORDER `[Streams], DESC, [Poor], DESC, CQD[Second Subnet], ASC, CQD[Second Reflexive Local IP Network], ASC, CQD[Stream Direction], ASC` |
| Q30 | T2 N=20 | `@G1` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Video"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="Conf"), @F3` | `@M6, "Good",SUM(CQD[Video Good Stream Count]),"Poor",SUM(CQD[Video Poor Stream Count])` \u2014 ORDER `[Streams], DESC, [Poor], DESC, CQD[Second Subnet], ASC, CQD[Second Reflexive Local IP Network], ASC, CQD[Stream Direction], ASC` |
| Q31 | T2 N=20 | `@G1` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Video"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="P2P"), @F3` | `@M6, "Good",SUM(CQD[Video Good Stream Count]),"Poor",SUM(CQD[Video Poor Stream Count])` \u2014 ORDER `[Streams], DESC, [Poor], DESC, CQD[Second Subnet], ASC, CQD[Second Reflexive Local IP Network], ASC, CQD[Stream Direction], ASC` |
| Q32 | T2 N=20 | `@G1` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="VBSS"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="Conf"), @F3` | `@M6, "Good",SUM(CQD[VBSS Good Stream Count]),"Poor",SUM(CQD[VBSS Poor Stream Count])` \u2014 ORDER `[Streams], DESC, [Poor], DESC, CQD[Second Subnet], ASC, CQD[Second Reflexive Local IP Network], ASC, CQD[Stream Direction], ASC` |
| Q33 | T2 N=20 | `@G1` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="VBSS"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="P2P"), @F3` | `@M6, "Good",SUM(CQD[VBSS Good Stream Count]),"Poor",SUM(CQD[VBSS Poor Stream Count])` \u2014 ORDER `[Streams], DESC, [Poor], DESC, CQD[Second Subnet], ASC, CQD[Second Reflexive Local IP Network], ASC, CQD[Stream Direction], ASC` |
| Q34 | T1 | `CQD[Media Type], CQD[Session Type], CQD[Second Transport Protocol]` | `@F1` | `"Streams",SUM(CQD[Total Stream Count])` |
| Q35 | T2 N=20 | `CQD[Second User Agent Category], CQD[Second Client App Version], CQD[Second Compute Device Name], CQD[Second CPU Name], CQD[Session Type], CQD[Media Type]` | `@F1` | `@M7` \u2014 ORDER `[ComputeTrue], DESC, [Streams], DESC` |
| Q36 | T2 N=20 | `CQD[Second Subnet], CQD[Second Building Name], CQD[Second Country]` | `FILTER(VALUES(CQD[Second Network Connection Detail]), CQD[Second Network Connection Detail]="Wifi"), FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio")` | `"Streams",SUM(CQD[Total Stream Count]),"B24",CALCULATE(SUM(CQD[Total Stream Count]), CQD[Second Wifi Band]="2.4 Ghz"),"Good24",CALCULATE(SUM(CQD[Audio Good Stream Count]), CQD[Second Wifi Band]="2.4 Ghz"),"Poor24",CALCULATE(SUM(CQD[Audio Poor Stream Count]), CQD[Second Wifi Band]="2.4 Ghz")` \u2014 ORDER `[B24], DESC, [Streams], DESC` |
| Q44 | T1 | `CQD[Second Network Mapped VPN], CQD[Media Type]` | `@F1` | `"Streams",SUM(CQD[Total Stream Count])` |
| Q45 | T2 N=20 | `CQD[Second Subnet], CQD[Second Building Name]` | `FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="Conf")` | `"Streams",SUM(CQD[Total Stream Count]),"Tcp",CALCULATE(SUM(CQD[Total Stream Count]), CQD[Second Transport Protocol] IN {"TCP","TurnTCP","MultiTurnTCP","CompoundTCP"})` \u2014 ORDER `[Tcp], DESC, [Streams], DESC` |
| Q46 | T1 | `CQD[Media Type], CQD[Stream Direction], CQD[Second Network Connection Detail]` | `@F1` | `"Streams",SUM(CQD[Total Stream Count]), @M2` |
| Q47 | T2 N=15 | `CQD[Second Feedback Tokens]` | `FILTER(VALUES(CQD[Second Feedback Tokens]), CQD[Second Feedback Tokens] <> "")` | `"RatingCount",SUM(CQD[Second Feedback Rating Count]),"PoorCount",SUM(CQD[Second Feedback Rating Poor Count])` \u2014 ORDER `[PoorCount], DESC, [RatingCount], DESC, CQD[Second Feedback Tokens], ASC` |
| Q48 | T2 N=30 | `CQD[Second Subnet], CQD[Second Network Name], CQD[Second Building Name], CQD[Second Inside Corp], CQD[Second Network Connection Detail]` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type] IN {"Conf","P2P"})` | `"Streams",SUM(CQD[Total Stream Count]),"AGood",SUM(CQD[Audio Good Stream Count]),"APoor",SUM(CQD[Audio Poor Stream Count])` \u2014 ORDER `[APoor], DESC, [Streams], DESC, CQD[Second Subnet], ASC` |
"""


def load_weekly_register(path=None):
    target = path or _weekly_register_path()
    if target is not None:
        try:
            return parse_weekly_register(Path(target).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            if path is not None:
                return {}
    if path is None:
        try:
            return parse_weekly_register(_FALLBACK_REGISTER_TEXT)
        except ValueError:
            return {}
    return {}


def date_span(first, last):
    start, end = date.fromisoformat(first), date.fromisoformat(last)
    return [(start + timedelta(days=offset)).isoformat() for offset in range((end - start).days + 1)]


_SIMPLE_COL_FILTER = re.compile(
    r"^\s*FILTER\(\s*VALUES\(\s*(CQD\[[^\]]+\])\s*\)\s*,\s*(.+)\)\s*$", re.S
)


def _split_top_level_commas(expr):
    parts, depth, in_str, start = [], 0, False, 0
    i = 0
    while i < len(expr):
        ch = expr[i]
        if ch == '"':
            if in_str and i + 1 < len(expr) and expr[i + 1] == '"':
                i += 2
                continue
            in_str = not in_str
        elif not in_str:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth = max(0, depth - 1)
            elif ch == "," and depth == 0:
                parts.append(expr[start:i].strip())
                start = i + 1
        i += 1
    tail = expr[start:].strip()
    if tail:
        parts.append(tail)
    return parts


def _merge_dax_filters(custom_filter, spec_filters):
    """Combine `custom_filter` with `spec_filters` without duplicate column lineage.

    DAX `SUMMARIZECOLUMNS` rejects two separate `FILTER(VALUES(CQD[Col]), ...)`
    arguments targeting the same column (such as `Q15`, which already filters
    `CQD[Second Building Name]`). Merging same-column predicates with `&&`
    into a single `FILTER(VALUES(CQD[Col]), ...)` keeps one filter table per column.
    """
    clauses = []
    for block in (custom_filter, spec_filters):
        if block:
            clauses.extend(_split_top_level_commas(block))
    if not clauses:
        return ""
    merged, index_by_col = [], {}
    for clause in clauses:
        match = _SIMPLE_COL_FILTER.match(clause)
        if not match:
            merged.append(clause)
            continue
        col, pred = match.group(1), match.group(2).strip()
        if col in index_by_col:
            pos, prev_pred = index_by_col[col]
            combined_pred = f"({prev_pred}) && ({pred})"
            merged[pos] = f"FILTER(VALUES({col}), {combined_pred})"
            index_by_col[col] = (pos, combined_pred)
        else:
            index_by_col[col] = (len(merged), pred)
            merged.append(clause)
    return ", ".join(merged)


def expand_register_query(register, qid, dates, focus=None, extra_filter=None):
    """The literal DAX the register defines for `qid` over `dates`, or None.

    None means the text cannot be rebuilt faithfully: an unknown query, a
    macro or placeholder left unresolved, or Q15 without its focus site.
    When `extra_filter` is supplied (for example a subsidiary filter on
    `CQD[Second Building Name]`), it is injected alongside the register's own
    filters so every query shares the exact same population scope.
    """
    spec = ((register or {}).get("queries") or {}).get(qid)
    template = spec and register.get("templates", {}).get(spec["template"])
    if not template or not dates:
        return None
    window = "TREATAS({" + ", ".join(f'"{day}"' for day in dates) + "}, CQD[Date])"
    macros = {**register.get("macros", {}), "@D": window, "@D14": window}

    def _expand_macros(fragment):
        if not fragment:
            return fragment
        out = fragment
        for _ in range(5):
            nxt = _MACRO.sub(lambda match: macros.get(match.group(0), match.group(0)), out)
            if nxt == out:
                break
            out = nxt
        return out

    custom_filter = _expand_macros(str(extra_filter).strip()) if extra_filter and str(extra_filter).strip() else None
    spec_filters = _expand_macros(spec["filters"]) if spec["filters"] else None
    combined_filters = _merge_dax_filters(custom_filter, spec_filters)

    text = template.replace("<GROUP>", spec["group"])
    if not combined_filters:
        text = text.replace("<FILTERS>, ", "")
    else:
        text = text.replace("<FILTERS>", combined_filters)
    text = text.replace("<MEASURES>", spec["measures"])
    if spec["n"]:
        text = text.replace("<N>", spec["n"])
    if spec["order"]:
        text = text.replace("<ORDER>", spec["order"])
    text = _expand_macros(text)
    if _MACRO.search(text) or any(placeholder in text for placeholder in _PLACEHOLDERS):
        return None
    # The site name is inserted last, so a building name is never read as a macro.
    if _FOCUS_MARKER in text:
        if not focus:
            return None
        text = text.replace(_FOCUS_MARKER, '"' + str(focus).replace('"', '""') + '"')
    return text


class Assembler:
    def __init__(self, raw):
        self.raw = raw
        self.results = expand_results(raw["results"])
        self.periods = raw["periods"]
        self.focus = raw.get("focus_site") or {}
        self.observations = {}
        self.queries = []
        self.seen_queries = set()
        self.investigation_evidence = {family: set() for family in FAMILIES}
        self._register = None
        self._mapping = None

    # -- raw access ---------------------------------------------------------
    def rows(self, qid, period=None):
        key = qid if period is None else f"{qid}_{PERIOD_TAG[period]}"
        entry = self.results.get(key)
        if not isinstance(entry, dict):
            return []
        self.register(key, entry, period)
        return entry.get("rows") or []

    def qid_for(self, qid, period=None):
        key = qid if period is None else f"{qid}_{PERIOD_TAG[period]}"
        entry = self.results.get(key)
        if isinstance(entry, dict):
            self.register(key, entry, period)
            return key if key in self.seen_queries else None
        return None

    # Q28-Q36 are deliberately ranked and truncated; the central register must
    # say so too, or it contradicts the embedded investigation batches.
    RANKED_QUERIES = frozenset(f"Q{n}" for n in range(28, 34)) | {"Q35", "Q36", "Q45", "Q47", "Q48"}
    # Q34 is the full-universe control: no partition is narrowed.
    UNIVERSE_FILTERS = {"Second Inside Corp": "all", "Second Network Connection Detail": "all",
                        "Stream Direction": "all", "Second Transport Protocol": "all",
                        "Second Subnet": "all", "Test Call Type": "NonTest"}

    def query_filters(self, key, period):
        base = {"Test Call Type": "NonTest", "period": self.periods[period] if period else "both"}
        scope_filter = str(self.raw.get("scope_filter") or "").strip()
        qid = key.split("_")[0]
        if qid == "Q34":
            out = dict(self.UNIVERSE_FILTERS,
                       period=self.periods[period] if period else "both")
        elif qid in self.RANKED_QUERIES:
            out = dict(base, ranking="top-N by streams")
        else:
            out = base
        if scope_filter:
            out = dict(out, scope_filter=scope_filter)
        return out

    def register(self, key, entry, period):
        if key in self.seen_queries:
            return
        self.seen_queries.add(key)
        error_text = str(entry.get("error") or "").strip()
        failed = bool(error_text)
        schema_err = failed and any(
            token in error_text.lower()
            for token in ("column", "measure", "cannot find", "does not exist",
                          "not found", "invalid", "unrecognized", "unknown", "resolve")
        )
        ranked = key.split("_")[0] in self.RANKED_QUERIES
        self.queries.append({
            "id": key,
            "status": "unsupported" if schema_err else "failed" if failed
                      else "partial" if ranked else "complete",
            "truncated": False if schema_err else None if failed else bool(ranked),
            "query": self.dax_for(key, period),
            "action": f"register query {key}",
            "filters": self.query_filters(key, period),
            "period": "both" if period is None else period,
            "row_count": len(entry.get("rows") or []),
            "evidence_type": "schema" if schema_err else "data",
            "reason": error_text if failed
                      else "Ranked top-N cohorts, not an exhaustive enumeration."
                      if ranked else None,
        })

    def dax_for(self, key, period):
        """The DAX that produced `key`: the recorded text, else the register's."""
        recorded = (self.results.get(key) or {}).get("dax")
        if isinstance(recorded, str) and recorded.strip():
            return recorded
        if self._register is None:
            self._register = load_weekly_register()
        try:
            first, last = ((self.periods["previous"][0], self.periods["current"][1])
                           if period is None else self.periods[period])
            dates = date_span(first, last)
        except (KeyError, IndexError, TypeError, ValueError):
            dates = None
        qid = key.split("_")[0]
        focus = self.focus.get("S") if qid == "Q15" else None
        extra_filter = self.raw.get("scope_filter")
        return (expand_register_query(self._register, qid, dates, focus, extra_filter=extra_filter) or
                f"Register query {key}: DAX not recorded and not rebuildable from weekly-register.md.")

    # -- building mapping -----------------------------------------------------
    BUILDING_FILE_ADVICE = ("Recommendation: populate the Building File (subnets, building "
                            "names, Inside flag) in the Teams admin center.")

    def mapping_state(self):
        """What the executed Q3/Q14 results say about the Building File.

        An executed query that names no building is an observed tenant state,
        not unfinished collection: the site and Inside sections are closed as
        unsupported with that evidence, and every tenant-wide analysis stays
        available. A query that was not run, or failed, proves nothing.
        """
        if self._mapping is not None:
            return self._mapping
        q3 = self.results.get("Q3")
        q3_executed = isinstance(q3, dict) and not q3.get("error")
        q3_rows = self.rows("Q3") if q3_executed else []
        q14_ids, names, executed = [], set(), set()
        for period in ("previous", "current"):
            entry = self.results.get(f"Q14_{PERIOD_TAG[period]}")
            if not isinstance(entry, dict) or entry.get("error"):
                continue
            executed.add(period)
            q14_ids.append(self.qid_for("Q14", period))
            names.update(n for n in (dim(r, "Second Building Name")
                                     for r in self.rows("Q14", period)) if n)
        sites_unavailable = "current" in executed and not names
        inside_unavailable = q3_executed and not q3_rows
        self._mapping = state = {
            "sites_unavailable": sites_unavailable,
            "inside_unavailable": inside_unavailable,
            "mapping_unavailable": inside_unavailable and not names,
            "q14_ids": [q for q in q14_ids if q],
            "sites_reason": ("Q14 executed but returned no named building: the Building File "
                             "maps no subnet to a building. " + self.BUILDING_FILE_ADVICE),
            "inside_reason": ("Q3 executed over the 14 days and returned no Inside traffic: no "
                              "subnet is mapped as Inside. " + self.BUILDING_FILE_ADVICE),
        }
        if sites_unavailable or inside_unavailable:
            found = []
            if sites_unavailable:
                found.append("Q14 executed and named no building.")
            if inside_unavailable:
                found.append("Q3 executed over the 14 days and returned no Inside traffic.")
            self.seen_queries.add("MAPPING")
            self.queries.append({
                "id": "MAPPING",
                "status": "unsupported",
                "truncated": False,
                "query": "Derived from the executed Q3/Q14 results; no DAX of its own.",
                "action": "derive building-mapping availability from Q3/Q14",
                "filters": {"source": "Q3/Q14 outcome"},
                "period": "n/a",
                "row_count": 0,
                "evidence_type": "schema",
                "reason": " ".join(found + [self.BUILDING_FILE_ADVICE]),
            })
        return state

    # -- observation writing ------------------------------------------------
    def obs(self, metric, period, *, value=None, numerator=None, denominator=None,
            unit="percent", query=None, population=None, definition=None,
            counts=None, scope=None, reason=None, grain=None, aggregation=None):
        key = f"obs.{metric}.{period}"
        if value is None and numerator is not None and denominator:
            value = ratio(numerator, denominator, 100.0 if unit == "percent" else 1.0)
        item = {
            "id": key, "native": metric, "unit": unit, "value": value,
            "numerator": numerator, "denominator": denominator,
            "denominator_definition": definition,
            "population_key": population or metric,
            "query": query,
            "reason": None if value is not None else (reason or "No row matched this cohort in the collected result."),
        }
        if counts:
            item["counts"] = counts
        if scope:
            item["scope"] = scope
        if grain:
            item["grain"] = grain
        if aggregation:
            item["aggregation"] = aggregation
        self.observations[key] = item

    def missing(self, metric, period, unit, query, why):
        self.obs(metric, period, unit=unit, query=query, reason=why)

    # -- Q1 : tenant reliability and usage ----------------------------------
    def reliability(self, period):
        rows = self.rows("Q1", period)
        qid = self.qid_for("Q1", period)
        by_scenario = {dim(r, "Session Type"): r for r in rows}
        population = "tenant;nontest"

        buckets = {"conf": [by_scenario.get("Conf")], "p2p": [by_scenario.get("P2P")],
                   "all": list(by_scenario.values())}
        for suffix, group in buckets.items():
            group = [r for r in group if r]
            cdr, failed = total(group, "CDR"), total(group, "Failed")
            established, dropped = total(group, "Established"), total(group, "Dropped")
            self.obs(f"setup.tenant.{suffix}", period, numerator=failed, denominator=cdr,
                     query=qid, population=population, definition="failed / CDR",
                     counts={"cdr": cdr, "failed": failed}, grain="stream",
                     aggregation="ratio_of_counts",
                     reason=f"{qid}: no Session Type row for {suffix}.")
            self.obs(f"drop.tenant.{suffix}", period, numerator=dropped, denominator=established,
                     query=qid, population=population, definition="dropped / established",
                     counts={"established": established, "dropped": dropped}, grain="stream",
                     aggregation="ratio_of_counts",
                     reason=f"{qid}: no Session Type row for {suffix}.")

        self.obs("usage.calls.all", period, value=total(rows, "Calls"), unit="count",
                 query=qid, population=population, grain="call_leg", aggregation="count",
                 reason=f"{qid}: Total Call Count not returned.")
        self.obs("usage.streams.all", period, value=total(rows, "Streams"), unit="count",
                 query=qid, population=population, grain="stream", aggregation="count",
                 reason=f"{qid}: Total Stream Count not returned.")
        days = self.rows("Q2")
        window = self.periods[period]
        measured = [r for r in days if window[0] <= str(dim(r, "Date"))[:10] <= window[1]]
        self.obs("usage.days", period, value=len(measured) or None, unit="count",
                 query=self.qid_for("Q2"), population=population, grain="stream",
                 aggregation="count", reason="Q2: no daily row inside this period.")

    # -- Q4 : media quality and classifiers ---------------------------------
    def media(self, period):
        rows = self.rows("Q4", period)
        qid = self.qid_for("Q4", period)
        for media in ("Audio", "Video", "VBSS"):
            slot = media.lower()
            selected = [r for r in rows if dim(r, "Media Type") == media]
            conf = [r for r in selected if dim(r, "Session Type") == "Conf"]
            p2p = [r for r in selected if dim(r, "Session Type") == "P2P"]
            # When one scenario has measured Good/Poor counts and the sibling
            # scenario emitted no row in a completed Q4 query, that sibling had
            # 0 streams (0 Good, 0 Poor) rather than missing columns.
            any_measured = (total(conf + p2p, MEDIA_GOOD[media]) is not None
                            and total(conf + p2p, MEDIA_POOR[media]) is not None)
            # The all-session slot is the sum of the two scenario slots, so it is
            # built from them rather than from every returned Session Type value.
            groups = {"conf": conf, "p2p": p2p, "all": conf + p2p}
            for suffix, group in groups.items():
                good, poor = total(group, MEDIA_GOOD[media]), total(group, MEDIA_POOR[media])
                if not group and suffix in ("conf", "p2p") and any_measured:
                    good, poor = 0, 0
                eligible = None if good is None or poor is None else good + poor
                scenario = {"conf": "Conf", "p2p": "P2P", "all": "Conf+P2P"}[suffix]
                zero_reason = (f"{qid}: 0 {media}/{scenario} streams in this period."
                               if eligible == 0 else f"{qid}: no {media}/{scenario} row returned.")
                self.obs(f"psr.{slot}.tenant.{suffix}", period,
                         numerator=poor, denominator=eligible, query=qid,
                         # The all-session slot is recomposed from these two, so
                         # all three must declare the same population and grain.
                         population=f"{media};nontest",
                         definition="Good + Poor classified streams",
                         counts={"good": good, "poor": poor}, grain="stream",
                         aggregation="ratio_of_counts",
                         scope={"media": media, "scenario": scenario, "direction": "all reported",
                                "endpoint_anchor": "Second", "network_scope": "all"},
                         reason=zero_reason)

        for scenario, suffix in (("Conf", "conf"), ("P2P", "p2p")):
            group = [r for r in rows if dim(r, "Session Type") == scenario]
            freeze = total(group, "Freeze")
            video = [r for r in group if dim(r, "Media Type") == "Video"]
            eligible = total(video, "VGood")
            poor = total(video, "VPoor")
            denominator = None if eligible is None or poor is None else eligible + poor
            self.obs(f"freeze.tenant.{suffix}", period, numerator=freeze, denominator=denominator,
                     query=qid, population=f"Video;{scenario};freeze;nontest",
                     definition="Video Poor Due to Freeze / Good + Poor video streams",
                     grain="stream", aggregation="ratio_of_counts",
                     reason=f"{qid}: freeze counts not returned for {scenario}.")

        # The dashboard declares only these four tenant classifier slots; the full
        # ten-classifier matrix lives in the media-classifiers extension.
        for classifier, scenarios in (("inbound_network", ("Conf", "P2P")),
                                      ("uplink", ("Conf",)),
                                      ("media_modality", ("Conf",))):
            true_alias, false_alias, _ = CLASSIFIERS[classifier]
            for scenario in scenarios:
                suffix = scenario.lower()
                metric = f"clf.{classifier}.tenant.{suffix}"
                group = [r for r in rows if dim(r, "Session Type") == scenario]
                true_count = total(group, true_alias)
                false_count = total(group, false_alias) if false_alias else None
                eligible = None if true_count is None or false_count is None else true_count + false_count
                self.obs(metric, period, numerator=true_count, denominator=eligible, query=qid,
                         population=f"{classifier};{scenario};nontest",
                         definition="True + False classified streams", grain="stream",
                         aggregation="ratio_of_counts",
                         counts={"true": true_count, "false": false_count},
                         reason=f"{qid}: {classifier} counts not returned for {scenario}.")

    # -- Q5 : network context ----------------------------------------------
    def network_context(self, period):
        rows = self.rows("Q5", period)
        qid = self.qid_for("Q5", period)
        conn_label = {"wired": "Wired", "wifi": "Wifi", "mobilebb": "MobileBB"}

        for scope_name in ("Inside", "Outside"):
            for conn, label in (("wired", "Wired"), ("wifi", "Wifi")):
                selected = [r for r in rows
                            if dim(r, "Media Type") == "Audio"
                            and dim(r, "Second Inside Corp") == scope_name
                            and dim(r, "Second Network Connection Detail") == label]
                good, poor = total(selected, "AGood"), total(selected, "APoor")
                eligible = None if good is None or poor is None else good + poor
                metric = f"psr.audio.conn.all.{scope_name.lower()}_{conn}"
                self.obs(metric, period, numerator=poor, denominator=eligible, query=qid,
                         population=f"Audio;Conf+P2P;{scope_name.lower()}_{conn};nontest",
                         definition="Good + Poor classified streams",
                         counts={"good": good, "poor": poor}, grain="stream",
                         aggregation="ratio_of_counts",
                         scope={"media": "Audio", "scenario": "Conf+P2P", "direction": "all reported",
                                "endpoint_anchor": "Second", "network_scope": scope_name},
                         reason=f"{qid}: no Audio row for {scope_name}/{label}.")

        for metric, scope_name, label in (("psr.audio.conn.p2p.inside_wired", "Inside", "Wired"),
                                          ("psr.audio.conn.p2p.outside_wifi", "Outside", "Wifi")):
            selected = [r for r in rows
                        if dim(r, "Media Type") == "Audio" and dim(r, "Session Type") == "P2P"
                        and dim(r, "Second Inside Corp") == scope_name
                        and dim(r, "Second Network Connection Detail") == label]
            good, poor = total(selected, "AGood"), total(selected, "APoor")
            eligible = None if good is None or poor is None else good + poor
            self.obs(metric, period, numerator=poor, denominator=eligible, query=qid,
                     population=f"Audio;P2P;{scope_name.lower()}_{label.lower()};nontest",
                     definition="Good + Poor classified streams",
                     counts={"good": good, "poor": poor}, grain="stream",
                     aggregation="ratio_of_counts",
                     reason=f"{qid}: no P2P Audio row for {scope_name}/{label}.")

        for conn, label in conn_label.items():
            selected = [r for r in rows if dim(r, "Session Type") == "Conf"
                        and dim(r, "Second Network Connection Detail") == label]
            dropped, established = total(selected, "Dropped"), total(selected, "Established")
            self.obs(f"drop.conn.conf.{conn}", period, numerator=dropped, denominator=established,
                     query=qid, population=f"Conf;{label};nontest",
                     definition="dropped / established", grain="stream",
                     aggregation="ratio_of_counts",
                     counts={"established": established, "dropped": dropped},
                     reason=f"{qid}: no Conf row for {label}.")

        vbss = [r for r in rows if dim(r, "Media Type") == "VBSS" and dim(r, "Session Type") == "P2P"]
        dropped, established = total(vbss, "Dropped"), total(vbss, "Established")
        self.obs("drop.media.p2p.vbss", period, numerator=dropped, denominator=established,
                 query=qid, population="VBSS;P2P;nontest", definition="dropped / established",
                 grain="stream", aggregation="ratio_of_counts",
                 counts={"established": established, "dropped": dropped},
                 reason=f"{qid}: no P2P VBSS row returned.")

    # -- Q6 : ICE paths -----------------------------------------------------
    def ice(self, period):
        rows = self.rows("Q6", period)
        qid = self.qid_for("Q6", period)

        def path_of(row):
            return " : ".join(p.strip().upper() for p in str(dim(row, "Connectivity Ice Pair") or "").split(":"))

        for metric, wanted in (("psr.audio.ice.p2p.direct_direct", "DIRECT : DIRECT"),
                               ("psr.audio.ice.p2p.direct_relay", "DIRECT : RELAY")):
            selected = [r for r in rows if path_of(r) == wanted]
            good, poor = total(selected, "AGood"), total(selected, "APoor")
            eligible = None if good is None or poor is None else good + poor
            self.obs(metric, period, numerator=poor, denominator=eligible, query=qid,
                     population=f"Audio;P2P;{wanted};nontest",
                     definition="Good + Poor classified streams",
                     counts={"good": good, "poor": poor}, grain="stream",
                     aggregation="ratio_of_counts",
                     reason=f"{qid}: no P2P pair on path {wanted}.")

        streams = total(rows, "Streams")
        relayed = total([r for r in rows if "RELAY" in path_of(r)], "Streams")
        self.obs("ice.p2p_relay_share", period, numerator=relayed, denominator=streams,
                 query=qid, population="P2P;ice-pairs;nontest",
                 definition="relayed / all reported P2P pairs", grain="stream",
                 aggregation="ratio_of_counts",
                 reason=f"{qid}: no P2P pair rows returned.")

    # -- Q7 : client cohorts ------------------------------------------------
    def clients(self, period):
        rows = self.rows("Q7", period)
        qid = self.qid_for("Q7", period)

        def cohort(names, scenario):
            return [r for r in rows if dim(r, "Second User Agent Category") in names
                    and (scenario is None or dim(r, "Session Type") == scenario)]

        for slot in ("teams21windows", "teams21web", "teamsrooms"):
            selected = cohort(CLIENTS[slot], "Conf")
            dropped, established = total(selected, "Dropped"), total(selected, "Established")
            self.obs(f"drop.ua.conf.{slot}", period, numerator=dropped, denominator=established,
                     query=qid, population=f"Conf;{slot};nontest",
                     definition="dropped / established", grain="stream",
                     aggregation="ratio_of_counts",
                     counts={"established": established, "dropped": dropped},
                     reason=f"{qid}: no Conf row for {slot}.")

        for metric, slot, scenario in (("psr.audio.ua.conf.android", "android", "Conf"),
                                       ("psr.audio.ua.conf.ios", "ios", "Conf"),
                                       ("psr.audio.ua.p2p.android", "android", "P2P"),
                                       ("psr.audio.ua.p2p.teams21windows", "teams21windows", "P2P")):
            selected = cohort(CLIENTS[slot], scenario)
            good, poor = total(selected, "AGood"), total(selected, "APoor")
            eligible = None if good is None or poor is None else good + poor
            self.obs(metric, period, numerator=poor, denominator=eligible, query=qid,
                     population=f"Audio;{scenario};{slot};nontest",
                     definition="Good + Poor classified streams",
                     counts={"good": good, "poor": poor}, grain="stream",
                     aggregation="ratio_of_counts",
                     reason=f"{qid}: no {scenario} Audio row for {slot}.")

        for slot in ("teams21windows", "citrixvdi"):
            selected = cohort(CLIENTS[slot], "Conf")
            true_count, false_count = total(selected, "LcT"), total(selected, "LcF")
            eligible = None if true_count is None or false_count is None else true_count + false_count
            self.obs(f"cpu.classifier.ua.conf.{slot}", period,
                     numerator=true_count, denominator=eligible, query=qid,
                     population=f"local_compute;Conf;{slot};nontest",
                     definition="True + False classified streams", grain="stream",
                     aggregation="ratio_of_counts",
                     counts={"true": true_count, "false": false_count},
                     reason=f"{qid}: local-compute classifier counts absent for {slot}.")

        selected = cohort(CLIENTS["teams21windows"], "Conf")
        cpu = next((num(r, "SysCPU") for r in selected if num(r, "SysCPU") is not None), None)
        self.obs("cpu.system_avg.ua.conf.teams21windows", period, value=cpu, query=qid,
                 population="Conf;teams21windows;system-cpu;nontest",
                 definition="native mean of Avg Second System CPU Resource Usage Average",
                 grain="native_measure", aggregation="native",
                 reason=f"{qid}: system CPU mean not returned for this cohort.")

    # -- Q8 : transport -----------------------------------------------------
    def transport(self, period):
        rows = self.rows("Q8", period)
        qid = self.qid_for("Q8", period)
        streams = self.observations.get(f"obs.usage.streams.all.{period}", {}).get("value")

        def protocol(row):
            return str(dim(row, "Second Transport Protocol") or "").strip().upper()

        udp = total([r for r in rows if protocol(r) == "UDP"], "Streams")
        tcp_family = total([r for r in rows if protocol(r).lower() in self.TCP_FAMILY
                            or protocol(r).startswith("TCP") or "TURNTCP" in protocol(r)], "Streams")
        turn = total([r for r in rows if "TURNTCP" in protocol(r)], "Streams")
        blank = None
        if streams is not None and udp is not None and tcp_family is not None:
            blank = max(0, int(streams) - int(udp) - int(tcp_family))
        partition = None if None in (udp, tcp_family, blank) else udp + tcp_family + blank

        for slot, numerator in (("udp", udp), ("tcpfamily", tcp_family),
                                ("blank", blank), ("turntcp", turn)):
            self.obs(f"transport.{slot}", period, numerator=numerator, denominator=partition,
                     query=qid, population="tenant;transport-partition;nontest",
                     definition="UDP + TCP family + unknown transport streams",
                     grain="stream", aggregation="ratio_of_counts",
                     reason=f"{qid}: {slot} share not derivable from the returned protocols.")
        return {"udp": udp, "tcpfamily": tcp_family, "blank": blank}

    # -- Q9 : Wi-Fi bands ---------------------------------------------------
    def wifi(self, period):
        rows = self.rows("Q9", period)
        qid = self.qid_for("Q9", period)

        def band_of(row):
            raw = str(dim(row, "Second Wifi Band") or "").lower().replace("ghz", "").replace(",", ".").strip()
            return "2.4" if raw.startswith("2") else "5" if raw.startswith("5") else raw

        def band_rows(band, scenario=None):
            return [r for r in rows if band_of(r) == band
                    and (scenario is None or dim(r, "Session Type") == scenario)]

        for metric, band, scenario in (("wifi.psr.conf.24", "2.4", "Conf"),
                                       ("wifi.psr.conf.5", "5", "Conf"),
                                       ("wifi.psr.p2p.24", "2.4", "P2P")):
            selected = band_rows(band, scenario)
            good, poor = total(selected, "AGood"), total(selected, "APoor")
            eligible = None if good is None or poor is None else good + poor
            self.obs(metric, period, numerator=poor, denominator=eligible, query=qid,
                     population=f"Audio;{scenario};wifi-{band};nontest",
                     definition="Good + Poor classified streams",
                     counts={"good": good, "poor": poor}, grain="stream",
                     aggregation="ratio_of_counts",
                     reason=f"{qid}: no {scenario} row on the {band} GHz band.")

        conf = [r for r in rows if dim(r, "Session Type") == "Conf"]
        self.obs("wifi.share.conf.24", period,
                 numerator=total(band_rows("2.4", "Conf"), "Streams"),
                 denominator=total(conf, "Streams"), query=qid,
                 population="Conf;wifi-all-bands;nontest",
                 definition="2.4 GHz streams / all Wi-Fi meeting streams",
                 grain="stream", aggregation="ratio_of_counts",
                 reason=f"{qid}: Wi-Fi band mix not returned.")

        for metric, band, radio in (("wifi.jitter.conf.24n", "2.4", "n"),
                                    ("wifi.jitter.conf.5ac", "5", "ac")):
            selected = [r for r in band_rows(band, "Conf")
                        if radio in str(dim(r, "Second Wifi Radio Type") or "").lower()]
            value = next((num(r, "Jitter") for r in selected if num(r, "Jitter") is not None), None)
            self.obs(metric, period, value=value, unit="ms", query=qid,
                     population=f"Conf;wifi-{band}-{radio};jitter;nontest",
                     grain="native_measure", aggregation="native",
                     reason=f"{qid}: no native jitter for {band} GHz 802.11{radio}.")

    # -- Q10 : network performance -----------------------------------------
    def netperf(self, period):
        rows = self.rows("Q10", period)
        qid = self.qid_for("Q10", period)
        conn_label = {"wifi": "Wifi", "wired": "Wired", "mobilebb": "MobileBB"}

        def pick(conn, scenario, alias):
            selected = [r for r in rows
                        if dim(r, "Second Network Connection Detail") == conn_label[conn]
                        and dim(r, "Session Type") == scenario
                        and dim(r, "Stream Direction") == "First-to-Second"]
            return next((num(r, alias) for r in selected if num(r, alias) is not None), None)

        for metric, conn, scenario, alias in (
                ("net.avg_jitter.netperf.conf.wifi.first_to_second", "wifi", "Conf", "Jitter"),
                ("net.avg_round_trip.netperf.conf.wifi.first_to_second", "wifi", "Conf", "RTT"),
                ("net.avg_round_trip.netperf.conf.wired.first_to_second", "wired", "Conf", "RTT"),
                ("net.avg_round_trip.netperf.p2p.wifi.first_to_second", "wifi", "P2P", "RTT"),
                ("net.avg_round_trip_max.netperf.conf.mobilebb.first_to_second", "mobilebb", "Conf", "RTTMax")):
            self.obs(metric, period, value=pick(conn, scenario, alias), unit="ms", query=qid,
                     population=f"Audio;{scenario};{conn};First-to-Second;nontest",
                     grain="native_measure", aggregation="native",
                     reason=f"{qid}: no native {alias} for {conn}/{scenario}/First-to-Second.")

    # -- Q11 : VPN ----------------------------------------------------------
    def vpn(self, period):
        rows = self.rows("Q11", period)
        qid = self.qid_for("Q11", period)

        def flagged(row):
            return str(dim(row, "Second VPN Estimated") or "").strip()

        for metric, wanted in (("psr.audio.vpn.estimated", "1"), ("psr.audio.vpn.flag0", "0")):
            selected = [r for r in rows if flagged(r) == wanted]
            good, poor = total(selected, "AGood"), total(selected, "APoor")
            eligible = None if good is None or poor is None else good + poor
            self.obs(metric, period, numerator=poor, denominator=eligible, query=qid,
                     population=f"Audio;vpn-estimated-{wanted};nontest",
                     definition="Good + Poor classified streams",
                     counts={"good": good, "poor": poor}, grain="stream",
                     aggregation="ratio_of_counts",
                     reason=f"{qid}: no Audio row with VPN Estimated = {wanted}.")

        streams = total(rows, "Streams")
        self.obs("vpn.flag_share", period,
                 numerator=total([r for r in rows if flagged(r) == "1"], "Streams"),
                 denominator=streams, query=qid, population="Audio;vpn-partition;nontest",
                 definition="flagged VPN streams / all reported", grain="stream",
                 aggregation="ratio_of_counts",
                 reason=f"{qid}: VPN partition not returned.")
        self.obs("vpn.unknown_share", period,
                 numerator=total([r for r in rows if flagged(r) not in ("0", "1")], "Streams"),
                 denominator=streams, query=qid, population="Audio;vpn-partition;nontest",
                 definition="unknown VPN state / all reported", grain="stream",
                 aggregation="ratio_of_counts",
                 reason=f"{qid}: VPN partition not returned.")

    # -- Q12 : VDI ----------------------------------------------------------
    def vdi(self, period):
        rows = self.rows("Q12", period)
        qid = self.qid_for("Q12", period)
        streams = total(rows, "Streams")

        def state(row):
            return str(dim(row, "Second Client VDI Is Optimized") or "").strip().lower()

        def mode(row):
            return str(dim(row, "Second Client VDI Mode") or "").strip()

        vdi_rows = [r for r in rows if mode(r) or state(r)]
        vdi_streams = total(vdi_rows, "Streams")
        self.obs("vdi.streams", period, value=vdi_streams, unit="count", query=qid,
                 population="vdi;nontest", grain="stream", aggregation="count",
                 reason=f"{qid}: no VDI mode reported.")

        buckets = {
            "optimized": [r for r in vdi_rows
                          if state(r) in ("true", "1", "yes", "optimized", "vdi 2.0 optimized")],
            "not_optimized": [r for r in vdi_rows
                              if state(r) in ("false", "0", "no", "not optimized", "vdi 2.0 not optimized")],
            "inactive": [r for r in vdi_rows if "inactive" in state(r)],
        }
        buckets["unknown"] = [r for r in vdi_rows if r not in buckets["optimized"]
                              and r not in buckets["not_optimized"] and r not in buckets["inactive"]]
        for slot, group in buckets.items():
            self.obs(f"vdi.{slot}", period, numerator=total(group, "Streams"),
                     denominator=vdi_streams, query=qid, population="vdi;partition;nontest",
                     definition="state streams / all VDI streams", grain="stream",
                     aggregation="ratio_of_counts",
                     reason=f"{qid}: no VDI row in state {slot}.")

        versions = {str(dim(r, "Second Client VDI Provider Version") or "").strip()
                    for r in vdi_rows}
        versions.discard("")
        self.obs("vdi.citrix_versions", period, value=len(versions) or None, unit="count",
                 query=qid, population="vdi;provider-versions;nontest",
                 grain="native_measure", aggregation="count",
                 reason=f"{qid}: no VDI provider version reported.")
        return streams

    # -- Q13 : client versions ----------------------------------------------
    def versions(self, period):
        rows = self.rows("Q13", period)
        qid = self.qid_for("Q13", period)
        streams = total(rows, "Streams")

        ranked = sorted((r for r in rows if num(r, "Streams")),
                        key=lambda r: num(r, "Streams"), reverse=True)
        primary = dim(ranked[0], "Second Client App Version") if ranked else None
        worst = max((r for r in rows if num(r, "APoor")), key=lambda r: num(r, "APoor"), default=None)
        quality_focus = dim(worst, "Second Client App Version") if worst else None

        top_rows = [r for r in rows if dim(r, "Second Client App Version") == primary]
        self.obs("ver.share.windows.primary", period, numerator=total(top_rows, "Streams"),
                 denominator=streams, query=qid, population="teams21windows;versions;nontest",
                 definition="primary version streams / all observed Windows streams",
                 grain="stream", aggregation="ratio_of_counts",
                 reason=f"{qid}: no Windows version rows returned.")
        self.obs("ver.drop.windows.primary", period, numerator=total(top_rows, "Dropped"),
                 denominator=total(top_rows, "Established"), query=qid,
                 population="teams21windows;primary-version;nontest",
                 definition="dropped / established", grain="stream", aggregation="ratio_of_counts",
                 reason=f"{qid}: primary version reliability not returned.")
        focus_rows = [r for r in rows if dim(r, "Second Client App Version") == quality_focus]
        good, poor = total(focus_rows, "AGood"), total(focus_rows, "APoor")
        eligible = None if good is None or poor is None else good + poor
        self.obs("ver.psr.windows.quality_focus", period, numerator=poor, denominator=eligible,
                 query=qid, population="teams21windows;quality-focus-version;nontest",
                 definition="Good + Poor classified streams",
                 counts={"good": good, "poor": poor}, grain="stream",
                 aggregation="ratio_of_counts",
                 reason=f"{qid}: quality-focus version not identified.")
        return {"primary": primary, "quality_focus": quality_focus}

    # -- Q16 : diagnostic cohorts -------------------------------------------
    def diagnostics(self, period):
        rows = self.rows("Q16", period)
        qid = self.qid_for("Q16", period)
        mce_name = "MediaConnectivityError"

        def is_mce(row):
            return mce_name.lower() in str(dim(row, "CDR Response Reason") or "").lower()

        mce = [r for r in rows if is_mce(r)]
        other = [r for r in rows if not is_mce(r)]

        self.obs("drop.tenant.conf.cdr_mce", period, numerator=total(mce, "Dropped"),
                 denominator=total(mce, "Established"), query=qid,
                 population=f"Conf;{mce_name};nontest", definition="dropped / established",
                 grain="stream", aggregation="ratio_of_counts",
                 reason=f"{qid}: no {mce_name} cohort returned.")
        self.obs("drop.tenant.conf.cdr_not_mce", period, numerator=total(other, "Dropped"),
                 denominator=total(other, "Established"), query=qid,
                 population="Conf;other-cdr-reasons;nontest", definition="dropped / established",
                 grain="stream", aggregation="ratio_of_counts",
                 reason=f"{qid}: no non-error CDR cohort returned.")
        self.obs("mce.share_drops.tenant.conf", period, numerator=total(mce, "Dropped"),
                 denominator=total(rows, "Dropped"), query=qid,
                 population="Conf;cdr-reason-partition;nontest",
                 definition="error-tagged drops / all meeting drops", grain="stream",
                 aggregation="ratio_of_counts",
                 reason=f"{qid}: drop partition by CDR reason not returned.")
        self.obs("mce.share_streams.tenant.conf", period, numerator=total(mce, "CDR"),
                 denominator=total(rows, "CDR"), query=qid,
                 population="Conf;cdr-reason-partition;nontest",
                 definition="error-tagged CDR / all meeting CDR", grain="stream",
                 aggregation="ratio_of_counts",
                 reason=f"{qid}: CDR partition by reason not returned.")

        for metric, scope_name, conn in (("mce.conf.blank_outside", "Outside", ""),
                                         ("mce.conf.wired_inside", "Inside", "Wired")):
            selected = [r for r in mce if dim(r, "Second Inside Corp") == scope_name
                        and str(dim(r, "Second Network Connection Detail") or "").strip() == conn]
            self.obs(metric, period, numerator=total(selected, "Dropped"),
                     denominator=total(selected, "Established"), query=qid,
                     population=f"Conf;{mce_name};{scope_name};{conn or 'unknown-connection'};nontest",
                     definition="dropped / established", grain="stream",
                     aggregation="ratio_of_counts",
                     reason=f"{qid}: no error-tagged row for {scope_name}/{conn or 'unknown'}.")

        media_rows = self.rows("Q25", period)
        media_qid = self.qid_for("Q25", period)
        conf = [r for r in media_rows if dim(r, "Session Type") == "Conf"]
        failed = [r for r in conf
                  if str(dim(r, "Media Failure Type") or "").strip().lower()
                  not in ("", "notmediafailure")]
        self.obs("mediafail.calls.tenant.conf", period, numerator=total(failed, "Calls"),
                 denominator=total(conf, "Calls"), query=media_qid,
                 population="Conf;media-failure;call-leg;nontest",
                 definition="calls with a media failure / all meeting call legs",
                 grain="call_leg", aggregation="ratio_of_counts",
                 reason=f"{media_qid}: media failure partition not returned.")

    # -- Q24 : poor reasons --------------------------------------------------
    def poor_reasons(self, period):
        rows = self.rows("Q24", period)
        qid = self.qid_for("Q24", period)
        selected = [r for r in rows if dim(r, "Session Type") == "P2P"
                    and "round" in str(dim(r, "Poor Reason") or "").lower()
                    and "trip" in str(dim(r, "Poor Reason") or "").lower()]
        self.obs("psr.audio.reason_roundtrip.tenant.p2p", period,
                 value=total(selected, "Streams"), unit="count", query=qid,
                 population="Audio;P2P;poor-reason-roundtrip;nontest",
                 grain="stream", aggregation="count",
                 reason=f"{qid}: no P2P round-trip poor-reason row returned.")

    # -- Q14/Q15 : sites and focus ------------------------------------------
    def _grouped_q14(self, period):
        """Aggregate Q14 rows by Second Building Name.

        A Building File may list the same building code under two country
        spellings (for example 'FR' and 'France'). Merging rows that share a
        building name prevents duplicate site records and ensures the busiest
        building is ranked on its whole Inside volume.
        """
        grouped = collections.OrderedDict()
        for row in self.rows("Q14", period):
            name = dim(row, "Second Building Name")
            if not name:
                continue
            country = dim(row, "Second Country")
            if name not in grouped:
                grouped[name] = {
                    "name": name, "country": country, "countries": [],
                    "Streams": None, "Dropped": None, "Established": None,
                    "Failed": None, "CDR": None,
                }
            item = grouped[name]
            if country and country not in item["countries"]:
                item["countries"].append(country)
                item["country"] = " / ".join(item["countries"])
            for alias in ("Streams", "Dropped", "Established", "Failed", "CDR"):
                val = num(row, alias)
                if val is not None:
                    item[alias] = (item[alias] or 0) + val
        return sorted(grouped.values(),
                      key=lambda item: (-(item["Streams"] or 0), -(item["Dropped"] or 0), item["name"]))

    def sites(self):
        current = self._grouped_q14("current")
        previous = {r["name"]: r for r in self._grouped_q14("previous")}
        qid = self.qid_for("Q14", "current")
        prev_qid = self.qid_for("Q14", "previous")
        sites = []
        for row in current:
            name = row["name"]
            earlier = previous.get(name)
            sites.append({
                "name": name, "streams": row["Streams"], "dropped": row["Dropped"],
                "established": row["Established"], "failed": row["Failed"],
                "previous": earlier["Dropped"] if earlier else None,
                "query_id": qid, "previous_query_id": prev_qid if earlier else None,
                "population_key": "Inside;Conf+P2P;top10;nontest",
                "reason": None if earlier else "Site absent from the prior-week ranking.",
                "scope": {"media": "All", "scenario": "Conf+P2P", "direction": "all reported",
                          "endpoint_anchor": "Second", "network_scope": "Inside"},
            })
        return sites

    def focus_daily(self):
        focus = self.focus.get("S")
        if not focus or self.mapping_state()["sites_unavailable"]:
            return None, []
        rows = self.rows("Q15", "current")
        qid = self.qid_for("Q15", "current")
        measured = {str(dim(r, "Date"))[:10]: r for r in rows}
        start = date.fromisoformat(self.periods["current"][0])
        daily = []
        for offset in range(7):
            day = (start + timedelta(days=offset)).isoformat()
            row = measured.get(day)
            daily.append({
                "date": day,
                "streams": num(row, "Streams") if row else None,
                "cdr": num(row, "CDR") if row else None,
                "failed": num(row, "Failed") if row else None,
                "established": num(row, "Established") if row else None,
                "dropped": num(row, "Dropped") if row else None,
                "query_id": qid,
                "population_key": f"Inside;{focus};daily;nontest",
                "reason": None if row else f"{qid} returned no row for this date at {focus}.",
            })
        return focus, daily

    def focus_observations(self, period):
        focus = self.focus.get("S")
        mapping = self.mapping_state()
        if not focus or mapping["sites_unavailable"]:
            why = (mapping["sites_reason"] if mapping["sites_unavailable"] else
                   "No focus site was selected, so Q15 (focus-site daily detail) was not collected.")
            for metric in ("site.focus.drop", "site.focus.setup"):
                self.obs(metric, period, unit="percent", query=None, reason=why,
                         population="Inside;focus-site;nontest")
            return
        rows = self.rows("Q15", "current") if period == "current" else []
        qid = self.qid_for("Q15", "current")
        if period != "current" or not rows:
            why = (f"{qid}: the focus-site daily detail is collected for week S only."
                   if period == "previous" else f"{qid}: no row returned for {focus}.")
            for metric in ("site.focus.drop", "site.focus.setup"):
                self.obs(metric, period, unit="percent", query=None, reason=why,
                         population=f"Inside;{focus};nontest")
            return
        self.obs("site.focus.drop", period, numerator=total(rows, "Dropped"),
                 denominator=total(rows, "Established"), query=qid,
                 population=f"Inside;{focus};nontest", definition="dropped / established",
                 grain="stream", aggregation="ratio_of_counts",
                 reason=f"{qid}: no reliability counts for {focus}.")
        self.obs("site.focus.setup", period, numerator=total(rows, "Failed"),
                 denominator=total(rows, "CDR"), query=qid,
                 population=f"Inside;{focus};nontest", definition="failed / CDR",
                 grain="stream", aggregation="ratio_of_counts",
                 reason=f"{qid}: no setup counts for {focus}.")

    # -- daily and unmapped --------------------------------------------------
    def daily(self):
        rows = self.rows("Q2")
        qid = self.qid_for("Q2")
        measured = {str(dim(r, "Date"))[:10]: r for r in rows}
        start = date.fromisoformat(self.periods["previous"][0])
        out = []
        for offset in range(14):
            day = (start + timedelta(days=offset)).isoformat()
            row = measured.get(day)
            out.append({
                "date": day,
                "streams": num(row, "Streams") if row else None,
                "cdr": num(row, "CDR") if row else None,
                "failed": num(row, "Failed") if row else None,
                "established": num(row, "Established") if row else None,
                "dropped": num(row, "Dropped") if row else None,
                "query_id": qid, "population_key": "tenant;nontest",
                "reason": None if row else f"{qid} returned no row for this date.",
            })
        return out

    def unmapped(self):
        rows = self.rows("Q18", "current")
        qid = self.qid_for("Q18", "current")
        private = [r for r in rows if is_rfc1918(dim(r, "Second Subnet"))]
        return {
            "name": "Private ranges carrying traffic but absent from the Building File",
            "streams": total(private, "Streams"), "dropped": None,
            "established": None, "failed": None, "previous": None,
            "query_id": qid, "population_key": "non-inside;rfc1918;nontest",
            "reason": ("Lower bound: Q18 ranks only the busiest non-Inside subnets (top 30), "
                       "counting the private 10/8 and 172.16/12 ranges; a mapped range would "
                       "be classified Inside."),
            "scope": {"media": "All", "scenario": "Conf+P2P", "direction": "all reported",
                      "endpoint_anchor": "Second", "network_scope": "Outside"},
        }

    # ---------------------------------------------------------------- extensions
    @staticmethod
    def row(period, cohort, population, query_id, streams, scope, dimensions, measures, reason=None):
        return {
            "period": period, "cohort_key": cohort, "population_key": population,
            "query_id": query_id, "streams": streams, "reason": reason,
            "scope": scope, "dimensions": dimensions, "measures": measures,
        }

    @staticmethod
    def count(native, value):
        return {"native_name": native, "value": value, "unit": "count",
                "numerator": value, "denominator": None,
                "denominator_definition": None, "reason": None, "aggregation": "count"}

    @staticmethod
    def rate(native, numerator, denominator, definition, unit="percent"):
        value = ratio(numerator, denominator, 100.0 if unit == "percent" else 1.0)
        if value is not None:
            reason = None
        elif denominator == 0:
            # The counts are present and both zero: the cohort has no eligible
            # population, which is a finding rather than a collection failure.
            reason = "No eligible population: the model reports zero True and zero False here."
        else:
            reason = "Counts absent from the collected result."
        return {"native_name": native, "value": value, "unit": unit,
                "numerator": numerator, "denominator": denominator,
                "denominator_definition": definition,
                "reason": reason, "aggregation": "ratio_of_counts"}

    @staticmethod
    def native(native, value, unit):
        return {"native_name": native, "value": value, "unit": unit,
                "numerator": None, "denominator": None,
                "denominator_definition": None,
                # The source already aggregated this figure, so it has no
                # numerator of its own; the reason records that explicitly.
                "reason": ("Source-aggregated value: it carries no numerator or denominator."
                           if value is not None else
                           "Native value absent from the collected result."),
                "aggregation": "native"}

    def scope(self, media="All", scenario="Conf+P2P", direction="all reported",
              anchor="Second", network="all"):
        return {"media": media, "scenario": scenario, "direction": direction,
                "endpoint_anchor": anchor, "network_scope": network}

    def envelope(self, rows, query_ids, reason_when_empty, extra_reason=None,
                 core_mapping=False):
        """Status derived from the rows, never declared.

        `complete` means every row carries a stream count, a fully stated scope
        and a resolved value for each of its measures. One unresolved cell makes
        the family `partial` with a reason, which is the honest reading.
        """
        ids = sorted({q for q in query_ids if q})
        q_by_id = {q["id"]: q for q in self.queries}
        failed_errors = [f"{qid}: {q_by_id[qid]['reason']}" for qid in ids
                         if qid in q_by_id and q_by_id[qid]["status"] in ("failed", "rejected")
                         and q_by_id[qid].get("reason")]
        if core_mapping and failed_errors:
            return {"status": "not_collected", "reason": "; ".join(dict.fromkeys(failed_errors)),
                    "query_ids": ids, "rows": []}
        if not rows:
            unsupported_errors = [q_by_id[qid]["reason"] for qid in ids
                                  if qid in q_by_id and q_by_id[qid]["status"] == "unsupported"
                                  and q_by_id[qid].get("reason")]
            if unsupported_errors:
                return {"status": "unsupported", "reason": "; ".join(dict.fromkeys(unsupported_errors)),
                        "query_ids": ids, "rows": []}
            if failed_errors:
                return {"status": "failed", "reason": "; ".join(dict.fromkeys(failed_errors)),
                        "query_ids": ids, "rows": []}
            executed = [qid for qid in ids
                        if qid in q_by_id and q_by_id[qid]["status"] in ("complete", "partial")]
            if executed:
                return {"status": "partial", "reason": reason_when_empty,
                        "query_ids": ids, "rows": []}
            return {"status": "not_collected", "reason": reason_when_empty,
                    "query_ids": ids, "rows": []}

        unresolved = []
        for row in rows:
            if row["streams"] is None:
                unresolved.append("stream counts")
            if any(value is None for value in row["scope"].values()):
                unresolved.append("scope fields")
            for name, measure in row["measures"].items():
                if measure["value"] is None:
                    unresolved.append(name)
        if extra_reason:
            return {"status": "partial", "reason": extra_reason, "query_ids": ids, "rows": rows}
        unverified_notes = [
            f"{qid} ({q_by_id[qid]['status']}): {q_by_id[qid].get('reason') or 'incomplete query evidence'}"
            for qid in ids
            if qid in q_by_id and (q_by_id[qid]["status"] != "complete" or q_by_id[qid].get("truncated") is not False)
        ]
        if unverified_notes:
            return {"status": "partial", "reason": "; ".join(dict.fromkeys(unverified_notes)),
                    "query_ids": ids, "rows": rows}
        periods_present = {row.get("period") for row in rows if row.get("period") in ("previous", "current")}
        if periods_present and periods_present != {"previous", "current"}:
            only_period = next(iter(periods_present))
            other_period = "previous" if only_period == "current" else "current"
            return {"status": "partial",
                    "reason": f"Rows were returned for {only_period} week only; {other_period} week returned no rows.",
                    "query_ids": ids, "rows": rows}
        if unresolved:
            missing = ", ".join(sorted(set(unresolved))[:4])
            return {"status": "partial",
                    "reason": f"Collected, but some rows have no measured {missing}; each row states why.",
                    "query_ids": ids, "rows": rows}
        return {"status": "complete", "reason": None, "query_ids": ids, "rows": rows}

    def ext_reliability_inside(self):
        mapping = self.mapping_state()
        if mapping["inside_unavailable"]:
            return {"status": "unsupported", "reason": mapping["inside_reason"],
                    "query_ids": sorted({q for q in ("MAPPING", self.qid_for("Q3")) if q}),
                    "rows": []}
        rows, ids, seen_days = [], [self.qid_for("Q3")], set()
        for row in self.rows("Q3"):
            day = str(dim(row, "Date"))[:10]
            seen_days.add(day)
            period = "current" if day >= self.periods["current"][0] else "previous"
            rows.append(self.row(
                period, f"inside|{day}", "Inside;daily;nontest", ids[0], num(row, "Streams"),
                self.scope(media="All", scenario="All", network="Inside"),
                {"date": day},
                {name: self.count(native, num(row, alias)) for name, native, alias in (
                    ("streams", "Total Stream Count", "Streams"),
                    ("cdr", "Total CDR Available Stream Count", "CDR"),
                    ("failed", "Total Call Setup Failed Stream Count", "Failed"),
                    ("established", "Total Call Setup Succeeded Stream Count", "Established"),
                    ("dropped", "Total Call Dropped Stream Count", "Dropped"))},
                reason=None if num(row, "Streams") is not None else "No Inside traffic reported on this date."))
        sparse_reason = (f"Q3 returned Inside traffic on {len(seen_days)} of 14 calendar days; "
                         "zero-traffic days emit no row."
                         if 0 < len(seen_days) < 14 else None)
        return self.envelope(rows, ids, "Q3 returned no Inside daily rows.",
                             extra_reason=sparse_reason, core_mapping=True)

    def ext_media_classifiers(self):
        rows, ids = [], []
        for period in ("previous", "current"):
            source = self.rows("Q4", period)
            qid = self.qid_for("Q4", period)
            ids.append(qid)
            for classifier, (t_alias, f_alias, n_alias) in CLASSIFIERS.items():
                media_list = ["Audio"] if classifier in AUDIO_ONLY else ["Audio", "Video", "VBSS"]
                scenarios = ["Conf"] if classifier in CONF_ONLY else ["Conf", "P2P"]
                for media in media_list:
                    for scenario in scenarios:
                        selected = [r for r in source if dim(r, "Media Type") == media
                                    and dim(r, "Session Type") == scenario]
                        true_count = total(selected, t_alias)
                        false_count = total(selected, f_alias) if f_alias else None
                        null_count = total(selected, n_alias) if n_alias else None
                        eligible = None if true_count is None or false_count is None else true_count + false_count
                        streams = None
                        if eligible is not None:
                            streams = eligible + (null_count or 0)
                        rows.append(self.row(
                            period, f"clf|{classifier}|{media}|{scenario}",
                            f"{classifier};{media};{scenario};nontest", qid, streams,
                            self.scope(media=media, scenario=scenario),
                            {"classifier": classifier},
                            {"problem_rate": self.rate("Detected Problem Rate", true_count, eligible,
                                                       "True + False classified streams"),
                             "true_count": self.count("True Count", true_count),
                             "false_count": self.count("False Count", false_count),
                             "null_count": self.count("Null Count", null_count)},
                            reason=None if streams is not None else
                            f"{qid} does not expose False/Null counts for {classifier}."))
        return self.envelope(rows, ids, "Q4 returned no classifier counts.")

    def ext_sites(self):
        mapping = self.mapping_state()
        if mapping["sites_unavailable"]:
            return {"status": "unsupported", "reason": mapping["sites_reason"],
                    "query_ids": sorted({"MAPPING", *mapping["q14_ids"]}), "rows": []}
        rows, ids = [], []
        for period in ("previous", "current"):
            qid = self.qid_for("Q14", period)
            ids.append(qid)
            for row in self._grouped_q14(period):
                name = row["name"]
                rows.append(self.row(
                    period, f"site|{name}", "Inside;Conf+P2P;top10;nontest", qid,
                    row["Streams"],
                    self.scope(network="Inside"),
                    {"site": name, "country": row["country"], "population_kind": "all_site"},
                    {"streams": self.count("Total Stream Count", row["Streams"]),
                     "dropped": self.count("Total Call Dropped Stream Count", row["Dropped"]),
                     "established": self.count("Total Call Setup Succeeded Stream Count", row["Established"]),
                     "failed": self.count("Total Call Setup Failed Stream Count", row["Failed"]),
                     "cdr": self.count("Total CDR Available Stream Count", row["CDR"]),
                     "drop_rate": self.rate("Total Call Dropped Failure Percentage",
                                            row["Dropped"], row["Established"],
                                            "dropped / established"),
                     "setup_rate": self.rate("Total Call Setup Failure Percentage",
                                             row["Failed"], row["CDR"], "failed / CDR")}))
        return self.envelope(rows, ids, "Q14 returned no site ranking.",
                             core_mapping=True)

    def ext_clients(self):
        rows, ids = [], []
        for period in ("previous", "current"):
            qid = self.qid_for("Q13", period)
            ids.append(qid)
            for row in self.rows("Q13", period):
                version = dim(row, "Second Client App Version")
                if not version:
                    continue
                age = dim(row, "Second Client App Version Age")
                rows.append(self.row(
                    period, f"version|{version}|{age or 'unreported'}", "teams21windows;versions;nontest", qid,
                    num(row, "Streams"), self.scope(),
                    {"client": "Microsoft Teams 2.1 Windows",
                     # windowsAge() keys on client_category; Q13 is filtered to
                     # that exact category, so this states the query's own filter.
                     "client_category": "Microsoft Teams 2.1 Windows", "version": version,
                     "version_age": age},
                    {"streams": self.count("Total Stream Count", num(row, "Streams")),
                     "users": self.count("Second User Count", num(row, "Users")),
                     "dropped": self.count("Total Call Dropped Stream Count", num(row, "Dropped")),
                     "psr": self.rate("Audio Poor Percentage", num(row, "APoor"),
                                      (num(row, "AGood") or 0) + (num(row, "APoor") or 0)
                                      if num(row, "AGood") is not None else None,
                                      "Good + Poor classified streams")}))
        return self.envelope(rows, ids, "Q13 returned no client versions.")

    def ext_vdi(self):
        rows, ids = [], []
        for period in ("previous", "current"):
            qid = self.qid_for("Q12", period)
            ids.append(qid)
            for row in self.rows("Q12", period):
                mode = dim(row, "Second Client VDI Mode")
                state = dim(row, "Second Client VDI Is Optimized")
                if not mode and not state:
                    continue
                mode = mode or "Unspecified"
                rows.append(self.row(
                    period, f"vdi|{mode}|{dim(row, 'Second Client VDI Provider Version')}",
                    "vdi;nontest", qid, num(row, "Streams"), self.scope(),
                    {"vdi_state": state, "vdi_mode": mode,
                     "provider_version": dim(row, "Second Client VDI Provider Version")},
                    {"streams": self.count("Total Stream Count", num(row, "Streams")),
                     "dropped": self.count("Total Call Dropped Stream Count", num(row, "Dropped"))}))
        return self.envelope(rows, ids, "Q12 returned no VDI rows.")

    def ext_p2p_pairs(self):
        rows, ids = [], []
        for period in ("previous", "current"):
            qid = self.qid_for("Q6", period)
            ids.append(qid)
            for row in self.rows("Q6", period):
                pair = str(dim(row, "Inside Corp Pair") or "")
                parts = [p.strip() for p in pair.split(":")] if ":" in pair else [None, None]
                good, poor = num(row, "AGood"), num(row, "APoor")
                eligible = None if good is None or poor is None else good + poor
                rows.append(self.row(
                    period, f"p2p|{dim(row, 'Connectivity Ice Pair')}|{pair}",
                    "P2P;ice-pairs;nontest", qid, num(row, "Streams"),
                    self.scope(media="Audio", scenario="P2P", anchor="Both"),
                    {"first_scope": parts[0] or None, "second_scope": parts[1] or None,
                     "selected_ice_path": dim(row, "Connectivity Ice Pair"),
                     "pair_grain": "scope_pair"},
                    {"psr": self.rate("Audio Poor Percentage", poor, eligible,
                                      "Good + Poor classified streams"),
                     "classifier": self.rate("Detected Inbound Network Problem Rate",
                                             num(row, "InT"),
                                             (num(row, "InT") or 0) + (num(row, "InF") or 0)
                                             if num(row, "InT") is not None else None,
                                             "True + False classified streams")}))
        return self.envelope(rows, ids, "Q6 returned no P2P pair rows.")

    def ext_regional_routing(self):
        rows, ids = [], []
        for period in ("previous", "current"):
            qid = self.qid_for("Q19", period)
            ids.append(qid)
            for row in self.rows("Q19", period):
                site = dim(row, "Second Building Name")
                server = dim(row, "First ASN Country")
                rows.append(self.row(
                    period, f"route|{site}|{server}", "Conf;First-to-Second;routing;nontest",
                    qid, num(row, "Streams"),
                    self.scope(scenario="Conf", direction="First-to-Second"),
                    {"user_country": dim(row, "Second ASN Country"), "user_site": site,
                     "user_location_basis": "building_mapping" if site else "asn_proxy",
                     "egress": None, "media_endpoint": server, "media_region": server,
                     "media_location_basis": "asn_proxy", "endpoint_role": "conference_server",
                     "exception_context": None, "media_country": server,
                     "media_country_basis": "asn_proxy",
                     "user_country_basis": "asn_proxy"},
                    {"rtt_avg": self.native("Avg Round Trip", num(row, "RTT"), "ms"),
                     "rtt_max_avg": self.native("Avg Round Trip Max", num(row, "RTTMax"), "ms"),
                     "streams": self.count("Total Stream Count", num(row, "Streams"))},
                    reason=None if site else "Building name absent; the origin is an ASN estimate."))
        return self.envelope(
            rows, ids, "Q19 returned no routing pairs.",
            extra_reason=("Serving endpoints are identified by First ASN Country, an estimate. "
                          "Validated datacenter identity is not available from this model, so the "
                          "family cannot be complete."))

    def ext_direction_comparison(self):
        rows, ids = [], []
        for period in ("previous", "current"):
            qid = self.qid_for("Q10", period)
            ids.append(qid)
            for row in self.rows("Q10", period):
                direction = dim(row, "Stream Direction")
                conn = dim(row, "Second Network Connection Detail")
                rows.append(self.row(
                    period, f"dir|{conn}|{direction}|{dim(row, 'Session Type')}",
                    f"Audio;{dim(row, 'Session Type')};{conn};nontest", qid, None,
                    self.scope(media="Audio", scenario=dim(row, "Session Type") or "Conf+P2P",
                               direction=direction),
                    {"connection": conn, "direction": direction},
                    {"rtt_avg": self.native("Avg Round Trip", num(row, "RTT"), "ms"),
                     "jitter_avg": self.native("Avg Jitter", num(row, "Jitter"), "ms"),
                     "loss_avg": self.native("Avg Packet Loss Rate", num(row, "Loss"), "ratio")},
                    reason="Native means carry no stream denominator."))
        matched = collections.defaultdict(set)
        for row in rows:
            key = (row["period"], row["population_key"], row["dimensions"]["connection"])
            matched[key].add(row["scope"]["direction"])
        unpaired = [k for k, v in matched.items() if v != {"First-to-Second", "Second-to-First"}]
        return self.envelope(
            rows, ids, "Q10 returned no directional network rows.",
            extra_reason=("Native means carry no stream denominator, and "
                          f"{len(unpaired)} cohort(s) lack a matched opposite direction."
                          if unpaired else
                          "Native means carry no stream denominator, so rows stay unweighted."))

    def ext_tcp_fallback(self):
        """Q45: conference streams that fell back to TCP, by second subnet.

        One query returns both the TCP count and the subnet's whole conference
        volume, so the share is exact and the earlier week compares on the same
        subnet key instead of on a media/scenario cohort.
        """
        rows, ids = [], []
        for period in ("previous", "current"):
            qid = self.qid_for("Q45", period)
            if not qid:
                continue
            ids.append(qid)
            for row in self.rows("Q45", period):
                subnet = dim(row, "Second Subnet")
                tcp, streams = num(row, "Tcp"), num(row, "Streams")
                if tcp is None or not tcp:
                    continue
                rows.append(self.row(
                    period, f"tcpfallback|{subnet}", "Conf;tcp-fallback;nontest",
                    qid, streams,
                    self.scope(scenario="Conf"),
                    {"subnet": subnet, "site": dim(row, "Second Building Name")},
                    {"tcp_streams": self.count("Total Stream Count", tcp),
                     "streams": self.count("Total Stream Count", streams),
                     "tcp_share": self.rate("Total Stream Count", tcp, streams,
                                            "TCP streams / conference streams of the subnet")}))
        return self.envelope(
            rows, ids,
            "Q45 returned no conference stream on a TCP transport.",
            extra_reason=("Ranked on TCP stream count and truncated: the subnets "
                          "below the cut-off are not listed, so this is a ranking "
                          "and not the full set of subnets using TCP."))

    def ext_vpn(self):
        rows, ids = [], []
        for period in ("previous", "current"):
            qid = self.qid_for("Q11", period)
            ids.append(qid)
            for row in self.rows("Q11", period):
                good, poor = num(row, "AGood"), num(row, "APoor")
                eligible = None if good is None or poor is None else good + poor
                rows.append(self.row(
                    period, f"vpn|{dim(row, 'Second VPN Estimated')}|{dim(row, 'Second Network Mapped VPN')}",
                    "Audio;vpn-partition;nontest", qid, num(row, "Streams"),
                    self.scope(media="Audio"),
                    {"vpn_estimated": dim(row, "Second VPN Estimated"),
                     "vpn_mapped": dim(row, "Second Network Mapped VPN")},
                    {"streams": self.count("Total Stream Count", num(row, "Streams")),
                     "psr": self.rate("Audio Poor Percentage", poor, eligible,
                                      "Good + Poor classified streams")}))
        rows, ids = self.ext_vpn_mapped(rows, ids)
        return self.envelope(rows, ids, "Q11 returned no VPN rows.")

    def ext_vpn_mapped(self, rows, ids):
        """Q44: Mapped VPN by medium, the native replacement for Estimated VPN.

        `Second UPN` returns only blank and `*` in this model, so the per-user
        column stays uncollected rather than being filled with a stand-in.
        """
        for period in ("previous", "current"):
            qid = self.qid_for("Q44", period)
            if not qid:
                continue
            ids.append(qid)
            for row in self.rows("Q44", period):
                media = dim(row, "Media Type")
                if media not in ("Audio", "Video", "VBSS"):
                    continue
                mapped = dim(row, "Second Network Mapped VPN")
                rows.append(self.row(
                    period, f"mappedvpn|{media}|{mapped}",
                    f"{media};mapped-vpn;nontest", qid, num(row, "Streams"),
                    self.scope(media=media),
                    {"mapped_vpn": mapped, "upn": None},
                    {"streams": self.count("Total Stream Count", num(row, "Streams"))}))
        return rows, ids

    def ext_frame_rates(self):
        rows, ids = [], []
        for period in ("previous", "current"):
            qid = self.qid_for("Q21", period)
            ids.append(qid)
            for row in self.rows("Q21", period):
                media = dim(row, "Media Type")
                if media not in ("Video", "VBSS"):
                    continue
                rows.append(self.row(
                    period, f"fps|{media}|{dim(row, 'Stream Direction')}",
                    f"{media};frame-rate;nontest", qid, num(row, "Streams"),
                    self.scope(media=media, direction=dim(row, "Stream Direction")),
                    {"content_type": media},
                    {"frame_rate": self.native("Avg Video Frame Rate", num(row, "FrameRate"), "fps"),
                     # `_avg` marks this as a source-computed mean: it is a
                     # percentage without a numerator of its own.
                     "frame_loss_avg": self.native("Avg Video Local Frame Loss Percentage",
                                                   num(row, "FrameLoss"), "percent"),
                     "streams": self.count("Total Stream Count", num(row, "Streams"))}))
        return self.envelope(rows, ids, "Q21 returned no frame-rate rows.")

    def ext_wifi_radio(self):
        rows, ids = [], []
        for period in ("previous", "current"):
            band_qid = self.qid_for("Q9", period)
            bssid_qid = self.qid_for("Q26", period)
            subnet_qid = self.qid_for("Q36", period)
            ids += [band_qid, bssid_qid, subnet_qid]
            for row in self.rows("Q9", period):
                band = dim(row, "Second Wifi Band")
                good, poor = num(row, "AGood"), num(row, "APoor")
                eligible = None if good is None or poor is None else good + poor
                rows.append(self.row(
                    period, f"band|{band}|{dim(row, 'Second Wifi Radio Type')}|{dim(row, 'Session Type')}",
                    "Audio;wifi;nontest", band_qid, num(row, "Streams"),
                    self.scope(media="Audio", scenario=dim(row, "Session Type") or "Conf+P2P"),
                    {"grain": "band_radio", "band": band,
                     "radio_type": dim(row, "Second Wifi Radio Type")},
                    {"streams": self.count("Total Stream Count", num(row, "Streams")),
                     "psr": self.rate("Audio Poor Percentage", poor, eligible,
                                      "Good + Poor classified streams"),
                     "jitter_avg": self.native("Avg Jitter", num(row, "Jitter"), "ms")}))
            for row in self.rows("Q26", period):
                roaming_val = num(row, "Roaming")
                roaming_measure = self.count("Total Second Roaming Count", roaming_val)
                if roaming_val is None:
                    roaming_measure["reason"] = (
                        (self.results.get(bssid_qid) or {}).get("error")
                        or "Total Second Roaming Count is not exposed by this semantic model."
                    )
                rows.append(self.row(
                    period, f"bssid|{dim(row, 'Second BSSID')}|{dim(row, 'Second Building Name')}",
                    "Audio;wifi-bssid;nontest", bssid_qid, num(row, "Streams"),
                    self.scope(media="Audio"),
                    {"grain": "bssid", "bssid": dim(row, "Second BSSID"),
                     "site": dim(row, "Second Building Name")},
                    {"streams": self.count("Total Stream Count", num(row, "Streams")),
                     "roaming": roaming_measure,
                     "poor": self.count("Audio Poor Stream Count", num(row, "APoor"))}))
            # The 2.4 GHz panel reads this grain. Q36 returns, per subnet, the
            # whole Wi-Fi audio volume and the 2.4 GHz subset with its good/poor
            # counts, so the share and the PSR are exact instead of depending on
            # which rows happened to survive a ranking.
            for row in self.rows("Q36", period):
                subnet = dim(row, "Second Subnet")
                band24, total = num(row, "B24"), num(row, "Streams")
                if not subnet or not band24:
                    continue
                good, poor = num(row, "Good24"), num(row, "Poor24")
                eligible = None if good is None or poor is None else good + poor
                rows.append(self.row(
                    period, f"subnet24|{subnet}",
                    "Audio;wifi-subnet-24;nontest", subnet_qid, band24,
                    self.scope(media="Audio"),
                    {"grain": "subnet_24ghz", "band": "2.4 Ghz", "subnet": subnet,
                     "site": dim(row, "Second Building Name"),
                     "country": dim(row, "Second Country")},
                    {"streams": self.count("Total Stream Count", band24),
                     "wifi_streams": self.count("Total Stream Count", total),
                     "band_share": self.rate("Total Stream Count", band24, total,
                                             "2.4 GHz streams / Wi-Fi audio streams of the subnet"),
                     "psr": self.rate("Audio Poor Percentage", poor, eligible,
                                      "Good + Poor classified 2.4 GHz streams")}))
        return self.envelope(
            rows, ids, "Q9, Q26 and Q36 returned no Wi-Fi radio rows.",
            extra_reason=("Band and radio-type totals are complete; the per-subnet "
                          "2.4 GHz rows are ranked on 2.4 GHz volume and truncated, "
                          "so the subnets below the cut-off are not listed."))

    def ext_qos(self):
        rows, ids = [], []
        for period in ("previous", "current"):
            qid = self.qid_for("Q22", period)
            ids.append(qid)
            for row in self.rows("Q22", period):
                direction = dim(row, "Stream Direction") or "all reported"
                rows.append(self.row(
                    period, f"qos|{dim(row, 'Second QoS Applied')}|{dim(row, 'Second QoS Value')}|{direction}",
                    "qos-partition;nontest", qid, num(row, "Streams"),
                    self.scope(direction=direction),
                    {"qos_applied": dim(row, "Second QoS Applied"),
                     "dscp": dim(row, "Second QoS Value")},
                    {"streams": self.count("Total Stream Count", num(row, "Streams")),
                     "dropped": self.count("Total Call Dropped Stream Count", num(row, "Dropped"))}))
        return self.envelope(rows, ids, "Q22 returned no QoS rows.")

    def ext_peripherals(self):
        rows, ids = [], []
        for period in ("previous", "current"):
            qid = self.qid_for("Q23", period)
            ids.append(qid)
            for row in self.rows("Q23", period):
                device = dim(row, "Second Capture Dev Name")
                form = dim(row, "Second Capture Device Form Factor")
                good, poor = num(row, "AGood"), num(row, "APoor")
                eligible = None if good is None or poor is None else good + poor
                rows.append(self.row(
                    period, f"device|{device}|{form}", "Audio;capture-device;nontest", qid,
                    num(row, "Streams"), self.scope(media="Audio"),
                    {"device": device, "form_factor": form},
                    {"streams": self.count("Total Stream Count", num(row, "Streams")),
                     "psr": self.rate("Audio Poor Percentage", poor, eligible,
                                      "Good + Poor classified streams")}))
        return self.envelope(rows, ids, "Q23 returned no capture-device rows.")

    def ext_user_feedback(self):
        rows, ids = [], []
        for period in ("previous", "current"):
            qid = self.qid_for("Q20", period)
            ids.append(qid)
            for row in self.rows("Q20", period):
                rating = dim(row, "Second Feedback Rating")
                count = num(row, "RatingCount")
                if rating in (None, "", "0") or not count:
                    continue
                rows.append(self.row(
                    period, f"rating|{rating}", "feedback;rated-stream;nontest", qid, count,
                    self.scope(), {"rating": rating},
                    {"rating_avg": {"native_name": "Second Feedback Rating Avg",
                                    "value": float(rating), "unit": "count",
                                    "numerator": None, "denominator": count,
                                    "denominator_definition": "responses carrying this rating",
                                    "reason": None, "aggregation": "native"},
                     "rating_count": self.count("Second Feedback Rating Count", count),
                     "poor_count": self.count("Second Feedback Rating Poor Count", num(row, "PoorCount"))}))
        return self.envelope(rows, ids, "Q20 returned no rated responses.")

    def extensions(self):
        return {
            "sites": self.ext_sites(),
            "clients": self.ext_clients(),
            "vdi": self.ext_vdi(),
            "p2p-pairs": self.ext_p2p_pairs(),
            "regional-routing": self.ext_regional_routing(),
            "direction-comparison": self.ext_direction_comparison(),
            "vpn": self.ext_vpn(),
            "tcp-fallback": self.ext_tcp_fallback(),
            "frame-rates": self.ext_frame_rates(),
            "wifi-radio": self.ext_wifi_radio(),
            "qos": self.ext_qos(),
            "peripherals": self.ext_peripherals(),
            "user-feedback": self.ext_user_feedback(),
            "reliability-inside": self.ext_reliability_inside(),
            "media-classifiers": self.ext_media_classifiers(),
        }

    # ---------------------------------------------------------------- pulse cards
    def pulse(self):
        """Summary cards the briefing reads directly.

        Each one restates figures already collected, in the compact shape the
        template verifies. Nothing new is measured here.
        """
        out = {"wifiMix": {}, "weeklyConf": {}, "clientVersions": {}, "volume": {}}

        for period in ("previous", "current"):
            # Usage volumes the briefing shows beside the quality tiles. Q1 gives
            # call counts per scenario, Q34 gives stream counts per medium; both
            # are already collected, so this restates them and measures nothing.
            call_qid = self.qid_for("Q1", period)
            calls = {}
            for row in self.rows("Q1", period):
                scenario = dim(row, "Session Type")
                if scenario in ("Conf", "P2P"):
                    calls[scenario] = num(row, "Calls")
            stream_qid = self.qid_for("Q34", period)
            streams = {}
            for row in self.rows("Q34", period):
                media = dim(row, "Media Type")
                value = num(row, "Streams")
                if media in ("Audio", "Video", "VBSS") and value is not None:
                    streams[media] = streams.get(media, 0) + value
            out["volume"][period] = {
                "calls": {"Conf": calls.get("Conf"), "P2P": calls.get("P2P"),
                          "query_id": call_qid,
                          "definition": "Total Call Count per Session Type"},
                "streams": {"Audio": streams.get("Audio"), "Video": streams.get("Video"),
                            "VBSS": streams.get("VBSS"), "query_id": stream_qid,
                            "definition": "Total Stream Count per Media Type, "
                                          "meetings and 1:1 combined"},
            }

            # Wi-Fi band mix, from the Q9 band grouping.
            qid = self.qid_for("Q9", period)
            bands = {"2.4": 0, "5": 0, "6": 0, "unknown": 0, "other": 0}
            for row in self.rows("Q9", period):
                raw = str(dim(row, "Second Wifi Band") or "").lower().replace("ghz", "").replace(",", ".").strip()
                bucket = ("2.4" if raw.startswith("2") else "5" if raw.startswith("5")
                          else "6" if raw.startswith("6") else "unknown" if not raw else "other")
                bands[bucket] += num(row, "Streams") or 0
            band_total = sum(bands.values())
            if band_total:
                out["wifiMix"][period] = {
                    "complete": True, "denominatorKind": "all-wifi-streams",
                    "query_id": qid, "total": band_total, "bands": bands,
                }

            # Weekly CONF network means, from the Q10 Audio / Wi-Fi / First-to-Second row.
            net_qid = self.qid_for("Q10", period)
            selected = [r for r in self.rows("Q10", period)
                        if dim(r, "Second Network Connection Detail") == "Wifi"
                        and dim(r, "Session Type") == "Conf"
                        and dim(r, "Stream Direction") == "First-to-Second"]
            picked = {alias: next((num(r, alias) for r in selected if num(r, alias) is not None), None)
                      for alias in ("RTT", "Jitter", "Loss")}
            if any(value is not None for value in picked.values()):
                out["weeklyConf"][period] = {
                    "complete": True, "query_id": net_qid,
                    "population_key": "Audio;Conf;Wifi;First-to-Second;nontest",
                    "scope": {"scenario": "Conf", "media": "Audio", "direction": "First-to-Second",
                              "endpoint_anchor": "Second", "network_scope": "Wifi"},
                    "measures": {
                        "rtt": {"value": picked["RTT"], "unit": "ms", "aggregation": "native_mean",
                                "reason": None if picked["RTT"] is not None else "Not returned for this cohort."},
                        "jitter": {"value": picked["Jitter"], "unit": "ms", "aggregation": "native_mean",
                                   "reason": None if picked["Jitter"] is not None else "Not returned for this cohort."},
                        # Packet loss is a 0-1 ratio in this model, not a percentage.
                        "loss": {"value": picked["Loss"], "unit": "ratio", "aggregation": "native_mean",
                                 "reason": None if picked["Loss"] is not None else "Not returned for this cohort."},
                    },
                }

            # Client version age distribution, from Q13.
            ver_qid = self.qid_for("Q13", period)
            by_age = {}
            for row in self.rows("Q13", period):
                age = dim(row, "Second Client App Version Age") or "Unknown"
                bucket = by_age.setdefault(age, {"age": age, "streams": 0, "user_count": 0})
                bucket["streams"] += num(row, "Streams") or 0
                bucket["user_count"] += num(row, "Users") or 0
            version_rows = list(by_age.values())
            if version_rows:
                out["clientVersions"][period] = {
                    "complete": True, "dimension": "Second Client App Version Age", "grain": "stream",
                    "population_key": "teams21windows;version-age;nontest",
                    "period_label": "Week S" if period == "current" else "Week S-1",
                    "total": sum(r["streams"] for r in version_rows),
                    "total_users": sum(r["user_count"] for r in version_rows),
                    "query_id": ver_qid, "rows": version_rows,
                }

        # Unmapped private ranges, from Q18. `building` stays null because Q18
        # ranks non-Inside subnets, which by definition carry no building.
        qid = self.qid_for("Q18", "current")
        private = [r for r in self.rows("Q18", "current")
                   if is_rfc1918(dim(r, "Second Subnet"))]
        subnet_rows = [{"subnet": dim(r, "Second Subnet"), "streams": int(num(r, "Streams") or 0),
                        "building": None} for r in private if dim(r, "Second Subnet")]
        if subnet_rows:
            collected = sum(r["streams"] for r in subnet_rows)
            out["buildingData"] = {"current": {
                "complete": True, "selection": "top-by-streams", "rank_by": "streams_desc",
                "total": collected, "population_key": "non-inside;rfc1918;nontest",
                "query_id": qid, "rows": subnet_rows,
            }}
            tenant = self.observations.get("obs.usage.streams.all.current", {}).get("value")
            if tenant:
                out["unmapped"] = {"current": {
                    "complete": True, "localConfirmed": True, "query_id": qid,
                    "unmapped": collected, "total": int(tenant),
                }}
        return out

    # ---------------------------------------------------------------- coverage
    def coverage(self, extensions):
        family_of_extension = {"reliability-inside": "reliability",
                               "media-classifiers": "media-quality",
                               "tcp-fallback": "transport"}
        evidence = {family: set() for family in FAMILIES}
        for name, envelope in extensions.items():
            evidence[family_of_extension.get(name, name)].update(envelope["query_ids"])

        prefix_family = [
            ("usage.", "reliability"), ("setup.", "reliability"), ("drop.tenant", "reliability"),
            ("mce.", "reliability"), ("mediafail.", "reliability"), ("drop.conn", "reliability"),
            ("drop.media", "reliability"), ("drop.ua", "clients"),
            ("site.", "sites"), ("psr.audio.vpn", "vpn"), ("vpn.", "vpn"),
            ("psr.audio.ice", "p2p-pairs"), ("ice.", "p2p-pairs"),
            ("psr.audio.ua", "clients"), ("ver.", "clients"),
            ("net.", "network-subnets"), ("transport.", "transport"), ("wifi.", "wifi-bands"),
            ("cpu.", "compute-models"), ("vdi.", "vdi"),
            ("psr.", "media-quality"), ("clf.", "media-quality"), ("freeze.", "media-quality"),
        ]
        # `unmapped` is validated as a site record, so its evidence belongs here too.
        evidence["sites"].add(self.qid_for("Q18", "current"))
        evidence["sites"].add(self.qid_for("Q15", "current"))
        unresolved = {family: False for family in FAMILIES}
        has_obs_values = {family: False for family in FAMILIES}
        for item in self.observations.values():
            metric = item["native"]
            family = next((f for p, f in prefix_family if metric.startswith(p)), "reliability")
            if item["query"]:
                evidence[family].add(item["query"])
                if metric.startswith("drop.ua"):
                    evidence["reliability"].add(item["query"])
            if any(item.get(k) is not None for k in ("value", "numerator", "denominator")):
                has_obs_values[family] = True
            if item["value"] is None:
                unresolved[family] = True

        daily_rows = self.daily()
        if any(row["streams"] is None for row in daily_rows):
            unresolved["reliability"] = True
        focus_site, focus_daily = self.focus_daily()
        if focus_site is not None and (
            len(focus_daily) != 7 or any(
                row[k] is None for row in focus_daily for k in ("streams", "failed", "dropped")
            )
        ):
            unresolved["sites"] = True

        coverage = {}
        for family in FAMILIES:
            envelopes = [e for n, e in extensions.items() if family_of_extension.get(n, n) == family]
            incomplete = any(e["status"] != "complete" for e in envelopes)
            if family not in ("reliability", "sites", "media-quality", "network-subnets",
                              "wifi-bands", "compute-models", "transport"):
                if not has_obs_values[family] and envelopes and all(
                        e["status"] in ("unsupported", "failed") for e in envelopes):
                    coverage[family] = {
                        "status": envelopes[0]["status"],
                        "reason": envelopes[0]["reason"],
                        "query_ids": sorted(x for x in evidence[family] if x),
                    }
                    continue
            if family == "network-subnets":
                coverage[family] = {
                    "status": "partial",
                    "reason": ("Ranked top-offender subnet cohorts per medium and scenario, "
                               "reconciled against the twelve executed scope controls. Rows below "
                               "each cut-off are deliberately absent, so this family is a ranking "
                               "and never claims exhaustive subnet coverage."),
                    "query_ids": sorted((evidence[family] | self.investigation_evidence[family]
                                         | {self.qid_for("Q17", "current"),
                                            self.qid_for("Q17", "previous")}) - {None}),
                }
                continue
            if family in ("wifi-bands", "compute-models", "transport"):
                coverage[family] = {
                    "status": "partial",
                    "reason": ("Native aggregates plus a ranked investigation envelope: the "
                               "top cohorts are collected, the long tail is not."),
                    "query_ids": sorted(x for x in
                                        evidence[family] | self.investigation_evidence[family] if x),
                }
                continue
            if unresolved[family] or incomplete:
                env_reasons = [e["reason"] for e in envelopes if e.get("reason")]
                partial_reason = ("; ".join(dict.fromkeys(env_reasons))
                                  if env_reasons and not unresolved[family]
                                  else "At least one slot or day in this family has no measured value; see each entry's reason.")
                coverage[family] = {
                    "status": "partial",
                    "reason": partial_reason,
                    "query_ids": sorted(x for x in evidence[family] if x),
                }
            else:
                coverage[family] = {
                    "status": "complete",
                    # findings is empty, so every family states its own conclusion.
                    "reason": "Collected in full for both weeks; no reportable conclusion beyond the measured values.",
                    "query_ids": sorted(x for x in evidence[family] if x),
                }

        # An unpopulated Building File is a tenant state with its own evidence,
        # not unfinished collection. Only `partial` may carry measured values.
        mapping = self.mapping_state()
        if mapping["sites_unavailable"]:
            known = self.unmapped()["streams"] is not None
            coverage["sites"] = {
                "status": "partial" if known else "unsupported",
                "reason": (mapping["sites_reason"] + " Tenant-wide analyses are unaffected."
                           + (" Q18 still measures a lower bound of traffic on private ranges "
                              "that no building maps." if known else "")),
                "query_ids": sorted(set(coverage["sites"]["query_ids"]) | {"MAPPING"}),
            }
        if mapping["inside_unavailable"]:
            entry = coverage["reliability"]
            entry["status"] = "partial"
            entry["reason"] = (mapping["inside_reason"]
                               + " Tenant-wide reliability does not depend on the Building File."
                               + (" " + entry["reason"] if unresolved["reliability"] else ""))
            entry["query_ids"] = sorted(set(entry["query_ids"]) | {"MAPPING"})
        return coverage

    # ------------------------------------------------- bounded investigations
    # Q28-Q43 fill the subnet, TCP, compute-model and Wi-Fi location panels.
    # Each medium and scenario is split into two disjoint transport partitions,
    # because the TCP family carries about one stream in a thousand and never
    # surfaces in a ranking it shares with UDP. Both partitions are ranked,
    # truncated and reconciled against the matching Q34 control, so the report
    # offers a top-offender ranking and never claims the exhaustive subnet
    # enumeration that made earlier runs unaffordable.
    TCP_FAMILY = frozenset({"tcp", "tls", "turntcp", "multiturntcp", "compoundtcp"})
    SUBNET_PACK = (
        ("Q28", "Audio", "Conf", "other"), ("Q29", "Audio", "P2P", "other"),
        ("Q30", "Video", "Conf", "other"), ("Q31", "Video", "P2P", "other"),
        ("Q32", "VBSS", "Conf", "other"), ("Q33", "VBSS", "P2P", "other"),
    )

    def control_totals(self, period):
        """Q34: executed streams per media x scenario x transport partition.

        The two partitions sum exactly to the scope total, which is what lets a
        ranked batch declare a control without overstating its coverage.
        """
        totals = {}
        for row in self.rows("Q34", period):
            media, scenario = dim(row, "Media Type"), dim(row, "Session Type")
            streams = num(row, "Streams")
            if not media or not scenario or streams is None:
                continue
            protocol = (dim(row, "Second Transport Protocol") or "").lower()
            family = "tcp" if protocol in self.TCP_FAMILY else "other"
            for key in ((media, scenario, family), (media, scenario, "all")):
                totals[key] = totals.get(key, 0) + int(streams)
        return totals

    def batch(self, qid, period, population, extra=None):
        """A ranked, truncated batch: honest about being a top-N ranking."""
        key = f"{qid}_{PERIOD_TAG[period]}"
        rows = self.rows(qid, period)
        entry = self.results.get(key) or {}
        if entry.get("error") or not rows:
            return None
        batch = {
            "id": key,
            "period": period,
            "population_key": population,
            "status": "partial",
            "truncated": True,
            "dax": self.dax_for(key, period),
            "filters": self.query_filters(key, period),
            "rows": rows,
            "reason": "Ranked top-N cohorts, not an exhaustive enumeration.",
        }
        batch.update(extra or {})
        return batch

    def network_results(self):
        controls, queries, wifi_queries, cpu_queries = [], [], [], []
        control_query_id = {}
        evidence = self.investigation_evidence
        q_by_id = {q["id"]: q for q in self.queries}
        for period in ("previous", "current"):
            totals = self.control_totals(period)
            qid_34 = self.qid_for("Q34", period)
            control_query_id[period] = qid_34
            q_by_id = {q["id"]: q for q in self.queries}
            q34_meta = q_by_id.get(qid_34) if qid_34 else None
            q34_ok = bool(q34_meta and q34_meta["status"] == "complete")
            for media in ("Audio", "Video", "VBSS"):
                for scenario in ("Conf", "P2P"):
                    streams = totals.get((media, scenario, "all"), 0 if q34_ok else None)
                    control = {"period": period, "media": media, "scenario": scenario,
                               "query_id": qid_34, "streams": streams}
                    if not qid_34:
                        control["streams"] = None
                        control["status"] = "not_collected"
                        control["reason"] = ("Q34 was not collected for this period.")
                    elif q34_meta and q34_meta["status"] in ("failed", "unsupported"):
                        control["streams"] = None
                        control["status"] = q34_meta["status"]
                        control["reason"] = q34_meta.get("reason") or f"{qid_34} failed."
                    elif streams is None:
                        control["status"] = "not_collected"
                        control["reason"] = ("Q34 returned no executed total for this "
                                             "media and scenario.")
                    else:
                        control["status"] = "complete"
                    controls.append(control)

            control_dax = (self.dax_for(f"Q34_{PERIOD_TAG[period]}", period)
                           if control_query_id[period] else None)
            if control_query_id[period]:
                evidence["network-subnets"].add(control_query_id[period])
            for qid, media, scenario, family in self.SUBNET_PACK:
                # Both partitions share one population_key so their rows group
                # into the same location, which is what makes a TCP share a share
                # of that location's traffic rather than of itself.
                batch = self.batch(
                    qid, period,
                    f"{media};{scenario};subnet-detail;nontest",
                    {"media": media, "scenario": scenario,
                     "numeric_packet_loss_unit": "ratio",
                     "aggregation": "native",
                     "control_stream_count": totals.get((media, scenario, family), 0 if q34_ok else None),
                     "control_dax": control_dax,
                     "reason": ("Ranked top-N cohorts within the "
                                + ("TCP-family" if family == "tcp" else "non-TCP")
                                + " transport partition, not an exhaustive enumeration.")})
                if batch:
                    queries.append(batch)
                    evidence["network-subnets"].add(batch["id"])

            cpu = self.batch("Q35", period, "compute-models;nontest",
                             {"numeric_packet_loss_unit": "ratio",
                              "numeric_cpu_unit": "percent"})
            if cpu:
                cpu_queries.append(cpu)
                evidence["compute-models"].add(cpu["id"])

        if not (queries or wifi_queries or cpu_queries):
            return None
        results = {
            "schema_version": "mqa-investigation-results-v1",
            "report_name": self.raw.get("report") or self.report_name,
            "timezone": "UTC",
            "periods": self.periods,
            "strategy": "top_offenders",
            "selection": "top_offenders",
        }
        if queries:
            results["queries"] = queries
            results["scope_controls"] = controls
        if wifi_queries:
            results["wifi_queries"] = wifi_queries
        if cpu_queries:
            results["cpu_queries"] = cpu_queries
        return results

    # ---------------------------------------------------------------- assembly
    def build(self, customer, report):
        self.report_name = report
        for period in ("previous", "current"):
            self.reliability(period)
            self.media(period)
            self.network_context(period)
            self.ice(period)
            self.clients(period)
            self.wifi(period)
            self.netperf(period)
            self.vpn(period)
            self.vdi(period)
            self.diagnostics(period)
            self.poor_reasons(period)
            self.focus_observations(period)

        transport = {period: self.transport(period) for period in ("previous", "current")}
        versions = self.versions("current")
        self.versions("previous")
        focus_site, focus_daily = self.focus_daily()
        extensions = self.extensions()
        # The investigation pack registers its own queries, so it must run before
        # coverage accounts for the evidence each family actually used.
        network_results = self.network_results()

        data = {
            "schema_version": "mqa-dashboard-report-v2",
            "source": {"customer": customer, "report": report,
                       "extracted": self.raw.get("extracted")
                                    or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                       "access_mode": "fabric_iq"},
            "timezone": "UTC",
            "periods": self.periods,
            "observations": self.observations,
            "queries": self.queries,
            "daily": self.daily(),
            "sites": self.sites(),
            "unmapped": self.unmapped(),
            "transport": transport,
            "focusSite": focus_site,
            "focusDaily": focus_daily,
            "versions": versions,
            "siteLocations": [],
            "coverage": self.coverage(extensions),
            "extensions": extensions,
            "pulse": self.pulse(),
            "findings": [],
            "networkResults": network_results,
        }
        mapping = self.mapping_state()
        if mapping["mapping_unavailable"]:
            # The template turns this into a Building File recommendation alert.
            data["source"]["network_mapping"] = {
                "status": "unavailable", "reason": mapping["inside_reason"],
                "query_ids": [q for q in ("MAPPING", self.qid_for("Q3")) if q],
            }
        return data


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--raw", type=Path, default=Path("working/raw_results.json"))
    parser.add_argument("--out", type=Path, default=Path("dashboard-data.json"))
    parser.add_argument("--customer", default=None,
                        help="Customer display name; defaults to raw_results.json.")
    parser.add_argument("--report", default=None,
                        help="Source report identity; defaults to raw_results.json.")
    args = parser.parse_args(argv)

    if not args.raw.is_file():
        raise SystemExit(f"raw results not found: {args.raw}")
    raw = json.loads(args.raw.read_text(encoding="utf-8"))
    # Customer and report identity belong to the collected run, never to this
    # script: a shipped asset must not carry a customer name.
    customer = args.customer or raw.get("customer")
    report = args.report or raw.get("report")
    if not customer or not report:
        raise SystemExit("customer and report identity must be supplied by "
                         "raw_results.json or by --customer/--report")
    data = Assembler(raw).build(customer, report)
    args.out.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")

    measured = sum(1 for o in data["observations"].values() if o["value"] is not None)
    print(f"{len(data['observations'])} slots, {measured} mesures, "
          f"{len(data['queries'])} requetes, {args.out} "
          f"({args.out.stat().st_size / 1024:.0f} Ko)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
