"""Decimal arithmetic on query results; callers must verify populations and units."""

import argparse
import json
from decimal import Decimal, InvalidOperation, localcontext
from typing import Optional


Result = dict[str, Optional[str]]
HUNDRED = Decimal(100)
UNITS = ("percent", "ratio", "ms", "fps", "count")


def finite_nonnegative(value: Decimal) -> None:
    if not value.is_finite() or value < 0:
        raise ValueError("A finite, nonnegative source value is required.")


def fraction(numerator: Decimal, denominator: Decimal) -> Decimal:
    finite_nonnegative(numerator)
    finite_nonnegative(denominator)
    if denominator == 0:
        raise ValueError("A rate cannot be calculated with a zero denominator.")
    if numerator > denominator:
        raise ValueError("The numerator exceeds the eligible population; verify the definition.")
    return numerator / denominator


def text(value: Decimal) -> str:
    rendered = format(value, "f")
    if "." in rendered:
        rendered = rendered.rstrip("0").rstrip(".")
    return "0" if value == 0 else rendered


def rate(numerator: Decimal, denominator: Decimal) -> Result:
    with localcontext() as context:
        context.prec = 40
        value = fraction(numerator, denominator)
        return {
            "numerator": text(numerator),
            "denominator": text(denominator),
            "ratio": text(value),
            "percent": text(value * HUNDRED),
        }


def compare_rates(
    current_numerator: Decimal,
    current_denominator: Decimal,
    previous_numerator: Decimal,
    previous_denominator: Decimal,
) -> Result:
    with localcontext() as context:
        context.prec = 40
        current = fraction(current_numerator, current_denominator)
        previous = fraction(previous_numerator, previous_denominator)
        return {
            "current_percent": text(current * HUNDRED),
            "previous_percent": text(previous * HUNDRED),
            "delta_pp": text((current - previous) * HUNDRED),
            "relative_change_percent": (
                text((current / previous - 1) * HUNDRED) if previous != 0 else None
            ),
            "relative_change_status": "calculated" if previous != 0 else "baseline_zero",
            "affected_count_change": text(current_numerator - previous_numerator),
            "eligible_count_change": text(current_denominator - previous_denominator),
        }


def compare_values(current: Decimal, previous: Decimal, unit: str) -> Result:
    finite_nonnegative(current)
    finite_nonnegative(previous)
    if unit not in UNITS:
        raise ValueError(f"Unsupported unit: {unit}")
    if unit == "percent" and max(current, previous) > HUNDRED:
        raise ValueError("Percentage rates must be in the range 0 to 100.")
    if unit == "ratio" and max(current, previous) > 1:
        raise ValueError("Rate ratios must be in the range 0 to 1.")
    with localcontext() as context:
        context.prec = 40
        delta = current - previous
        delta_pp = delta if unit == "percent" else delta * HUNDRED if unit == "ratio" else None
        return {
            "unit": unit,
            "current": text(current),
            "previous": text(previous),
            "delta": text(delta),
            "delta_pp": text(delta_pp) if delta_pp is not None else None,
            "relative_change_percent": (
                text((current / previous - 1) * HUNDRED) if previous != 0 else None
            ),
            "relative_change_status": "calculated" if previous != 0 else "baseline_zero",
        }


def decimal_argument(value: str) -> Decimal:
    try:
        parsed = Decimal(value)
        finite_nonnegative(parsed)
    except (InvalidOperation, ValueError) as error:
        raise argparse.ArgumentTypeError(f"Invalid numeric value: {value}") from error
    return parsed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    rate_parser = commands.add_parser("rate")
    for field in ("numerator", "denominator"):
        rate_parser.add_argument(f"--{field}", type=decimal_argument, required=True)
    compare_parser = commands.add_parser("compare-rates")
    for field in (
        "current-numerator", "current-denominator", "previous-numerator", "previous-denominator"
    ):
        compare_parser.add_argument(f"--{field}", type=decimal_argument, required=True)
    values_parser = commands.add_parser("compare-values")
    values_parser.add_argument("--current", type=decimal_argument, required=True)
    values_parser.add_argument("--previous", type=decimal_argument, required=True)
    values_parser.add_argument("--unit", choices=UNITS, required=True)
    args = parser.parse_args()
    try:
        if args.command == "rate":
            result = rate(args.numerator, args.denominator)
        elif args.command == "compare-rates":
            result = compare_rates(
                args.current_numerator, args.current_denominator,
                args.previous_numerator, args.previous_denominator,
            )
        else:
            result = compare_values(args.current, args.previous, args.unit)
    except (ValueError, InvalidOperation) as error:
        parser.error(str(error))
    print(json.dumps(result, ensure_ascii=True, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
