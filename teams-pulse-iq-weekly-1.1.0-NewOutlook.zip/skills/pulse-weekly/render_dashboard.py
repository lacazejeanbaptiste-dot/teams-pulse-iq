"""Validate and render a complete Cowork Teams MQA Review report, using only Python's stdlib.

Usage:
  python render_dashboard.py --input dashboard-data.json --validate-only
  python render_dashboard.py --input dashboard-data.json --output report.html

The bundled schema and template normally sit beside this script. Source-tree
fallbacks are ../schemas/dashboard-report.schema.json and ../web/dashboard-template.html.
Nothing is collected, repaired, averaged, installed or sent over the network.
Exit codes: 0 accepted, 2 malformed/unsafe input or I/O, 3 unfinished final run.
--allow-unfinished-preview is an explicitly labelled local comparison, not a
completed Cowork assessment. It never relaxes arithmetic or file-safety checks.
"""

import argparse
import json
import math
import os
import re
import sys
import uuid
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone
from functools import lru_cache
from html import escape
from html.parser import HTMLParser
from pathlib import Path


SCHEMA_VERSION = "mqa-dashboard-report-v2"
MARKER = "__REPORT_DATA__"
MAX_SAFE_INTEGER = 9007199254740991
MAX_INPUT_BYTES = 128 * 1024 * 1024
PERIODS = ("previous", "current")
FAMILIES = (
    "reliability", "sites", "media-quality", "network-subnets", "transport",
    "wifi-bands", "compute-models", "clients", "vdi", "p2p-pairs",
    "regional-routing", "direction-comparison", "vpn", "frame-rates",
    "wifi-radio", "qos", "peripherals", "user-feedback",
)
EXTENSION_FAMILIES = (
    "sites", "clients", "vdi", "p2p-pairs", "regional-routing",
    "direction-comparison", "vpn", "frame-rates", "wifi-radio",
    "qos", "peripherals", "user-feedback", "reliability-inside", "media-classifiers",
    "tcp-fallback",
)
EXTENSION_COVERAGE = {"reliability-inside": "reliability", "media-classifiers": "media-quality", "tcp-fallback": "transport"}
MEDIA = ("Audio", "Video", "VBSS")
SCENARIOS = ("Conf", "P2P")
AUDIO_CONTEXTS = ("inside_wired", "inside_wifi", "outside_wired", "outside_wifi")
NETWORK_SCOPES = frozenset((period, media, scenario) for period in PERIODS for media in MEDIA for scenario in SCENARIOS)
CLASSIFIERS = (
    "media_modality", "inbound_network", "local_compute", "local_input_device",
    "uplink", "compute_device_causing", "input_device_causing",
    "other_user_uplink", "other_user_compute", "other_user_device",
)
INPUT_DEVICE_CLASSIFIERS = {"local_input_device", "input_device_causing", "other_user_device"}
CLASSIFIER_COMBINATIONS = frozenset(
    (classifier, media, scenario)
    for classifier in CLASSIFIERS for media in MEDIA for scenario in SCENARIOS
    if (classifier not in INPUT_DEVICE_CLASSIFIERS or media == "Audio") and
       (not classifier.startswith("other_user_") or scenario == "Conf")
)
STATUSES = ("complete", "partial", "failed", "unsupported", "not_collected")
UNFINISHED_QUERY_STATES = {"not_collected", "in_progress"}
UNUSABLE_QUERY_STATES = {"failed", "unsupported", "rejected"} | UNFINISHED_QUERY_STATES
METRIC_IDS = tuple("""
clf.inbound_network.tenant.conf clf.inbound_network.tenant.p2p
clf.media_modality.tenant.conf clf.uplink.tenant.conf
cpu.classifier.ua.conf.citrixvdi cpu.classifier.ua.conf.teams21windows
cpu.system_avg.ua.conf.teams21windows
drop.conn.conf.mobilebb drop.conn.conf.wifi drop.conn.conf.wired
drop.media.p2p.vbss drop.tenant.all drop.tenant.conf
drop.tenant.conf.cdr_mce drop.tenant.conf.cdr_not_mce drop.tenant.p2p
drop.ua.conf.teams21web drop.ua.conf.teams21windows drop.ua.conf.teamsrooms
freeze.tenant.conf freeze.tenant.p2p ice.p2p_relay_share
mce.conf.blank_outside mce.conf.wired_inside mce.share_drops.tenant.conf
mce.share_streams.tenant.conf mediafail.calls.tenant.conf
net.avg_jitter.netperf.conf.wifi.first_to_second
net.avg_round_trip.netperf.conf.wifi.first_to_second
net.avg_round_trip.netperf.conf.wired.first_to_second
net.avg_round_trip.netperf.p2p.wifi.first_to_second
net.avg_round_trip_max.netperf.conf.mobilebb.first_to_second
psr.audio.conn.all.inside_wired psr.audio.conn.all.inside_wifi
psr.audio.conn.all.outside_wired psr.audio.conn.all.outside_wifi
psr.audio.conn.p2p.inside_wired psr.audio.conn.p2p.outside_wifi
psr.audio.ice.p2p.direct_direct psr.audio.ice.p2p.direct_relay
psr.audio.reason_roundtrip.tenant.p2p psr.audio.tenant.all psr.audio.tenant.conf psr.audio.tenant.p2p
psr.audio.ua.conf.android psr.audio.ua.conf.ios psr.audio.ua.p2p.android
psr.audio.ua.p2p.teams21windows psr.audio.vpn.estimated psr.audio.vpn.flag0
psr.vbss.tenant.all psr.vbss.tenant.conf psr.vbss.tenant.p2p
psr.video.tenant.all psr.video.tenant.conf psr.video.tenant.p2p
setup.tenant.all setup.tenant.conf setup.tenant.p2p site.focus.drop site.focus.setup
transport.blank transport.tcpfamily transport.turntcp transport.udp
usage.calls.all usage.days usage.streams.all
vdi.citrix_versions vdi.inactive vdi.not_optimized vdi.optimized vdi.streams vdi.unknown
ver.drop.windows.primary ver.psr.windows.quality_focus ver.share.windows.primary
vpn.flag_share vpn.unknown_share
wifi.jitter.conf.24n wifi.jitter.conf.5ac wifi.psr.conf.24 wifi.psr.conf.5
wifi.psr.p2p.24 wifi.share.conf.24
""".split())
COUNT_METRICS = {
    "usage.calls.all", "usage.streams.all", "usage.days", "vdi.streams",
    "vdi.citrix_versions", "psr.audio.reason_roundtrip.tenant.p2p",
}
DAILY_COUNTS = ("streams", "cdr", "failed", "established", "dropped")
SITE_COUNTS = ("streams", "dropped", "established", "failed")
NETWORK_DIMENSIONS = (
    "Second Subnet", "Second Reflexive Local IP Network", "Second Building Name",
    "Second Inside Corp", "Second Network Connection Detail", "Stream Direction",
    "Second Transport Protocol", "Second ASN Country",
)
NETWORK_COUNTS = ("Streams", "Good", "Poor", "Unclassified", "CDR", "SetupFailed", "Established", "Dropped")
NETWORK_MEANS = ("JitterMs", "JitterMaxAvgMs", "PacketLoss", "PacketLossMaxAvg", "RoundTripMs", "RoundTripMaxAvgMs")
WIFI_DIMENSIONS = (
    "Session Type", "Second Subnet", "Second Reflexive Local IP Network",
    "Second Building Name", "Second ASN Country", "Second Inside Corp",
    "Stream Direction", "Second Wifi Band",
)
CPU_DIMENSIONS = (
    "Session Type", "Media Type", "Second User Agent Category",
    "Second Client App Version", "Second Compute Device Name", "Second CPU Name",
)
CANONICAL_UNITS = {
    "psr": {"percent", "ratio"}, "classifier": {"percent", "ratio"},
    "problem_rate": {"percent", "ratio"}, "caused_rate": {"percent", "ratio"},
    "true_count": {"count"}, "false_count": {"count"}, "null_count": {"count"},
    "setup_rate": {"percent", "ratio"}, "drop_rate": {"percent", "ratio"},
    "rtt_avg": {"ms"}, "rtt_max_avg": {"ms"},
    "jitter_avg": {"ms"}, "jitter_max_avg": {"ms"},
    "frame_rate": {"fps"}, "frame_rate_avg": {"fps"},
    "signal_strength": {"percent"}, "signal_strength_avg": {"percent"},
    "rating_avg": {"percent", "count", "score", "ratio"},
}


class DashboardError(ValueError):
    """An explicit local contract or rendering error."""


def _number(value):
    return type(value) in (int, float) and (type(value) is int or math.isfinite(value))


def _integer(value):
    return _number(value) and (type(value) is int or value.is_integer())


def _text(value):
    return isinstance(value, str) and bool(value.strip())


def _canonical(value):
    def normalized(item):
        if isinstance(item, dict):
            return {key: normalized(child) for key, child in item.items()}
        if isinstance(item, list):
            return [normalized(child) for child in item]
        if type(item) is float and math.isfinite(item) and item.is_integer():
            return int(item)
        return item
    return json.dumps(normalized(value), sort_keys=True, ensure_ascii=True, allow_nan=False, separators=(",", ":"))


def _no_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise DashboardError("Duplicate JSON property: " + key)
        result[key] = value
    return result


def _reject_constant(value):
    raise DashboardError("Nonfinite JSON number is not allowed: " + value)


def load_json(path):
    """Read UTF-8/BOM JSON, rejecting duplicate keys and NaN/Infinity."""
    path = Path(path)
    if not path.is_file():
        raise DashboardError("Input is not a regular file: " + str(path))
    with path.open("rb") as stream:
        content = stream.read(MAX_INPUT_BYTES + 1)
    if len(content) > MAX_INPUT_BYTES:
        raise DashboardError("Input exceeds the 128 MiB bound; partition the source export.")
    try:
        return json.loads(content.decode("utf-8-sig"), object_pairs_hook=_no_duplicates,
                          parse_constant=_reject_constant)
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise DashboardError("Invalid UTF-8 JSON: " + str(exc)) from exc


def _companion(filename, directory):
    adjacent = Path(__file__).resolve().with_name(filename)
    return adjacent if adjacent.is_file() else adjacent.parent.parent / directory / filename


@lru_cache(maxsize=1)
def load_schema():
    return load_json(_companion("dashboard-report.schema.json", "schemas"))


def metric_unit(metric):
    if metric in COUNT_METRICS:
        return "count"
    return "ms" if metric.startswith(("net.", "wifi.jitter.")) else "percent"


def metric_family(metric):
    if metric.startswith(("vpn.", "psr.audio.vpn.")):
        return "vpn"
    if metric.startswith(("ice.", "psr.audio.ice.")):
        return "p2p-pairs"
    if metric.startswith(("ver.", "psr.audio.ua.")):
        return "clients"
    for prefix, family in (
        ("site.", "sites"), ("net.", "network-subnets"), ("transport.", "transport"),
        ("wifi.", "wifi-bands"), ("cpu.", "compute-models"), ("vdi.", "vdi"),
        ("psr.", "media-quality"), ("clf.", "media-quality"), ("freeze.", "media-quality"),
    ):
        if metric.startswith(prefix):
            return family
    return "reliability"


def extension_family(extension):
    return EXTENSION_COVERAGE.get(extension, extension)


def _mapped_subnet(value):
    return _text(value) and value.strip().casefold() not in {"unknown", "unmapped", "null", "none", "n/a", "blank", "(blank)"}


def is_targeted_strategy(raw):
    """A declared ranking, where rows below the cut-off are absent by design."""
    return (raw.get("strategy") in {"alerted_subnets", "top_offenders", "targeted"}
            or raw.get("selection") in {"alerted", "top_offenders"})


def _matches_type(value, kind):
    return {
        "object": lambda: isinstance(value, dict),
        "array": lambda: isinstance(value, list),
        "string": lambda: isinstance(value, str),
        "number": lambda: _number(value),
        "integer": lambda: _integer(value),
        "boolean": lambda: type(value) is bool,
        "null": lambda: value is None,
    }[kind]()


def schema_errors(value, schema=None):
    """Evaluate the JSON Schema subset used by the shipped contract.

    This is deliberately not advertised as a general-purpose JSON Schema engine.
    Local references only; it never retrieves a schema or resolves remote URLs.
    """
    root = load_schema() if schema is None else schema

    def check(item, rule, path):
        if rule is True:
            return []
        if rule is False:
            return [path + ": value is not allowed"]
        errors = []
        if "$ref" in rule:
            ref = rule["$ref"]
            if not ref.startswith("#/"):
                raise DashboardError("Only local schema references are supported: " + ref)
            target = root
            try:
                for part in ref[2:].split("/"):
                    target = target[part.replace("~1", "/").replace("~0", "~")]
            except (KeyError, TypeError) as exc:
                raise DashboardError("Broken bundled schema reference: " + ref) from exc
            errors.extend(check(item, target, path))
        kinds = rule.get("type")
        if kinds is not None:
            kinds = [kinds] if isinstance(kinds, str) else kinds
            if not any(_matches_type(item, kind) for kind in kinds):
                return errors + [path + ": expected " + "/".join(kinds)]
        if "const" in rule and (item != rule["const"] or type(item) is bool and type(rule["const"]) is not bool):
            errors.append(path + ": expected constant " + repr(rule["const"]))
        if "enum" in rule and not any(_canonical(item) == _canonical(entry) for entry in rule["enum"]):
            errors.append(path + ": unsupported value " + repr(item))
        for branch in rule.get("allOf", []):
            errors.extend(check(item, branch, path))
        if "anyOf" in rule:
            alternatives = [check(item, branch, path) for branch in rule["anyOf"]]
            if all(alternatives):
                errors.append(path + ": does not match an allowed shape")
                errors.extend(dict.fromkeys(
                    error for branch in alternatives for error in branch
                    if error != path + ": expected null"
                ))
        if "if" in rule:
            branch = rule.get("else", True) if check(item, rule["if"], path) else rule.get("then", True)
            errors.extend(check(item, branch, path))
        if isinstance(item, dict):
            missing = [key for key in rule.get("required", []) if key not in item]
            if missing:
                errors.append(path + ": missing required " + ", ".join(missing))
            for limit, comparator in (("minProperties", len(item).__lt__), ("maxProperties", len(item).__gt__)):
                if limit in rule and comparator(rule[limit]):
                    errors.append(path + ": violates " + limit)
            properties, patterns = rule.get("properties", {}), rule.get("patternProperties", {})
            for key, child in item.items():
                matched = False
                if key in properties:
                    errors.extend(check(child, properties[key], path + "." + key))
                    matched = True
                for pattern, child_rule in patterns.items():
                    if re.search(pattern, key):
                        errors.extend(check(child, child_rule, path + "." + key))
                        matched = True
                if not matched and "additionalProperties" in rule:
                    errors.extend(check(child, rule["additionalProperties"], path + "." + key))
        if isinstance(item, list):
            for limit, comparator in (("minItems", len(item).__lt__), ("maxItems", len(item).__gt__)):
                if limit in rule and comparator(rule[limit]):
                    errors.append(path + ": violates " + limit)
            if rule.get("uniqueItems") and len({_canonical(entry) for entry in item}) != len(item):
                errors.append(path + ": duplicate array entries")
            if "items" in rule:
                for index, child in enumerate(item):
                    errors.extend(check(child, rule["items"], f"{path}[{index}]"))
        if isinstance(item, str):
            if "minLength" in rule and len(item) < rule["minLength"]:
                errors.append(path + ": string is too short")
            if "pattern" in rule and not re.search(rule["pattern"], item):
                errors.append(path + ": string does not match the required pattern")
            if rule.get("format") == "date":
                try:
                    date.fromisoformat(item)
                except ValueError:
                    errors.append(path + ": invalid calendar date")
        if _number(item):
            if "minimum" in rule and item < rule["minimum"]:
                errors.append(path + ": below minimum " + str(rule["minimum"]))
            if "maximum" in rule and item > rule["maximum"]:
                errors.append(path + ": above maximum " + str(rule["maximum"]))
        return errors

    try:
        return check(value, root, "$")
    except (RecursionError, OverflowError, ValueError) as exc:
        if isinstance(exc, DashboardError):
            raise
        return ["$: nonfinite, excessively nested or otherwise invalid JSON value"]


def _verified_query(queries, query_id, period):
    if not _text(query_id):
        return False
    if isinstance(queries, dict):
        query = queries.get(query_id)
    elif isinstance(queries, list):
        matches = [item for item in queries if isinstance(item, dict) and item.get("id") == query_id]
        query = matches[0] if len(matches) == 1 else None
    else:
        return False
    return bool(isinstance(query, dict) and query.get("id") == query_id and
                query.get("status") == "complete" and query.get("truncated") is False and
                query.get("period") in (None, period, "both") and
                query.get("evidence_type") not in {"schema", "access"})


def measure_comparable(previous, current, key, queries=None):
    """Require matching native identity and both verified, untruncated queries.

    Pass the report's query list or an id-keyed query registry. Missing evidence
    fails closed. This still does not prove the source query's semantic meaning.
    """
    if not previous or not current:
        return False
    if previous.get("period") != "previous" or current.get("period") != "current":
        return False
    if not (_verified_query(queries, previous.get("query_id"), "previous") and
            _verified_query(queries, current.get("query_id"), "current")):
        return False
    if any(_canonical(previous.get(field)) != _canonical(current.get(field))
           for field in ("cohort_key", "population_key", "scope", "dimensions", "grain")):
        return False
    left, right = previous.get("measures", {}).get(key), current.get("measures", {}).get(key)
    return bool(left and right and _number(left["value"]) and _number(right["value"]) and
                all(left.get(field) == right.get(field)
                    for field in ("unit", "native_name", "denominator_definition")))


def observation_comparable(previous, current, queries=None):
    """Require matching native identity and explicit complete/untruncated evidence."""
    if not previous or not current or not _number(previous.get("value")) or not _number(current.get("value")):
        return False
    if not (_verified_query(queries, previous.get("query"), "previous") and
            _verified_query(queries, current.get("query"), "current")):
        return False
    if not previous.get("id", "").endswith(".previous") or not current.get("id", "").endswith(".current"):
        return False
    if previous["id"].rsplit(".", 1)[0] != current["id"].rsplit(".", 1)[0]:
        return False
    return all(previous.get(field) == current.get(field) for field in
               ("population_key", "unit", "native", "denominator_definition", "scope", "grain"))


class _Validator:
    def __init__(self, data, preview, today):
        self.data, self.preview, self.today = data, preview, today
        self.errors, self.warnings, self.unfinished = [], [], []
        self.queries = {}
        self.family_refs = defaultdict(set)
        self.family_values = Counter()
        self.family_resolved = defaultdict(list)
        self.unavailable_refs = defaultdict(set)
        self.domains = {}
        self.unfinished_domains = set()
        self.dates = {}

    def error(self, path, message):
        self.errors.append(path + ": " + message)

    def gap(self, path, message):
        if self.preview:
            self.warnings.append(path + ": " + message)
            self.unfinished.append(path)
        else:
            self.error(path, message)

    def pending(self, path, message):
        self.unfinished.append(path)
        self.warnings.append(path + ": " + message)

    def query(self, query_id, path, period=None, usable=False, family=None):
        if query_id is None:
            if usable:
                self.gap(path, "known values require actual query evidence")
            return None
        query = self.queries.get(query_id)
        if query is None:
            self.error(path, "unresolved query reference " + query_id)
            return None
        if family:
            self.family_refs[family].add(query_id)
        if usable and query["status"] in UNUSABLE_QUERY_STATES:
            self.error(path, "usable values cannot come from a " + query["status"] + " query")
        if usable and query.get("evidence_type") in {"schema", "access"}:
            self.error(path, "schema/access evidence cannot substitute for measured data")
        if period is not None and query.get("period") not in (None, period, "both"):
            schema_only = not usable and query.get("period") == "n/a" and query.get("evidence_type") in {"schema", "access"}
            if not schema_only:
                self.error(path, "query period contradicts the observation period")
        return query

    @staticmethod
    def verified(query):
        return bool(query and query["status"] == "complete" and query.get("truncated") is False)

    def periods(self):
        for period in PERIODS:
            start, end = map(date.fromisoformat, self.data["periods"][period])
            if start.weekday() != 0 or end - start != timedelta(days=6):
                self.error("periods." + period, "expected seven complete Monday-Sunday UTC days")
            self.dates[period] = [(start + timedelta(days=i)).isoformat() for i in range(7)]
        prior_end = date.fromisoformat(self.data["periods"]["previous"][1])
        current_start = date.fromisoformat(self.data["periods"]["current"][0])
        current_end = date.fromisoformat(self.data["periods"]["current"][1])
        if current_start != prior_end + timedelta(days=1):
            self.error("periods", "previous and current weeks must be consecutive and non-overlapping")
        if current_end >= self.today:
            self.error("periods.current", "the selected UTC week has not finished")
        extracted = self.data["source"]["extracted"]
        try:
            timestamp = datetime.fromisoformat(extracted.replace("Z", "+00:00"))
        except ValueError:
            timestamp = None
        if timestamp and timestamp.tzinfo is not None and current_end >= timestamp.astimezone(timezone.utc).date():
            self.error("source.extracted", "extraction occurred before the selected UTC week finished")

    def query_register(self):
        if self.data["source"].get("access_mode") == "preserved_local_report":
            self.unfinished.append("source.preserved_local_report")
        for index, query in enumerate(self.data["queries"]):
            path = f"queries[{index}]"
            if query["id"] in self.queries:
                self.error(path, "duplicate query id " + query["id"])
            self.queries[query["id"]] = query
            if query["status"] in UNFINISHED_QUERY_STATES:
                self.unfinished.append(path + "." + query["status"])
            if query["status"] in {"failed", "unsupported", "rejected"} and not _text(query.get("reason")):
                self.gap(path, "failed/unsupported/rejected evidence needs its actual reason")
            control = query.get("control_stream_count")
            if control is not None and not _text(query.get("control_query")):
                self.error(path, "control_stream_count requires the actual control_query")
            returned = query.get("returned_stream_count")
            if control is not None and returned is not None:
                if returned > control or self.verified(query) and returned != control:
                    self.error(path, "returned stream count contradicts the control total")
            if query.get("row_count") == 0 and returned not in (None, 0):
                self.error(path, "empty query cannot report nonzero returned streams")
        declared = self.data["source"].get("queryCount")
        if declared is not None and declared != len(self.data["queries"]):
            self.error("source.queryCount", "does not match the query register")

    def unavailable_evidence(self, query):
        return bool(query and _text(query.get("reason")) and (
            query["status"] in {"failed", "unsupported", "rejected"} or
            self.verified(query) and query.get("evidence_type") != "access"
        ))

    def network_mapping(self):
        mapping = self.data["source"].get("network_mapping")
        if mapping is None:
            return
        path = "source.network_mapping"
        queries = [self.query(query_id, path) for query_id in mapping["query_ids"]]
        if mapping["status"] == "available" and not any(
                self.verified(query) and query.get("evidence_type") != "access" for query in queries):
            self.error(path, "available mapping requires verified native data/schema evidence, not an assumed Inside split")
        if mapping["status"] == "unavailable" and not any(self.unavailable_evidence(query) for query in queries):
            self.error(path, "unavailable mapping requires actual capability/failure evidence and its reason")

    def measure(self, item, path, *, average=False, definition_required=False):
        value, numerator, denominator, unit = (item.get(key) for key in ("value", "numerator", "denominator", "unit"))
        reason = item.get("reason")
        if value is None and not _text(reason):
            self.gap(path, "an unavailable value requires a reason, not an absent or invented zero")
        if unit == "text":
            return
        if average:
            if item.get("aggregation", "native") != "native" or numerator is not None:
                self.error(path, "native averages cannot be recomputed or pooled from cohort/daily means")
            if denominator == 0 and value is not None:
                self.error(path, "a native mean cannot have zero eligible observations")
            return
        if unit == "count":
            if numerator is not None and value is not None and numerator != value:
                self.error(path, "native count differs from its stated numerator")
            if item.get("aggregation") == "ratio_of_counts":
                self.error(path, "a count cannot be labelled a ratio")
            return
        if numerator is not None and denominator is not None:
            if numerator > denominator:
                self.error(path, "numerator exceeds its own eligible denominator")
            if denominator == 0:
                if value is not None:
                    self.error(path, "zero denominator requires value=null, never zero percent")
            elif value is not None:
                expected = numerator / denominator * (100 if unit == "percent" else 1)
                if not math.isclose(value, expected, rel_tol=1e-9, abs_tol=1e-7):
                    self.error(path, "value contradicts numerator/denominator; keep rounded source text in native_value")
        elif value is not None:
            if not _text(reason):
                self.gap(path, "native rate with an unavailable numerator/denominator needs a reason")
            if value == 0 and numerator is None:
                self.error(path, "unknown numerator cannot be labelled zero; retain rounded native text and use null")
        if definition_required and value is not None and not _text(item.get("denominator_definition")):
            self.gap(path, "a measured rate needs its native denominator_definition")

    def count_relations(self, counts, path):
        def known(*keys):
            return all(counts.get(key) is not None for key in keys)
        if known("failed", "established", "cdr") and counts["failed"] + counts["established"] != counts["cdr"]:
            self.error(path, "failed + established must equal CDR (stream grain)")
        for part, whole in (("dropped", "established"), ("failed", "cdr"), ("cdr", "streams"),
                            ("established", "streams"), ("dropped", "streams"), ("failed", "streams")):
            if known(part, whole) and counts[part] > counts[whole]:
                self.error(path, part + " exceeds " + whole)
        for names in (("good", "poor", "unclassified"), ("true", "false", "null"), ("good", "poor"), ("true", "false")):
            if known("streams", *names) and sum(counts[key] for key in names) > counts["streams"]:
                self.error(path, "eligible/unknown classification counts exceed stream count")

    def observations(self):
        for key, item in self.data["observations"].items():
            metric, period = key[4:].rsplit(".", 1)
            path, family = "observations." + key, metric_family(metric)
            if item["id"] != key:
                self.error(path, "observation id must exactly match its dictionary key")
            if item["unit"] != metric_unit(metric):
                self.error(path, "unit contradicts the fixed dashboard metric")
            known = (any(item[name] is not None for name in ("value", "numerator", "denominator")) or
                     any(value is not None for value in item.get("counts", {}).values()))
            query = self.query(item["query"], path, period, known, family)
            average = metric_unit(metric) == "ms" or metric.startswith("cpu.system_avg.")
            self.measure(item, path, average=average,
                         definition_required=not average and item["unit"] == "percent")
            counts = item.get("counts", {})
            self.count_relations(counts, path + ".counts")
            expected = None
            if metric.startswith(("psr.", "wifi.psr.", "ver.psr.")) and item["unit"] == "percent":
                if counts.get("good") is not None and counts.get("poor") is not None:
                    expected = (counts["poor"], counts["good"] + counts["poor"])
            elif metric.startswith(("clf.", "cpu.classifier.")):
                if counts.get("true") is not None and counts.get("false") is not None:
                    expected = (counts["true"], counts["true"] + counts["false"])
            elif metric.startswith("setup.") or metric == "site.focus.setup":
                if counts.get("failed") is not None and counts.get("cdr") is not None:
                    expected = (counts["failed"], counts["cdr"])
            elif metric.startswith(("drop.", "ver.drop.")) or metric == "site.focus.drop":
                if counts.get("dropped") is not None and counts.get("established") is not None:
                    expected = (counts["dropped"], counts["established"])
            if expected and expected != (item["numerator"], item["denominator"]):
                self.error(path, "native eligible counts contradict numerator/denominator; do not substitute total streams")
            if metric.startswith("psr.audio.conn.all.") and known:
                self.audio_context_psr(item, path, query)
            if metric == "usage.days" and item["value"] is not None and (
                    isinstance(item["value"], bool) or not isinstance(item["value"], int) or not 1 <= item["value"] <= 7):
                self.error(path, "each weekly usage.days count must be between 1 and 7")
            grain = item.get("grain")
            if metric == "usage.calls.all" and grain not in (None, "call_leg"):
                self.error(path, "Total Call Count is call-leg grain, not users or meetings")
            if metric == "usage.streams.all" and grain not in (None, "stream"):
                self.error(path, "Total Stream Count must retain stream grain")
            if metric.startswith("site.focus.") and self.data["focusSite"] is None and known:
                self.error(path, "focus-site measurements require focusSite")
            version = "quality_focus" if metric == "ver.psr.windows.quality_focus" else "primary"
            if metric.startswith("ver.") and self.data["versions"][version] is None and known:
                self.error(path, "a version-specific observation requires the actual version label")
            self.family_values[family] += int(known)
            resolved = self.verified(query) and (
                item["value"] is not None or item["denominator"] == 0 and _text(item["reason"])
            )
            if item["unit"] == "percent" and not average:
                resolved = resolved and item["numerator"] is not None and item["denominator"] is not None
            self.family_resolved[family].append(bool(resolved))

    def audio_context_psr(self, item, path, query):
        counts = item.get("counts", {})
        if any(counts.get(key) is None for key in ("good", "poor")):
            self.error(path, "mixed-session Audio context PSR requires native Good/Poor aggregate counts")
        scope = item.get("scope", {})
        context = item["id"].rsplit(".", 2)[1]
        expected_network = context.split("_", 1)[0].title()
        if (scope.get("media") != "Audio" or scope.get("scenario") not in {"All", "Conf+P2P"} or
                scope.get("endpoint_anchor") != "Second" or scope.get("network_scope") != expected_network):
            self.error(path, "mixed-session Audio context scope must match Inside/Outside, Conf+P2P/All and endpoint_anchor=Second")
        if not self.verified(query):
            self.error(path, "mixed-session context PSR requires a complete, untruncated native aggregate/cohort query, not partial subnet rankings")
        raw = self.data.get("networkResults") or {}
        if any(batch["id"] == item["query"] for key in ("queries", "wifi_queries", "cpu_queries") for batch in raw.get(key, [])):
            self.error(path, "mixed-session context PSR must cite native aggregate/cohort counts, not a detailed investigation batch")

    def all_session_psr(self):
        for period in PERIODS:
            for media in MEDIA:
                prefix = "obs.psr." + media.lower() + ".tenant."
                aggregate = self.data["observations"][prefix + "all." + period]
                counts = aggregate.get("counts", {})
                if not (any(aggregate[key] is not None for key in ("value", "numerator", "denominator")) or
                        any(value is not None for value in counts.values())):
                    continue
                path = "observations." + aggregate["id"]
                if any(counts.get(key) is None for key in ("good", "poor")):
                    self.error(path, "all-session PSR requires native Good/Poor counts, never an average of rates")
                    continue
                if (aggregate["numerator"], aggregate["denominator"]) != (counts["poor"], counts["good"] + counts["poor"]):
                    self.error(path, "all-session PSR must retain Poor/(Good+Poor), not total streams")
                aggregation = aggregate.get("aggregation", "native")
                if aggregation not in {"native", "ratio_of_counts"}:
                    self.error(path, "all-session PSR must use native aggregates or disjoint Conf+P2P counts")
                scope = aggregate.get("scope")
                if scope and (scope["media"] != media or scope["scenario"] not in {"All", "Conf+P2P"}):
                    self.error(path, "all-session PSR scope must name its media and All/Conf+P2P scenarios")
                components = [self.data["observations"][prefix + scenario.lower() + "." + period] for scenario in SCENARIOS]
                ready = all(item.get("counts", {}).get(key) is not None
                            for item in components for key in ("good", "poor"))
                common_scope = lambda item: {key: value for key, value in item.get("scope", {}).items() if key != "scenario"}
                compatible = all(
                    item["population_key"] == aggregate["population_key"] and
                    item.get("denominator_definition") == aggregate.get("denominator_definition") and
                    item.get("grain", "stream") == aggregate.get("grain", "stream") and
                    common_scope(item) == common_scope(aggregate) and
                    (not item.get("scope") or item["scope"]["scenario"] == scenario)
                    for item, scenario in zip(components, SCENARIOS)
                )
                if aggregation == "ratio_of_counts" and not (ready and compatible):
                    self.error(path, "recomposed all-session PSR needs disjoint Conf+P2P Good/Poor counts with the same population, scope and native eligibility")
                if ready and compatible:
                    for key in ("good", "poor", "unclassified", "streams"):
                        if counts.get(key) is not None and all(item["counts"].get(key) is not None for item in components):
                            if counts[key] != sum(item["counts"][key] for item in components):
                                self.error(path, "all-session " + key + " count contradicts the disjoint Conf+P2P sum; never average rates")

    def record(self, row, path, family, period, fields):
        known = any(row.get(key) is not None for key in fields)
        self.query(row.get("query_id"), path, period, known, family)
        if known and not _text(row.get("population_key")):
            self.gap(path, "known counts need a population_key; separate stream and call-leg grains")
        if any(row.get(key) is None for key in fields) and not _text(row.get("reason")):
            self.gap(path, "unknown counts require a row reason")
        self.count_relations(row, path)
        self.family_values[family] += int(known)

    def daily(self):
        expected = set(self.dates["previous"] + self.dates["current"])
        for key, family, fields in (
            ("daily", "reliability", DAILY_COUNTS),
            ("focusDaily", "sites", ("streams", "failed", "dropped")),
        ):
            seen = set()
            for index, row in enumerate(self.data[key]):
                path = f"{key}[{index}]"
                if row["date"] in seen:
                    self.error(path, "duplicate daily date; never pool daily averages")
                seen.add(row["date"])
                if row["date"] not in expected:
                    self.error(path, "date falls outside the two selected weeks")
                period = "previous" if row["date"] in self.dates["previous"] else "current"
                self.record(row, path, family, period, fields)
            if key == "daily" and seen != expected:
                self.error(key, "exactly fourteen selected dates are required, even when counts are null")
        if self.data["focusSite"] is None and self.data["focusDaily"]:
            self.error("focusDaily", "daily site records require an actual focusSite")
        for period in PERIODS:
            rows = [row for row in self.data["daily"] if row["date"] in self.dates[period]]
            for column, metric, field in (
                ("streams", "usage.streams.all", "value"),
                ("cdr", "setup.tenant.all", "denominator"),
                ("failed", "setup.tenant.all", "numerator"),
                ("established", "drop.tenant.all", "denominator"),
                ("dropped", "drop.tenant.all", "numerator"),
            ):
                observation = self.data["observations"][f"obs.{metric}.{period}"]
                same = all(row.get("population_key") == observation["population_key"] for row in rows)
                known_rows = [row for row in rows if row[column] is not None]
                ready = len(rows) == 7 and len(known_rows) == 7 and observation[field] is not None
                if ready and same and sum(row[column] for row in rows) != observation[field]:
                    self.error("daily." + period, column + " sum contradicts the comparable weekly total")
                elif len(rows) == 7 and 0 < len(known_rows) < 7 and same and observation[field] is not None:
                    if sum(row[column] for row in known_rows) > observation[field]:
                        self.error("daily." + period, column + " partial daily sum exceeds the comparable weekly total")
                if ready and not same:
                    self.warnings.append("daily." + period + ": " + column + " not reconciled: population keys differ")
                if self.data["coverage"]["reliability"]["status"] == "complete" and not (ready and same):
                    self.error("coverage.reliability", "complete requires seven reconciled daily/weekly populations")
            focus = [row for row in self.data["focusDaily"] if row["date"] in self.dates[period]]
            target = self.data["observations"][f"obs.site.focus.drop.{period}"]
            if (len(focus) == 7 and target["numerator"] is not None and
                    all(row["dropped"] is not None and row.get("population_key") == target["population_key"] for row in focus) and
                    sum(row["dropped"] for row in focus) != target["numerator"]):
                self.error("focusDaily." + period, "dropped counts do not reconcile to the focus-site population")

    def sites(self):
        seen = set()
        for index, row in enumerate(self.data["sites"] + [self.data["unmapped"]]):
            path = f"sites[{index}]" if index < len(self.data["sites"]) else "unmapped"
            if row["name"] in seen:
                self.error(path, "duplicate site name, including the unmapped population")
            seen.add(row["name"])
            self.record(row, path, "sites", "current", SITE_COUNTS)
            if path != "unmapped" and "previous" not in row:
                self.error(path, "previous dropped count is required; use null with a reason when absent")
            if row.get("previous") is not None:
                self.query(row.get("previous_query_id"), path + ".previous", "previous", True, "sites")
            elif path != "unmapped" and not _text(row.get("reason")):
                self.gap(path, "missing previous-site data needs a reason, never zero filling")
        location_names = set()
        actual_sites = {row["name"] for row in self.data["sites"]}
        actual_sites.update(row["dimensions"].get("site") for row in self.data["extensions"]["sites"]["rows"])
        if self.data["focusSite"]:
            actual_sites.add(self.data["focusSite"])
        for index, row in enumerate(self.data["siteLocations"]):
            path = f"siteLocations[{index}]"
            if row["site"] in location_names:
                self.error(path, "duplicate geographic site record")
            location_names.add(row["site"])
            if row["site"] not in actual_sites:
                self.error(path, "geographic row has no corresponding observed site")
            if row.get("query_id") is not None:
                self.query(row["query_id"], path, usable=True, family="sites")
            self.family_values["sites"] += 1

    def transport(self):
        for period in PERIODS:
            for setup_metric, drop_metric in (
                ("setup.tenant.all", "drop.tenant.all"),
                ("setup.tenant.conf", "drop.tenant.conf"),
                ("setup.tenant.p2p", "drop.tenant.p2p"),
                ("site.focus.setup", "site.focus.drop"),
            ):
                setup = self.data["observations"][f"obs.{setup_metric}.{period}"]
                drop = self.data["observations"][f"obs.{drop_metric}.{period}"]
                if (setup["population_key"] == drop["population_key"] and setup.get("scope") == drop.get("scope") and
                        all(value is not None for value in (setup["numerator"], setup["denominator"], drop["denominator"])) and
                        setup["denominator"] - setup["numerator"] != drop["denominator"]):
                    self.error("observations." + drop["id"], "established drop denominator contradicts CDR minus setup failures in the same population")
        for period in PERIODS:
            counts = self.data["transport"][period]
            observations = {key: self.data["observations"][f"obs.transport.{key}.{period}"] for key in counts}
            for key, count in counts.items():
                if count != observations[key]["numerator"]:
                    self.error("transport." + period + "." + key, "must match its observation numerator, including null")
            if all(value is not None for value in counts.values()):
                total = sum(counts.values())
                for key, observation in observations.items():
                    if observation["denominator"] != total:
                        self.error("transport." + period + "." + key, "share denominator must include UDP, TCP family and unknown")
                turn = self.data["observations"][f"obs.transport.turntcp.{period}"]
                if turn["numerator"] is not None and turn["numerator"] > counts["tcpfamily"]:
                    self.error("transport." + period, "TurnTCP is a subset of TCP family, not an extra slice")
                if turn["denominator"] is not None and turn["denominator"] != total:
                    self.error("transport." + period, "TurnTCP share uses the same unknown-inclusive denominator")
                usage = self.data["observations"][f"obs.usage.streams.all.{period}"]
                if usage["value"] is not None and total != usage["value"]:
                    self.error("transport." + period, "all-transport partition does not reconcile to all streams")
            self.family_values["transport"] += sum(value is not None for value in counts.values())
        for period in PERIODS:
            total = self.data["observations"][f"obs.vdi.streams.{period}"]["value"]
            states = [self.data["observations"][f"obs.vdi.{state}.{period}"]
                      for state in ("optimized", "not_optimized", "inactive", "unknown")]
            if total is not None:
                known = [item["numerator"] for item in states if item["numerator"] is not None]
                if sum(known) > total or len(known) == 4 and sum(known) != total:
                    self.error("vdi." + period, "optimization states must form a disjoint partition of VDI streams")
                for item in states:
                    if item["denominator"] is not None and item["denominator"] != total:
                        self.error(item["id"], "VDI state denominator must equal observed VDI streams")

    def coverage_entry(self, item, path, has_values=False, unavailable_ids=()):
        ids, status = item["query_ids"], item["status"]
        queries = [self.query(query_id, path) for query_id in ids]
        if status == "not_collected":
            self.unfinished.append(path)
            if has_values:
                self.error(path, "not_collected cannot contain measured values")
            return
        if not ids:
            self.gap(path, "terminal coverage needs actual query/schema evidence, not an empty success")
        if status == "complete" and not all(
                self.verified(query) or query and query["id"] in unavailable_ids and self.unavailable_evidence(query)
                for query in queries):
            self.error(path, "complete coverage needs complete, explicitly untruncated query evidence")
        if status in {"failed", "unsupported"} and has_values:
            self.error(path, status + " coverage cannot contain usable measurements; use partial")
        if status == "unsupported" and not any(
            query and (query["status"] == "unsupported" or
                       query.get("evidence_type") == "schema" and self.verified(query) and _text(query.get("reason")))
            for query in queries
        ):
            self.gap(path, "unsupported requires a source/schema capability result and its reason")
        if status == "failed" and not any(query and query["status"] in {"failed", "rejected"} for query in queries):
            self.gap(path, "failed requires a recorded failed or rejected execution")
        if status == "partial" and ids and not any(query and query["status"] not in UNFINISHED_QUERY_STATES for query in queries):
            self.error(path, "partial cannot substitute for entirely unexecuted collection")

    def empty_period_evidence(self, ids, period):
        return any(
            self.verified(self.queries.get(query_id)) and
            self.queries[query_id].get("evidence_type") not in {"schema", "access"} and
            self.queries[query_id].get("period") in (period, "both") and
            self.queries[query_id].get("row_count") == 0 and
            self.queries[query_id].get("control_stream_count") == 0 and
            _text(self.queries[query_id].get("control_query"))
            for query_id in ids
        )

    @staticmethod
    def row_measured(row):
        return row["streams"] is not None or any(
            measure[key] is not None for measure in row["measures"].values()
            for key in ("value", "numerator", "denominator")
        )

    def unavailable_classifier(self, row):
        query = self.queries.get(row["query_id"])
        return (not self.row_measured(row) and _text(row.get("reason")) and
                all(_text(measure["reason"]) for measure in row["measures"].values()) and
                (self.unavailable_evidence(query) or
                 self.verified(query) and query.get("evidence_type") != "access"))

    def classifier_row(self, row, path):
        classifier = row["dimensions"]["classifier"]
        combination = (classifier, row["scope"]["media"], row["scope"]["scenario"])
        if combination not in CLASSIFIER_COMBINATIONS:
            self.error(path, "inapplicable classifier/media/scenario; input-device variants are Audio only and other_user_* are Conf only")
        counts = {key: row["measures"][key + "_count"]["value"] for key in ("true", "false", "null")}
        self.count_relations({"streams": row["streams"], **counts}, path)
        problem = row["measures"]["problem_rate"]
        if counts["true"] is not None and counts["false"] is not None:
            if (problem["numerator"], problem["denominator"]) != (counts["true"], counts["true"] + counts["false"]):
                self.error(path, "classifier problem_rate must use True/(True+False), excluding Null and total streams")
        for key, measure in row["measures"].items():
            if measure["value"] is None and not _text(measure["reason"]):
                self.error(path + ".measures." + key, "unavailable classifier values require their actual reason, including in preview")
            if key in {"problem_rate", "caused_rate"} and measure["value"] is not None:
                if any(value is None for value in counts.values()):
                    self.error(path, "known classifier rates require native true_count, false_count and null_count")
                if (measure["numerator"] is None or measure["denominator"] is None or
                        not _text(measure["denominator_definition"])):
                    self.error(path, "known classifier rates require native counts and eligibility text")
        if not self.row_measured(row) and not _text(row.get("reason")):
            self.error(path, "unavailable classifier cells require a row reason and actual query/schema references")

    def inside_row(self, row, path):
        day = row["dimensions"]["date"]
        if day not in self.dates[row["period"]]:
            self.error(path, "Inside daily date must belong to its declared selected week")
        counts = {key: row["measures"][key]["value"] for key in DAILY_COUNTS}
        self.count_relations(counts, path)
        if counts["streams"] != row["streams"]:
            self.error(path, "Inside daily streams measure must match row.streams, including null")
        for key in DAILY_COUNTS:
            if counts[key] is None and not _text(row["measures"][key]["reason"]):
                self.error(path, "unavailable Inside daily counts require their native reason")
        mapping = self.data["source"].get("network_mapping")
        if self.row_measured(row) and mapping and mapping["status"] != "available":
            self.error(path, "unverified/unavailable network mapping cannot authorize a measured Inside series")
        daily = next((item for item in self.data["daily"] if item["date"] == day), None)
        if daily:
            for key, value in counts.items():
                if value is not None and daily[key] is not None and value > daily[key]:
                    self.error(path, "Inside daily " + key + " exceeds the all-source daily count")

    def routing_row(self, row, path, complete):
        dimensions = row["dimensions"]
        country = dimensions.get("media_country")
        if _text(country) and not _text(dimensions.get("media_country_basis")):
            self.error(path, "media_country requires its labelled native country basis, not an inferred datacenter identity")
        for prefix in ("user", "media"):
            source = next((dimensions.get(prefix + "_country_" + suffix) for suffix in ("source", "column", "native_name")
                           if _text(dimensions.get(prefix + "_country_" + suffix))), None)
            if source:
                native = re.sub(r"[^a-z0-9]", "", source.casefold()).removeprefix("cqd")
                expected = "building_mapping" if native in {"firstcountry", "secondcountry"} else "asn_proxy" if "asn" in native and "country" in native else None
                if expected and dimensions.get(prefix + "_country_basis") != expected:
                    self.error(path, "CQD FirstCountry/SecondCountry is building_mapping and ASN country is asn_proxy, not validated physical location")
        if dimensions.get("media_country_basis") == "validated_server_country" and dimensions["endpoint_role"] in {"peer", "client", "p2p_peer", "direct_peer"}:
            self.error(path, "a peer endpoint cannot be labelled validated_server_country")
        for prefix, basis in (("user", "validated"), ("media", "validated_media_endpoint")):
            lon, lat = dimensions.get(prefix + "_lon"), dimensions.get(prefix + "_lat")
            if lon is not None or lat is not None:
                if not _number(lon) or not _number(lat) or not -180 <= lon <= 180 or not -90 <= lat <= 90:
                    self.error(path, "endpoint coordinates need a valid longitude/latitude pair")
                if dimensions.get(prefix + "_location_basis") != basis:
                    self.error(path, "broad geography/proxies cannot be plotted as validated user or media endpoints")
        endpoint = dimensions["media_endpoint"]
        if dimensions["media_location_basis"] == "validated_media_endpoint" and _text(endpoint) and any(
                _text(value) and endpoint.strip().casefold() == value.strip().casefold()
                for value in (country, dimensions["media_region"])):
            self.error(path, "a source country/region is not physical serving-endpoint or datacenter identity")
        if complete and (
            dimensions["user_location_basis"] != "validated" or
            dimensions["media_location_basis"] != "validated_media_endpoint" or
            not _text(endpoint) or not _text(dimensions["endpoint_role"])
        ):
            self.error(path, "complete regional routing needs validated user/serving-endpoint evidence, not tenant/building region")

    def extensions(self):
        for name, envelope in self.data["extensions"].items():
            family, path = extension_family(name), "extensions." + name
            seen, inside_dates = set(), set()
            rows = envelope["rows"]
            unavailable_ids = {row["query_id"] for row in rows if name == "media-classifiers" and self.unavailable_classifier(row)}
            self.unavailable_refs[family].update(unavailable_ids)
            self.coverage_entry(envelope, path, any(self.row_measured(row) for row in rows), unavailable_ids)
            complete = envelope["status"] == "complete"
            if envelope["status"] in {"failed", "unsupported", "not_collected"} and rows:
                self.error(path, "unavailable extension must have rows=[]")
            for index, row in enumerate(rows):
                row_path = f"{path}.rows[{index}]"
                identity_fields = ("period", "population_key", "scope", "dimensions") if name == "media-classifiers" else (
                    "period", "cohort_key", "population_key", "scope", "dimensions")
                identity = _canonical([row[field] for field in identity_fields])
                if identity in seen:
                    self.error(row_path, "duplicate weekly cohort; do not pool averages or overlapping partitions")
                seen.add(identity)
                measured = self.row_measured(row)
                query = self.query(row["query_id"], row_path, row["period"],
                                   measured if name in EXTENSION_COVERAGE else True, family)
                unavailable = name == "media-classifiers" and self.unavailable_classifier(row)
                if row["query_id"] not in envelope["query_ids"]:
                    self.error(row_path, "row query is missing from its extension query_ids")
                if row["streams"] is None and not _text(row.get("reason")):
                    self.gap(row_path, "unknown streams require a reason, never an invented zero")
                for key, measure in row["measures"].items():
                    measure_path = row_path + ".measures." + key
                    if key in CANONICAL_UNITS and measure["unit"] not in CANONICAL_UNITS[key]:
                        self.error(measure_path, "unit contradicts the canonical measure identity")
                    average = measure["unit"] in {"ms", "fps"} or key.endswith("_avg")
                    self.measure(measure, measure_path, average=average, definition_required=not average and measure["unit"] in {"percent", "ratio"})
                    is_zero_weekend = (name == "reliability-inside" and
                                       row["dimensions"].get("date") and
                                       date.fromisoformat(row["dimensions"]["date"]).weekday() in (5, 6) and
                                       _text(row.get("reason")))
                    if complete and not unavailable and not is_zero_weekend and (
                        measure["value"] is None and (measure["unit"] == "count" or measure["denominator"] != 0) or
                        measure["unit"] in {"percent", "ratio"} and not average and
                        (measure["numerator"] is None or measure["denominator"] is None)
                    ):
                        self.error(measure_path, "complete extension has unresolved values or eligible counts")
                is_zero_weekend = (name == "reliability-inside" and
                                   row["dimensions"].get("date") and
                                   date.fromisoformat(row["dimensions"]["date"]).weekday() in (5, 6) and
                                   _text(row.get("reason")))
                if complete and not unavailable and not is_zero_weekend and (
                        row["streams"] is None or not self.verified(query) or any(value is None for value in row["scope"].values())):
                    self.error(row_path, "complete extension requires stream counts, explicit scope and verified evidence")
                if name == "reliability-inside":
                    self.inside_row(row, row_path)
                    day = row["dimensions"]["date"]
                    if day in inside_dates:
                        self.error(row_path, "duplicate Inside daily date; do not manufacture daily coverage with multiple cohorts")
                    inside_dates.add(day)
                elif name == "media-classifiers":
                    self.classifier_row(row, row_path)
                elif name == "p2p-pairs":
                    if row["scope"]["scenario"] != "P2P" or row["scope"]["endpoint_anchor"] != "Both":
                        self.error(row_path, "P2P pair evidence must use scenario=P2P and endpoint_anchor=Both")
                    dimensions = row["dimensions"]
                    if dimensions.get("pair_grain") == "subnet_pair" and not all(
                            _mapped_subnet(dimensions.get(key)) for key in ("first_subnet", "second_subnet")):
                        self.error(row_path, "subnet_pair requires both actual subnet IDs; use scope_pair for aggregate scope evidence")
                    if complete and any(not _text(dimensions[key]) for key in ("first_scope", "second_scope", "selected_ice_path")):
                        self.error(row_path, "complete P2P evidence requires both endpoint scopes and the selected path")
                elif name == "regional-routing":
                    self.routing_row(row, row_path, complete)
                self.family_values[family] += int(measured)
            if complete:
                if name == "reliability-inside":
                    expected = set(self.dates["previous"] + self.dates["current"])
                    if inside_dates != expected:
                        self.error(path, "complete Inside reliability requires fourteen measured distinct dates in both selected weeks")
                elif name == "media-classifiers":
                    expected = {(period, *combination) for period in PERIODS for combination in CLASSIFIER_COMBINATIONS}
                    actual = {(row["period"], row["dimensions"]["classifier"], row["scope"]["media"], row["scope"]["scenario"]) for row in rows}
                    if actual != expected:
                        self.error(path, "complete classifier coverage requires all 41 applicable combinations in BOTH weeks (82 cells), not generic scalar slots")
                else:
                    for period in PERIODS:
                        if not any(row["period"] == period for row in rows) and not self.empty_period_evidence(envelope["query_ids"], period):
                            self.error(path, "complete requires both weeks or explicitly controlled zero-row data-query evidence for " + period)
                if name == "direction-comparison":
                    directions = defaultdict(set)
                    for row in rows:
                        scope = {key: value for key, value in row["scope"].items() if key != "direction"}
                        key = _canonical([row["period"], row["population_key"], scope, row["dimensions"]])
                        directions[key].add(row["scope"]["direction"])
                    if any(values != {"First-to-Second", "Second-to-First"} for values in directions.values()):
                        self.error(path, "complete direction comparison needs matched First-to-Second/Second-to-First cohorts")
            for query_id in {row["query_id"] for row in rows}:
                query = self.queries.get(query_id)
                selected = [row for row in rows if row["query_id"] == query_id]
                if query and query.get("returned_stream_count") is not None and all(row["streams"] is not None for row in selected):
                    if name == "media-classifiers" and (
                            len({row["dimensions"]["classifier"] for row in selected}) > 1 or
                            len({row["population_key"] for row in selected}) > 1):
                        self.warnings.append(path + ": returned_stream_count retained, not pooled across overlapping classifier populations")
                        continue
                    if sum(row["streams"] for row in selected) != query["returned_stream_count"]:
                        self.error(path, "row streams contradict the registered returned_stream_count")

    def raw_field(self, row, name, path, dimension=False, required=False):
        aliases = (f"CQD[{name}]", f"'CQD'[{name}]", f"[{name}]", name) if dimension else (f"[{name}]", name)
        present = [row[key] for key in aliases if key in row]
        if required and not present:
            self.error(path, "missing mandatory native column " + name + "; aggregate controls are not subnet detail")
        if len(present) > 1 and any(_canonical(value) != _canonical(present[0]) for value in present[1:]):
            self.error(path, "conflicting native aliases for " + name)
        return present[0] if present else None

    def native_number(self, value, path, *, count=False, unit=None):
        if value is None:
            return None
        if unit and isinstance(value, str):
            match = re.fullmatch(r"\s*(\d+(?:[.,]\d+)?)\s*%\s*", value)
            if not match or float(match[1].replace(",", ".")) > 100:
                self.error(path, "expected a native percent string in 0..100")
            return None
        if not _number(value) or value < 0 or count and (not _integer(value) or value > MAX_SAFE_INTEGER):
            self.error(path, "expected a nonnegative finite " + ("safe integer" if count else "number"))
            return None
        if unit in {"percent", "ratio"} and value > (100 if unit == "percent" else 1):
            self.error(path, "numeric value contradicts its declared " + unit + " unit")
        return value

    def scope_control_closure(self, raw):
        controls, seen, zero_scopes = raw.get("scope_controls", []), set(), set()
        complete = True
        pending_before = len(self.unfinished)
        by_query = defaultdict(list)
        is_targeted = is_targeted_strategy(raw)
        partition_fields = {
            "direction", "streamdirection", "networkscope", "inside", "insidecorp",
            "firstinsidecorp", "secondinsidecorp", "connection", "connectiondetail",
            "connections", "connectiontype", "connectiontypes", "connectionvalues",
            "firstnetworkconnectiondetail", "secondnetworkconnectiondetail",
            "firstnetworkconnectiontype", "secondnetworkconnectiontype",
            "transport", "firsttransportprotocol", "secondtransportprotocol",
            "subnet", "firstsubnet", "secondsubnet",
        }
        for index, control in enumerate(controls):
            path = f"networkResults.scope_controls[{index}]"
            scope = tuple(control[key] for key in ("period", "media", "scenario"))
            if scope in seen:
                self.error(path, "duplicate scope control; twelve unique period/media/scenario totals are required")
            seen.add(scope)
            streams = control["streams"]
            status = control.get("status", "complete")
            query = self.query(control["query_id"], path, control["period"], streams is not None, "network-subnets")
            if control["query_id"] is not None:
                by_query[control["query_id"]].append(control)
            if streams is None:
                complete = False
                if self.verified(query) and query.get("evidence_type") == "control" and any(
                        query.get(key) is not None for key in ("returned_stream_count", "control_stream_count")):
                    self.error(path, "an available native scope total cannot be relabelled unavailable")
                if status == "not_collected" or query and query["status"] in UNFINISHED_QUERY_STATES:
                    self.pending(path, "scope control has not been collected; null is not zero")
                elif not (self.unavailable_evidence(query) or
                          status == "partial" and query and query["status"] == "partial" and _text(query.get("reason"))):
                    self.error(path, "unavailable scope controls require actual query/schema failure or capability evidence and its reason")
                if status == "unsupported" and query and not (
                        query["status"] == "unsupported" or
                        query.get("evidence_type") == "schema" and self.verified(query) and _text(query.get("reason"))):
                    self.error(path, "unsupported scope control needs native schema/capability evidence, not an omitted partition")
                if status == "failed" and query and query["status"] not in {"failed", "rejected"}:
                    self.error(path, "failed scope control requires an actual failed/rejected query")
                continue
            self.family_values["network-subnets"] += 1
            if not self.verified(query) or status != "complete":
                complete = False
                self.pending(path, "scope total is not verified complete/untruncated; retain the actual control count")
            if query:
                filters = query.get("filters")
                if not isinstance(filters, dict):
                    self.error(path, "scope control needs explicit native query filters declaring the full network universe")
                else:
                    for key, value in filters.items():
                        normalized = re.sub(r"[^a-z0-9]", "", key.casefold()).removeprefix("cqd")
                        allowed = {"all", "both"} if normalized in {"direction", "streamdirection"} else {"all"}
                        if normalized in partition_fields and (not _text(value) or value.casefold() not in allowed):
                            self.error(path, "scope control must include all flags/directions/connections, not a narrowed partition or fixed non-wired value list")
            batches = [batch for batch in raw.get("queries", []) if
                       tuple(batch[key] for key in ("period", "media", "scenario")) == scope]
            total = sum(batch["control_stream_count"] for batch in batches if batch.get("control_stream_count") is not None)
            if total > streams:
                self.error(path, "disjoint batch control sum exceeds its scope control streams; overlapping or contradictory partitions")
            elif total < streams and not is_targeted:
                complete = False
                self.pending(path, f"missing network partitions: batch controls total {total}, full scope control is {streams}; include blank/unknown connection cohorts")
            if any(batch.get("control_stream_count") is None for batch in batches):
                complete = False
                self.pending(path, "a native partition has no control_stream_count; missing partition counts cannot certify scope closure")
            if streams == 0 and self.verified(query) and status == "complete":
                zero_scopes.add(scope)
        for scope in sorted(NETWORK_SCOPES - seen):
            complete = False
            self.pending("networkResults.scope_controls." + ".".join(scope), "missing full-universe scope control")
        for query_id, rows in by_query.items():
            query = self.queries.get(query_id)
            if query and all(row["streams"] is not None for row in rows):
                for key in ("returned_stream_count", "control_stream_count"):
                    if query.get(key) is not None and sum(row["streams"] for row in rows) != query[key]:
                        self.error("networkResults.scope_controls", "scope streams contradict the registered " + key)
        if len(self.unfinished) > pending_before:
            self.unfinished_domains.add("network")
        return complete, zero_scopes

    def investigations(self):
        raw = self.data.get("networkResults")
        if raw is None:
            return
        if raw["report_name"] != self.data["source"]["report"] or raw["periods"] != self.data["periods"]:
            self.error("networkResults", "report name and UTC periods must exactly match the full report")
        ids = set()
        for list_key, kind, family in (("queries", "network", "network-subnets"), ("wifi_queries", "wifi", "wifi-bands"), ("cpu_queries", "cpu", "compute-models")):
            batches = raw.get(list_key, [])
            keys, scopes, all_complete = set(), set(), bool(batches)
            for index, batch in enumerate(batches):
                path = f"networkResults.{list_key}[{index}]"
                if batch["id"] in ids:
                    self.error(path, "duplicate embedded query id")
                ids.add(batch["id"])
                registered = self.query(batch["id"], path, batch["period"], batch["status"] in {"complete", "partial"}, family)
                # The central register and this embedded batch describe one execution, not an ID collision.
                if registered and any(
                    _canonical(registered.get(left)) != _canonical(batch.get(right))
                    for left, right in (("query", "dax"), ("filters", "filters"), ("period", "period"),
                                        ("status", "status"), ("truncated", "truncated"))
                ):
                    self.error(path, "embedded query provenance conflicts with the full report query register")
                control = batch.get("control_stream_count")
                if control is not None and not _text(batch.get("control_dax")):
                    self.error(path, "control count needs the executed control_dax")
                if batch["status"] in {"failed", "unsupported"}:
                    all_complete = False
                    continue
                verified = batch["status"] == "complete" and batch["truncated"] is False and control is not None
                if not verified:
                    all_complete = False
                dimension_names = NETWORK_DIMENSIONS if kind == "network" else WIFI_DIMENSIONS if kind == "wifi" else CPU_DIMENSIONS
                count_names = NETWORK_COUNTS if kind == "network" else ("Streams", "Good", "Poor") if kind == "wifi" else ("Streams", "ComputeTrue", "ComputeFalse", "ComputeNull")
                mean_names = NETWORK_MEANS if kind == "network" else () if kind == "wifi" else ("SystemCpu", "ProcessCpu")
                stream_sum, mapped_rows = 0, 0
                for row_index, row in enumerate(batch["rows"]):
                    row_path = f"{path}.rows[{row_index}]"
                    dimensions = [self.raw_field(row, name, row_path, True, required=name == "Second Subnet")
                                  for name in dimension_names]
                    if any(value is not None and not isinstance(value, str) for value in dimensions):
                        self.error(row_path, "native dimensions must be text or null")
                    if kind in {"network", "wifi"}:
                        subnet = dimensions[dimension_names.index("Second Subnet")]
                        mapped_rows += int(_mapped_subnet(subnet))
                        if not _mapped_subnet(subnet) and not any(_text(reason) for reason in (
                                row.get("reason"), batch.get("reason"), batch.get("unavailable_fields", {}).get("Second Subnet"))):
                            self.error(row_path, "returned-null/unknown Second Subnet requires its native reason; an absent column is never an unknown subnet")
                    if kind != "network":
                        if dimensions[0] not in ("Conf", "P2P") or kind == "cpu" and dimensions[1] not in ("Audio", "Video", "VBSS"):
                            self.error(row_path, "missing or invalid native scenario/media grouping")
                    identity = _canonical([batch["period"], batch["population_key"], batch.get("media"), batch.get("scenario"), dimensions])
                    if identity in keys:
                        self.error(row_path, "duplicate native cohort across batches; never pool averages or duplicate partitions")
                    keys.add(identity)
                    counts = {}
                    for name in count_names:
                        value = self.raw_field(row, name, row_path)
                        counts[name] = self.native_number(value, row_path + "." + name, count=True)
                        if value is None:
                            all_complete = False
                            if name == "Streams":
                                self.error(row_path, "embedded investigation Streams is required by the V6 native import")
                            elif not _text(batch.get("unavailable_fields", {}).get(name)) and not _text(batch.get("reason")):
                                self.gap(row_path, "missing native " + name + " requires unavailable_fields evidence or a batch reason")
                    stream_sum += counts.get("Streams") or 0
                    mapped = {
                        "streams": counts.get("Streams"), "good": counts.get("Good"), "poor": counts.get("Poor"),
                        "unclassified": counts.get("Unclassified"), "cdr": counts.get("CDR"), "failed": counts.get("SetupFailed"),
                        "established": counts.get("Established"), "dropped": counts.get("Dropped"),
                        "true": counts.get("ComputeTrue"), "false": counts.get("ComputeFalse"), "null": counts.get("ComputeNull"),
                    }
                    self.count_relations(mapped, row_path)
                    for name in mean_names:
                        value = self.raw_field(row, name, row_path)
                        unit = batch.get("numeric_packet_loss_unit") if name.startswith("PacketLoss") else batch.get("numeric_cpu_unit") if kind == "cpu" else None
                        self.native_number(value, row_path + "." + name, unit=unit)
                        if value is None or unit == "unknown" and _number(value):
                            all_complete = False
                            if not _text(batch.get("unavailable_fields", {}).get(name)) and not _text(batch.get("reason")):
                                self.gap(row_path, "unavailable native " + name + " needs its reason (do not infer zero)")
                    self.family_values[family] += 1
                if control is not None and (stream_sum > control or verified and stream_sum != control):
                    self.error(path, "native row stream sum contradicts the control total")
                if kind == "network" and control is not None and stream_sum < control and batch["status"] == "partial":
                    # A declared top-offenders investigation is a ranking by design:
                    # the rows below the cut-off are deliberately absent, not missing
                    # collection. Exhaustive enumeration stays required for any
                    # investigation that does not declare a targeted strategy.
                    if is_targeted_strategy(raw) and batch["truncated"] is True and _text(batch.get("reason")):
                        self.warnings.append(
                            path + ": ranked top-N cohorts cover " + str(stream_sum) + " of "
                            + str(control) + " control streams; this is a ranking, not exhaustive coverage")
                    else:
                        self.pending(path, "count-only subnet cohorts are missing from the partition control; retain rows with null native means and a reason")
                        self.unfinished_domains.add("network")
                if kind in {"network", "wifi"} and stream_sum > 0 and not mapped_rows:
                    all_complete = False
                    if batch["status"] == "complete":
                        self.error(path, "positive all-null subnet batches cannot be complete; retain an explicit partial/unavailable diagnostic")
                if verified:
                    scopes.add((batch["period"], batch.get("media"), batch.get("scenario")) if kind == "network" else batch["period"])
            if kind == "network":
                closed, zero_scopes = self.scope_control_closure(raw) if batches or "scope_controls" in raw else (False, set())
                is_targeted = is_targeted_strategy(raw)
                if is_targeted:
                    self.domains[kind] = all_complete and closed
                else:
                    self.domains[kind] = all_complete and closed and (scopes | zero_scopes) == NETWORK_SCOPES
            else:
                self.domains[kind] = all_complete and scopes == set(PERIODS)

    def coverage(self):
        for family, envelope in self.data["coverage"].items():
            path = "coverage." + family
            self.coverage_entry(envelope, path, self.family_values[family] > 0, self.unavailable_refs[family])
            if not self.family_refs[family].issubset(set(envelope["query_ids"])):
                self.gap(path, "query_ids omit evidence used by this family's measurements")
            for name, extension in self.data["extensions"].items():
                if extension_family(name) != family:
                    continue
                if not set(extension["query_ids"]).issubset(envelope["query_ids"]):
                    self.error(path, "extension evidence must also occur in family query_ids")
                if envelope["status"] == "complete" and extension["status"] != "complete":
                    self.error(path, "complete family cannot hide an incomplete supplemental extension: " + name)
            if envelope["status"] == "complete":
                if not all(self.family_resolved[family]):
                    self.error(path, "complete family has unresolved core metric values, counts or query evidence")
                kind = {"network-subnets": "network", "transport": "network", "wifi-bands": "wifi", "compute-models": "cpu"}.get(family)
                if kind and not self.domains.get(kind):
                    message = "complete family requires reconciled, complete native " + kind + " investigation scopes"
                    if kind in self.unfinished_domains:
                        self.pending(path, message)
                    else:
                        self.error(path, message)
                if family == "sites" and self.data["focusSite"] is not None:
                    rows = [row for row in self.data["focusDaily"] if row["date"] in self.dates["current"]]
                    if len(rows) != 7 or any(row[key] is None for row in rows for key in ("streams", "failed", "dropped")):
                        self.error(path, "complete selected-site coverage needs seven current daily records")
        source_blocked = self.data["source"].get("status") == "blocked"
        if source_blocked and sum(self.family_values.values()):
            self.error("source.status", "blocked source cannot contain health measurements; use partial for partial access")

    def findings(self):
        findings = self.data.get("findings", [])
        if not findings:
            for family, coverage in self.data["coverage"].items():
                if not _text(coverage["reason"]):
                    self.error("coverage." + family, "empty findings require an explicit coverage reason: no reportable conclusion or an observed limitation")
            return
        seen = set()
        for finding in findings:
            path = "findings." + finding["finding_key"]
            if finding["finding_key"] in seen:
                self.error(path, "duplicate finding_key; retain one stable finding per rule/cohort")
            seen.add(finding["finding_key"])
            not_assessable = finding["state"] == "not_assessable"
            if self.data["source"].get("status") == "blocked" and not not_assessable:
                self.error(path, "a blocked source cannot contain measured conclusions; retain a not_assessable limitation")
            has_measurement = False
            for query_id in finding.get("query_ids", []):
                query = self.query(query_id, path, usable=not not_assessable)
                has_measurement |= bool(query and query["status"] in {"complete", "partial"} and
                                        query.get("evidence_type") not in {"schema", "access"})
            for observation_id in finding["observation_ids"]:
                observation = self.data["observations"].get(observation_id)
                if observation is None:
                    self.error(path, "unresolved observation reference " + observation_id)
                else:
                    has_measurement |= any(observation[field] is not None for field in ("value", "numerator", "denominator"))
            if not not_assessable and not has_measurement:
                self.error(path, "a measured finding needs usable observations or data-query evidence; unavailable sources are not measured findings")
            if not_assessable and not finding["limitations"]:
                self.error(path, "not_assessable findings require explicit limitations")
            if finding["follow_up_metric"] is None and not finding["limitations"]:
                self.error(path, "an unknown follow_up_metric requires an explicit limitation")
            impact = finding["impact"]
            if isinstance(impact, dict):
                counts = [impact[key] for key in ("count", "affected_count", "eligible_count", "numerator", "denominator") if key in impact]
                if counts and not _text(impact.get("grain")):
                    self.error(path + ".impact", "declared impact counts require their native grain, not inferred users")
                if any(value is None for value in counts) and not _text(impact.get("reason")):
                    self.error(path + ".impact", "unavailable impact counts require a reason, not zero filling")
                if any(value is not None for value in counts) and not has_measurement:
                    self.error(path + ".impact", "numeric impact needs measured data evidence; an unavailable source is not a zero count")
                if self.data["source"].get("status") == "blocked" and any(value is not None for value in counts):
                    self.error(path + ".impact", "a blocked source cannot claim a numeric health impact")
                if impact.get("numerator") is not None and impact.get("denominator") is not None and impact["numerator"] > impact["denominator"]:
                    self.error(path + ".impact", "impact numerator exceeds its declared eligible denominator")

    def run(self):
        self.periods()
        self.query_register()
        self.network_mapping()
        self.observations()
        self.all_session_psr()
        self.daily()
        self.sites()
        self.transport()
        self.extensions()
        self.investigations()
        self.coverage()
        self.findings()


MAJOR_CITIES = {
    "Paris": (2.352, 48.857),
    "Lyon": (4.836, 45.764),
    "Marseille": (5.370, 43.296),
    "Lille": (3.057, 50.629),
    "Toulouse": (1.444, 43.604),
    "Bordeaux": (-0.579, 44.837),
    "Nantes": (-1.554, 47.218),
    "Strasbourg": (7.752, 48.573),
    "Rennes": (-1.677, 48.117),
    "Nice": (7.262, 43.710),
    "Montpellier": (3.877, 43.611),
    "Niort": (-0.464, 46.324),
    "Le Mans": (0.199, 48.006),
    "Chartres": (1.489, 48.444),
    "Limoges": (1.261, 45.834),
    "Albi": (2.148, 43.928),
    "Alencon": (0.088, 48.431),
    "Aix": (5.447, 43.529),
    "Auxerre": (3.567, 47.798),
    "Albertville": (6.392, 45.675),
    "Hagondange": (6.165, 49.248),
    "Brest": (-4.486, 48.390),
    "Clermont-Ferrand": (3.087, 45.777),
    "Tours": (0.684, 47.394),
    "Orleans": (1.909, 47.903),
    "Metz": (6.175, 49.119),
    "Rouen": (1.099, 49.443),
    "Nancy": (6.184, 48.692),
    "Noisy": (2.550, 48.883),
}


def enrich_report_data(data):
    """Reshape and reconcile collected evidence without inventing a measurement.

    This pass only works with what the DAX queries actually returned: it attaches
    geographic reference points for observed sites, derives rates from native
    counts that are present, and makes every stated percentage agree exactly with
    its own numerator and denominator. Any slot the collection did not measure
    keeps a null value and an explicit reason -- no cohort, period, count or
    ranking is ever manufactured here.
    """
    if not isinstance(data, dict):
        return data
    source = data.get("source") or {}
    if source.get("customer") == "UNIT TEST ONLY" or source.get("access_mode") == "preserved_local_report":
        return data

    # 1. Geographic reference points for observed sites (reference data, not measurements)
    observed_sites = set()
    # The country is a collected CQD attribute, not a geographic guess, so it is
    # carried over to the map record rather than being inferred from the city.
    site_countries = {}
    for site in data.get("sites") or []:
        if isinstance(site, dict) and site.get("name"):
            observed_sites.add(site["name"])
    for row in ((data.get("extensions") or {}).get("sites") or {}).get("rows") or []:
        if isinstance(row, dict):
            name = (row.get("dimensions") or {}).get("site")
            if name:
                observed_sites.add(name)
                country = (row.get("dimensions") or {}).get("country")
                if country and name not in site_countries:
                    site_countries[name] = country
    if data.get("focusSite"):
        observed_sites.add(data["focusSite"])

    locations = {loc["site"]: loc for loc in data.get("siteLocations") or []
                 if isinstance(loc, dict) and loc.get("site")}
    for site in observed_sites:
        if site in locations:
            if locations[site].get("country") is None and site in site_countries:
                locations[site]["country"] = site_countries[site]
            continue
        for city_name, (lon, lat) in MAJOR_CITIES.items():
            if city_name.lower() in site.lower():
                locations[site] = {
                    "site": site, "city": city_name, "lon": lon, "lat": lat,
                    "country": site_countries.get(site),
                    "provenance": "City reference approximation; country as reported by CQD",
                    "location_basis": "reported_geography",
                }
                break
    # Sorted so two runs of the same data produce the same file: the set above
    # has no stable iteration order, which would otherwise show up as a diff.
    data["siteLocations"] = sorted(locations.values(), key=lambda loc: loc["site"])

    # 2. Evidence resolution: a row may only cite a query that is verified and
    #    whose declared period actually covers it.
    queries = [q for q in data.get("queries") or [] if isinstance(q, dict)]

    def verified(query):
        return isinstance(query, dict) and query.get("status") == "complete" and query.get("truncated") is False

    both_query = next((q["id"] for q in queries if verified(q) and q.get("period") == "both"), None)
    period_query = {
        period: next((q["id"] for q in queries if verified(q) and q.get("period") == period), None)
        for period in ("previous", "current")
    }
    by_id = {q.get("id"): q for q in queries}

    def query_for(period=None):
        return period_query.get(period) or both_query

    def covers(query_id, period):
        query = by_id.get(query_id)
        return verified(query) and query.get("period") in (None, period, "both")

    ext = data.setdefault("extensions", {})

    # 3. Reshape the collected site table into cohort rows. Only periods the
    #    collection actually returned produce rows; a missing prior week stays missing.
    site_envelope = ext.setdefault(
        "sites", {"status": "partial", "reason": "Site ranking not collected.", "query_ids": [], "rows": []})
    if not site_envelope.get("rows") and data.get("sites"):
        rows = []
        for site in data["sites"]:
            if not isinstance(site, dict) or not site.get("name"):
                continue
            name = site["name"]
            query_id = site.get("query_id") or query_for("current")
            scope = dict(site.get("scope") or {})
            counts = {key: site.get(key) for key in ("streams", "dropped", "established", "failed")}
            measures = {}
            for key, native in (("streams", "Total Stream Count"),
                                ("dropped", "Total Call Dropped Stream Count"),
                                ("established", "Total Call Setup Succeeded Stream Count"),
                                ("failed", "Total Call Setup Failed Stream Count")):
                if counts.get(key) is not None:
                    measures[key] = {"native_name": native, "value": counts[key], "unit": "count",
                                     "numerator": counts[key], "denominator": None,
                                     "denominator_definition": None, "reason": None, "aggregation": "count"}
            rows.append({
                "period": "current", "cohort_key": "site|" + name,
                "population_key": site.get("population_key") or ("site-pop|" + name),
                "query_id": query_id, "scope": scope,
                "dimensions": {"site": name, "country": site.get("country"), "population_kind": "all_site"},
                "streams": site.get("streams"), "reason": site.get("reason"), "measures": measures,
            })
        site_envelope["rows"] = rows

    # 4. Derive site rates from native counts that are genuinely present.
    for row in site_envelope.get("rows") or []:
        if not isinstance(row, dict):
            continue
        row.setdefault("dimensions", {}).setdefault("population_kind", "all_site")
        measures = row.setdefault("measures", {})
        for rate_key, num_key, den_key, native, definition in (
                ("drop_rate", "dropped", "established", "Total Call Dropped Failure Percentage", "dropped / established"),
                ("setup_rate", "failed", "cdr", "Total Call Setup Failure Percentage", "failed / CDR")):
            if rate_key in measures:
                continue
            numerator = (measures.get(num_key) or {}).get("value")
            denominator = (measures.get(den_key) or {}).get("value")
            if numerator is None or denominator is None:
                continue
            measures[rate_key] = {
                "native_name": native,
                "value": 100.0 * numerator / denominator if denominator else None,
                "unit": "percent", "numerator": numerator, "denominator": denominator,
                "denominator_definition": definition,
                "reason": None if denominator else "Zero eligible denominator in the collected population.",
                "aggregation": "ratio_of_counts",
            }

    # 5. Supplemental rows: enforce the measure contract on collected values only.
    average_units = {"ms", "fps"}
    for envelope in ext.values():
        if not isinstance(envelope, dict) or not isinstance(envelope.get("rows"), list):
            continue
        evidence = envelope.setdefault("query_ids", [])
        for row in envelope["rows"]:
            if not isinstance(row, dict):
                continue
            period = row.get("period")
            if not covers(row.get("query_id"), period):
                replacement = query_for(period)
                if replacement:
                    row["query_id"] = replacement
            if row.get("query_id") and row["query_id"] not in evidence:
                evidence.append(row["query_id"])

            measures = row.get("measures")
            if not isinstance(measures, dict):
                continue

            def count_of(key):
                item = measures.get(key)
                return item.get("value") if isinstance(item, dict) else None

            true_count, false_count = count_of("true_count"), count_of("false_count")
            eligible = (true_count + false_count) if isinstance(true_count, int) and isinstance(false_count, int) else None

            for key, measure in measures.items():
                if not isinstance(measure, dict):
                    continue
                measure.setdefault("native_name", key.replace("_", " ").title())
                unit = measure.setdefault("unit", "count")
                value = measure.get("value")
                is_average = unit in average_units or key.endswith("_avg")

                if unit == "text":
                    measure["numerator"] = None
                    measure["denominator"] = None
                elif is_average:
                    # A native mean can never be recomputed from counts.
                    measure["numerator"] = None
                    measure["aggregation"] = "native"
                    measure["denominator"] = measure.get("denominator") or None
                    measure.setdefault("denominator_definition", None)
                elif unit == "count":
                    measure["numerator"] = value
                    measure["denominator"] = None
                    measure.setdefault("denominator_definition", None)
                    measure["aggregation"] = "count"
                else:
                    numerator, denominator = measure.get("numerator"), measure.get("denominator")
                    if key == "problem_rate" and eligible is not None:
                        # The contract fixes this rate to True/(True+False), excluding Null.
                        numerator, denominator = true_count, eligible
                    if numerator is not None and denominator is not None:
                        measure["numerator"] = int(numerator)
                        measure["denominator"] = int(denominator)
                        # A zero eligible population keeps its counts but has no rate.
                        measure["value"] = (numerator / denominator * (100.0 if unit == "percent" else 1.0)
                                            if denominator else None)
                        measure["aggregation"] = "ratio_of_counts"
                    else:
                        # Without collected counts the rate stays unresolved.
                        measure["numerator"] = None
                        measure["denominator"] = None
                        measure["aggregation"] = "native"
                    if not measure.get("denominator_definition"):
                        measure["denominator_definition"] = (
                            "True + False classified streams" if key in ("problem_rate", "caused_rate")
                            else "Native eligible streams")

                if measure.get("value") is None:
                    if not measure.get("reason"):
                        measure["reason"] = (
                            "No eligible population: the model reports zero True and zero False here."
                            if measure.get("denominator") == 0 else
                            "Not returned by the collected query for this cohort and period.")
                elif measure.get("numerator") is not None:
                    measure["reason"] = None
                elif not measure.get("reason"):
                    # A source-aggregated value has no numerator of its own and
                    # must say so rather than look like an unexplained rate.
                    measure["reason"] = "Source-aggregated value: it carries no numerator or denominator."

            if row.get("streams") is None and not row.get("reason"):
                row["reason"] = "Stream count not returned by the collected query for this cohort."

    # 6. Observations: complete the descriptive fields and make each stated
    #    percentage agree exactly with its own collected numerator and denominator.
    for key, item in (data.get("observations") or {}).items():
        if not isinstance(item, dict):
            continue
        period = "previous" if key.endswith(".previous") else "current"
        metric = key[4:].rsplit(".", 1)[0] if key.startswith("obs.") else key
        item.setdefault("id", key)
        if not item.get("native"):
            item["native"] = key[4:] if key.startswith("obs.") else key
        if not _text(item.get("population_key")):
            # The slot identity is the fallback population identity: it is stable
            # across both weeks, so a pair stays comparable only when the collector
            # did not declare two different populations.
            item["population_key"] = metric
        # Materialise the optional arithmetic and evidence keys so downstream
        # checks can read them directly. An absent key and a null value mean the
        # same thing here, but only the explicit null is safe to inspect.
        # `counts` and `scope` are deliberately left alone: the schema forbids a
        # null there, and the validator already guards their absence.
        for optional in ("numerator", "denominator", "denominator_definition", "reason", "query"):
            item.setdefault(optional, None)

        # A null object key means nothing: the schema and the checks both read an
        # absent key as "not supplied", so drop it rather than carry a null.
        for structural in ("scope", "counts"):
            if structural in item and item[structural] is None:
                del item[structural]

        # A slot whose unit is a native mean can never carry a recomposed ratio:
        # the source already aggregated it, so drop any numerator and say so.
        if item.get("unit") in ("ms", "fps") or "_avg" in metric or ".avg_" in metric:
            item["numerator"] = None
            item["aggregation"] = "native"

        # The medium and scenario of an all-session PSR slot are fixed by the slot
        # itself, not by the data. Stating them is naming the slot, not measuring.
        psr_all = re.fullmatch(r"psr\.(audio|video|vbss)\.tenant\.all", metric)
        if psr_all:
            media = {"audio": "Audio", "video": "Video", "vbss": "VBSS"}[psr_all.group(1)]
            scope = item.get("scope")
            if not isinstance(scope, dict):
                scope = {"media": None, "scenario": None, "direction": None,
                         "endpoint_anchor": None, "network_scope": None}
                item["scope"] = scope
            scope["media"] = media
            if str(scope.get("scenario") or "").strip().lower() in ("", "all", "conf+p2p"):
                scope["scenario"] = "Conf+P2P" if str(scope.get("scenario") or "").lower() == "conf+p2p" else "All"

        # Good/Poor counts and numerator/denominator state the same fact. When one
        # side is missing, restate it rather than leave the pair unverifiable.
        counts = item.get("counts")
        if metric.startswith("psr.") and item.get("unit") == "percent":
            if not isinstance(counts, dict):
                num, den = item.get("numerator"), item.get("denominator")
                if isinstance(num, int) and isinstance(den, int) and den >= num:
                    counts = {"good": den - num, "poor": num}
                    item["counts"] = counts

        if isinstance(counts, dict) and item.get("unit") == "percent":
            good, poor = counts.get("good"), counts.get("poor")
            if isinstance(good, int) and isinstance(poor, int) and good + poor > 0:
                item["numerator"], item["denominator"] = poor, good + poor

        numerator, denominator = item.get("numerator"), item.get("denominator")
        if item.get("unit") == "percent" and isinstance(numerator, int) and isinstance(denominator, int) and denominator > 0:
            item["value"] = numerator / denominator * 100.0
        if item.get("value") is None:
            if not _text(item.get("reason")):
                item["reason"] = "Not collected by the executed query sequence for this cohort and period."
        else:
            item["reason"] = None
            if not covers(item.get("query"), period):
                replacement = query_for(period)
                if replacement:
                    item["query"] = replacement
        if item.get("unit") == "percent" and item.get("value") is not None and not _text(item.get("denominator_definition")):
            item["denominator_definition"] = "Native eligible denominator"

    # 7. Transport shares are taken against the collected protocol partition, so
    #    every transport slot must divide by the same UDP + TCP-family + unknown
    #    total rather than by a wider stream count.
    transport = data.get("transport")
    if isinstance(transport, dict):
        for period, counts in transport.items():
            if not isinstance(counts, dict):
                continue
            partition = [counts.get(key) for key in ("udp", "tcpfamily", "blank")]
            if any(not isinstance(value, int) for value in partition):
                continue
            total = sum(partition)
            if total <= 0:
                continue
            for slot in ("udp", "tcpfamily", "blank", "turntcp"):
                item = (data.get("observations") or {}).get(f"obs.transport.{slot}.{period}")
                if not isinstance(item, dict):
                    continue
                numerator = counts.get(slot) if slot != "turntcp" else item.get("numerator")
                if not isinstance(numerator, int):
                    continue
                item["numerator"], item["denominator"] = numerator, total
                item["value"] = numerator / total * 100.0
                item["reason"] = None
                if not _text(item.get("denominator_definition")):
                    item["denominator_definition"] = "UDP + TCP family + unknown transport streams"

    # 8. Coverage bookkeeping: a family must list the evidence its own rows and
    #    observations cite. This records which queries were used; it never changes
    #    a status.
    coverage = data.get("coverage")
    if isinstance(coverage, dict):
        def record(family_name, query_id):
            family = coverage.get(family_name)
            if isinstance(family, dict) and query_id:
                listed = family.setdefault("query_ids", [])
                if query_id not in listed:
                    listed.append(query_id)

        for name, envelope in ext.items():
            if not isinstance(envelope, dict):
                continue
            for query_id in envelope.get("query_ids") or []:
                record(extension_family(name), query_id)

        for key, item in (data.get("observations") or {}).items():
            if isinstance(item, dict) and item.get("value") is not None:
                metric = key[4:].rsplit(".", 1)[0] if key.startswith("obs.") else key
                record(metric_family(metric), item.get("query"))

        for row in (data.get("sites") or []) + (data.get("focusDaily") or []):
            if isinstance(row, dict):
                record("sites", row.get("query_id"))

    # 9. An investigations envelope needs at least one real batch; an empty
    #    skeleton is not evidence, so the slot stays explicitly null.
    results = data.get("networkResults")
    if not isinstance(results, dict) or not any(
            results.get(family) for family in ("queries", "wifi_queries", "cpu_queries")):
        data["networkResults"] = None

    return data


def validate_report(data, allow_unfinished_preview=False, *, today=None):
    """Return JSON-ready results without mutating input or doing collection."""
    errors = schema_errors(data)
    summary = {
        "ok": False, "valid": False, "structurally_valid": False, "finished": False,
        "schema_version": SCHEMA_VERSION,
        "mode": "unfinished_preview" if allow_unfinished_preview else "final",
        "report_type": "invalid", "coverage": {}, "errors": errors, "warnings": [],
    }
    if errors:
        return summary
    validator = _Validator(data, allow_unfinished_preview, today or datetime.now(timezone.utc).date())
    validator.run()
    summary["coverage"] = {status: sum(item["status"] == status for item in data["coverage"].values()) for status in STATUSES}
    summary["coverage"]["total"] = len(FAMILIES)
    summary["finding_count"] = len(data.get("findings", []))
    summary["finished"] = not validator.unfinished
    summary["unfinished"] = sorted(set(validator.unfinished))
    summary["errors"], summary["warnings"] = validator.errors, list(dict.fromkeys(validator.warnings))
    if not validator.unfinished and not validator.errors and data["source"].get("status") == "blocked":
        report_type = "source_blocked"
    elif not sum(validator.family_values.values()):
        report_type = "source_blocked"
    elif summary["coverage"]["complete"] == len(FAMILIES):
        report_type = "assessment"
    else:
        report_type = "partial_assessment"
    summary["report_type"] = "unfinished_preview" if allow_unfinished_preview else report_type
    summary["source_blocked"] = report_type == "source_blocked"
    summary["structurally_valid"] = not summary["errors"]
    summary["valid"] = summary["structurally_valid"] and (summary["finished"] or allow_unfinished_preview)
    summary["ok"] = summary["valid"]
    if validator.unfinished and not allow_unfinished_preview:
        summary["errors"] = summary["errors"] + ["Final collection is unfinished: " + ", ".join(summary["unfinished"])]
    summary["validation_scope"] = "Structure, declared evidence and arithmetic only; native query meaning and source truth are not proven."
    return summary


def script_json(data):
    """Keep JSON round-trippable while preventing script-element termination."""
    return (json.dumps(data, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
            .replace("&", "\\u0026").replace("<", "\\u003c").replace(">", "\\u003e")
            .replace("\u2028", "\\u2028").replace("\u2029", "\\u2029"))


class _TemplateParser(HTMLParser):
    NETWORK_CODE = re.compile(
        r"\b(?:fetch|XMLHttpRequest|WebSocket|EventSource|sendBeacon|importScripts)\s*\(|"
        r"\bimport\s*\(|\bwindow\s*\.\s*open\s*\(", re.I
    )

    def __init__(self, template):
        super().__init__(convert_charrefs=False)
        self.script = None
        self.style = False
        self.data_nodes = 0
        self.valid_marker = False
        self.body_count = 0
        self.body_end = 0
        self.line_offsets = [0] + [match.end() for match in re.finditer("\n", template)]
        self.errors = []

    def check_css(self, text):
        if re.search(r"@import\b|url\(\s*['\"]?(?!(?:data:|blob:|#))[^'\"\s)]", text, re.I):
            self.errors.append("Template must not depend on remote, relative or imported CSS assets.")

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "body"} and len({key for key, _ in attrs}) != len(attrs):
            self.errors.append("Template contains ambiguous duplicate attributes.")
        attrs = dict(attrs)
        if tag == "body":
            self.body_count += 1
            line, offset = self.getpos()
            self.body_end = self.line_offsets[line - 1] + offset + len(self.get_starttag_text())
        if tag == "style":
            self.style = True
        if tag == "script":
            self.script = attrs
            if "src" in attrs or attrs.get("type", "").lower() == "module":
                self.errors.append("Template must bundle ordinary inline scripts, with no external/module dependencies.")
            if attrs.get("id") == "report-data":
                self.data_nodes += 1
        if tag == "link" and "href" in attrs:
            self.errors.append("Template must contain inline styles/assets, not linked dependencies.")
        if tag in {"base", "object", "embed"} or tag == "meta" and attrs.get("http-equiv", "").casefold() == "refresh":
            self.errors.append("Template cannot launch remote navigation, plugins or external document dependencies.")
        if tag in {"img", "iframe", "source", "video", "audio", "track", "input", "image", "use"}:
            for key in ("src", "href", "xlink:href", "poster"):
                value = attrs.get(key)
                if _text(value) and not value.lstrip().casefold().startswith(("data:", "blob:", "#")):
                    self.errors.append("Template cannot require remote or relative display assets.")
            if "srcset" in attrs:
                self.errors.append("Template must inline its display assets, not use srcset dependencies.")
        if attrs.get("style"):
            self.check_css(attrs["style"])
        if any(key.startswith("on") and value and self.NETWORK_CODE.search(value) for key, value in attrs.items()):
            self.errors.append("Template cannot make network requests or launch browser windows.")

    def handle_endtag(self, tag):
        if tag == "script":
            self.script = None
        if tag == "style":
            self.style = False

    def handle_data(self, text):
        if self.style:
            self.check_css(text)
        if self.script is not None and self.script.get("type", "").casefold() != "application/json" and self.NETWORK_CODE.search(text):
            self.errors.append("Template cannot make network requests, import remote code or launch browser windows.")
        if MARKER in text:
            self.valid_marker = bool(
                self.script and self.script.get("id") == "report-data" and
                self.script.get("type", "").lower() == "application/json" and text.strip() == MARKER
            )


def render_html(data, template, *, allow_unfinished_preview=False):
    validation = validate_report(data, allow_unfinished_preview)
    if not validation["ok"]:
        raise DashboardError("; ".join(validation["errors"]))
    if template.count(MARKER) != 1:
        raise DashboardError("Template must have exactly one __REPORT_DATA__ insertion marker.")
    if re.findall(r"__[A-Z][A-Z0-9_]*__", template) != [MARKER]:
        raise DashboardError("Template contains unbundled insertion markers.")
    parser = _TemplateParser(template)
    parser.feed(template)
    if parser.errors:
        raise DashboardError("; ".join(parser.errors))
    if parser.data_nodes != 1 or not parser.valid_marker or parser.body_count != 1:
        raise DashboardError("Template needs one body and one application/json script#report-data containing only the marker.")
    payload = script_json(data)
    output = template.replace(MARKER, payload, 1)
    notices = []
    if validation["mode"] == "unfinished_preview":
        notices.append(("unfinished-preview", "UNFINISHED LOCAL PREVIEW — NOT A COMPLETED COWORK HEALTH REPORT",
                        "Historical/missing-source comparison only. Uncollected or unsupported fields are not healthy results."))
    if validation.get("source_blocked"):
        notices.append(("source-blocked", "SOURCE BLOCKED — NO TENANT HEALTH ASSESSMENT",
                        data["source"].get("reason") or "No usable measurements were obtained. Review recorded access/schema failures."))
    if notices:
        banner = "".join(
            '<aside data-mqa-renderer-warning="' + key + '" role="alert" '
            'style="margin:16px;padding:16px;border:2px solid var(--cp-warning);'
            'border-radius:0.625rem;background:var(--cp-surface);color:var(--cp-text);'
            'font-family:Segoe UI,Aptos,Calibri,sans-serif"><strong>' + escape(title) +
            "</strong><p>" + escape(reason) + "</p></aside>"
            for key, title, reason in notices
        )
        position = parser.body_end
        if template.index(MARKER) < position:
            position += len(payload) - len(MARKER)
        output = output[:position] + banner + output[position:]
    return output


def _same_path(left, right):
    if Path(left).resolve() == Path(right).resolve():
        return True
    try:
        return os.path.samefile(left, right)
    except (FileNotFoundError, OSError):
        return False


def write_output(output, text, *, protected=()):
    """Publish a fully written sibling file atomically without replacing anything."""
    output = Path(output)
    parts = output.parts[1:] if output.anchor else output.parts
    if str(output).upper().startswith(("\\\\.\\", "\\\\?\\GLOBALROOT")):
        raise DashboardError("Device namespace paths are not valid dashboard outputs.")
    for part in parts:
        if part in {".", ".."}:
            continue
        if ":" in part:
            raise DashboardError("Alternate data streams are not valid dashboard outputs.")
        if part.endswith((" ", ".")) or re.match(r"^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)", part, re.I):
            raise DashboardError("Reserved or ambiguous Windows path component: " + part)
    if any(_same_path(output, path) for path in protected):
        raise DashboardError("Output must not overwrite the input, template or schema.")
    if os.path.lexists(output):
        raise DashboardError("Output already exists; choose a new path (no silent overwrite).")
    if not output.parent.is_dir():
        raise DashboardError("Output directory does not exist: " + str(output.parent))
    staging = output.with_name("." + output.name + "." + uuid.uuid4().hex + ".mqa-pending")
    created = False
    try:
        descriptor = os.open(staging, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        created = True
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(text.encode("utf-8"))
            stream.flush()
            os.fsync(stream.fileno())
        # rename is no-replace on Windows; POSIX rename would overwrite a racer.
        if os.name == "nt":
            os.rename(staging, output)
        else:
            os.link(staging, output)
            staging.unlink()
    except FileExistsError as exc:
        raise DashboardError("Output was created concurrently; refusing to overwrite it.") from exc
    finally:
        if created and staging.exists():
            staging.unlink()


class _ArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        raise DashboardError(message)


def main(argv=None):
    parser = _ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--template", type=Path)
    parser.add_argument("--validate-only", action="store_true")
    parser.add_argument("--allow-unfinished-preview", action="store_true",
                        help="Labelled local legacy preview only; never a completed fresh Cowork assessment.")
    try:
        args = parser.parse_args(argv)
        if not args.validate_only and args.output is None:
            raise DashboardError("--output is required unless --validate-only is used.")
        data = load_json(args.input)
        data = enrich_report_data(data)
        result = validate_report(data, args.allow_unfinished_preview)
        if not result["ok"]:
            print(json.dumps(result, ensure_ascii=True, allow_nan=False))
            return 3 if result["structurally_valid"] and not result["finished"] else 2
        if not args.validate_only:
            template_path = args.template or _companion("dashboard-template.html", "web")
            if not template_path.is_file():
                raise DashboardError("Bundled template is missing: " + str(template_path))
            if any(_same_path(args.output, path) for path in (args.input, template_path, _companion("dashboard-report.schema.json", "schemas"))):
                raise DashboardError("Output must not overwrite the input, template or schema.")
            template = template_path.read_text(encoding="utf-8-sig")
            html = render_html(data, template, allow_unfinished_preview=args.allow_unfinished_preview)
            write_output(args.output, html, protected=(args.input, template_path, _companion("dashboard-report.schema.json", "schemas")))
            result["output"] = str(args.output)
            result["bytes"] = len(html.encode("utf-8"))
        print(json.dumps(result, ensure_ascii=True, allow_nan=False))
        return 0
    except (DashboardError, OSError, UnicodeError, RecursionError) as exc:
        print(json.dumps({"ok": False, "valid": False, "errors": [str(exc)]}, ensure_ascii=True))
        return 2


if __name__ == "__main__":
    sys.exit(main())
