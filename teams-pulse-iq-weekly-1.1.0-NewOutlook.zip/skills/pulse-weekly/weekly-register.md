# Teams MQA Review — query register

Reference material for the `pulse-weekly` skill. Every query the weekly run
executes is defined here, literally. Do not paraphrase a cell, and do not
invent a query that is not in the table.

### Substitutions

Expand these literally in every query. Do not paraphrase them.

- `@D` → `TREATAS({"YYYY-MM-DD", ... 7 dates of the week being queried ...}, CQD[Date])`
- `@D14` → `TREATAS({... the 14 dates of S−1 and S ...}, CQD[Date])`
- `@T` → `FILTER(VALUES(CQD[Test Call Type]), CQD[Test Call Type] = "NonTest")`
- `@IN` → `FILTER(VALUES(CQD[Second Inside Corp]), CQD[Second Inside Corp] = "Inside")`

`@T` is the locked report filter and is mandatory in **every** query: it removes
synthetic tests, bot probes and automated diagnostics from every population.

### Measure blocks

Expand these literally where a query names them.

`@M1` (reliability counts)
```
"Streams",SUM(CQD[Total Stream Count]),"Calls",SUM(CQD[Total Call Count]),"CDR",SUM(CQD[Total CDR Available Stream Count]),"Failed",SUM(CQD[Total Call Setup Failed Stream Count]),"Established",SUM(CQD[Total Call Setup Succeeded Stream Count]),"Dropped",SUM(CQD[Total Call Dropped Stream Count])
```

`@M2` (media good/poor counts)
```
"AGood",SUM(CQD[Audio Good Stream Count]),"APoor",SUM(CQD[Audio Poor Stream Count]),"VGood",SUM(CQD[Video Good Stream Count]),"VPoor",SUM(CQD[Video Poor Stream Count]),"SGood",SUM(CQD[VBSS Good Stream Count]),"SPoor",SUM(CQD[VBSS Poor Stream Count])
```

`@M3` (the ten classifiers — True, False and Null counts — plus video freezes)
```
"InT",SUM(CQD[Detected Inbound Network Problem True Count]),"InF",SUM(CQD[Detected Inbound Network Problem False Count]),"InN",SUM(CQD[Detected Inbound Network Problem Null Count]),"UpT",SUM(CQD[Detected Uplink Problem True Count]),"UpF",SUM(CQD[Detected Uplink Problem False Count]),"UpN",SUM(CQD[Detected Uplink Problem Null Count]),"MoT",SUM(CQD[Detected Media Modality Problem True Count]),"MoF",SUM(CQD[Detected Media Modality Problem False Count]),"MoN",SUM(CQD[Detected Media Modality Problem Null Count]),"LcT",SUM(CQD[Detected Local Compute Problem True Count]),"LcF",SUM(CQD[Detected Local Compute Problem False Count]),"LcN",SUM(CQD[Detected Local Compute Problem Null Count]),"LdT",SUM(CQD[Detected Local Input Device Problem True Count]),"LdF",SUM(CQD[Detected Local Input Device Problem False Count]),"LdN",SUM(CQD[Detected Local Input Device Problem Null Count]),"CdT",SUM(CQD[Detected Compute Device Causing Problem True Count]),"CdF",SUM(CQD[Detected Compute Device Causing Problem False Count]),"CdN",SUM(CQD[Detected Compute Device Causing Problem Null Count]),"IdT",SUM(CQD[Detected Input Device Causing Problem True Count]),"IdF",SUM(CQD[Detected Input Device Causing Problem False Count]),"IdN",SUM(CQD[Detected Input Device Causing Problem Null Count]),"OuT",SUM(CQD[Detected Other User Uplink Problem True Count]),"OuF",SUM(CQD[Detected Other User Uplink Problem False Count]),"OuN",SUM(CQD[Detected Other User Uplink Problem Null Count]),"OcT",SUM(CQD[Detected Other User Compute Problem True Count]),"OcF",SUM(CQD[Detected Other User Compute Problem False Count]),"OcN",SUM(CQD[Detected Other User Compute Problem Null Count]),"OdT",SUM(CQD[Detected Other User Device Problem True Count]),"OdF",SUM(CQD[Detected Other User Device Problem False Count]),"OdN",SUM(CQD[Detected Other User Device Problem Null Count]),"Freeze",SUM(CQD[Video Poor Due to Freeze Count])
```

`@M4` (network values — pass-through, never re-aggregated)
```
"RTT",SUM(CQD[Avg Round Trip]),"RTTMax",SUM(CQD[Avg Round Trip Max]),"Jitter",SUM(CQD[Avg Jitter]),"JitterMax",SUM(CQD[Avg Jitter Max]),"Loss",SUM(CQD[Avg Packet Loss Rate]),"LossMax",SUM(CQD[Avg Packet Loss Rate Max])
```

`@M5` (endpoint compute — pass-through, never re-aggregated)
```
"SysCPU",SUM(CQD[Avg Second System CPU Resource Usage Average]),"ProcCPU",SUM(CQD[Avg Second Process CPU Resource Usage Average])
```

`@M6` (subnet investigation metrics — the aliases the investigation contract reads)
```
"Streams",SUM(CQD[Total Stream Count]),"CDR",SUM(CQD[Total CDR Available Stream Count]),"SetupFailed",SUM(CQD[Total Call Setup Failed Stream Count]),"Established",SUM(CQD[Total Call Setup Succeeded Stream Count]),"Dropped",SUM(CQD[Total Call Dropped Stream Count]),"JitterMs",SUM(CQD[Avg Jitter]),"JitterMaxAvgMs",SUM(CQD[Avg Jitter Max]),"PacketLoss",SUM(CQD[Avg Packet Loss Rate]),"PacketLossMaxAvg",SUM(CQD[Avg Packet Loss Rate Max]),"RoundTripMs",SUM(CQD[Avg Round Trip]),"RoundTripMaxAvgMs",SUM(CQD[Avg Round Trip Max])
```

`@M7` (compute-model investigation metrics)
```
"Streams",SUM(CQD[Total Stream Count]),"ComputeTrue",SUM(CQD[Detected Local Compute Problem True Count]),"ComputeFalse",SUM(CQD[Detected Local Compute Problem False Count]),"ComputeNull",SUM(CQD[Detected Local Compute Problem Null Count]),"SystemCpu",SUM(CQD[Avg Second System CPU Resource Usage Average]),"ProcessCpu",SUM(CQD[Avg Second Process CPU Resource Usage Average])
```

`@G1` (subnet investigation grouping — every dimension the contract reads)
```
CQD[Second Subnet], CQD[Second Reflexive Local IP Network], CQD[Second Building Name], CQD[Second Inside Corp], CQD[Second Network Connection Detail], CQD[Stream Direction], CQD[Second Transport Protocol], CQD[Second ASN Country]
```

`@F1` (media and scenario are both reported — never blank)
```
FILTER(VALUES(CQD[Media Type]), CQD[Media Type] IN {"Audio","Video","VBSS"}), FILTER(VALUES(CQD[Session Type]), CQD[Session Type] IN {"Conf","P2P"})
```

`@F2` (TCP family only — the transports the TCP concentration panel ranks)
```
FILTER(VALUES(CQD[Second Transport Protocol]), CQD[Second Transport Protocol] IN {"TCP","TLS","TurnTCP","MultiTurnTCP","CompoundTCP"})
```

`@F3` (everything that is not TCP family, blank transport included)
```
FILTER(VALUES(CQD[Second Transport Protocol]), NOT(CQD[Second Transport Protocol] IN {"TCP","TLS","TurnTCP","MultiTurnTCP","CompoundTCP"}))
```

`@F4` (Wi-Fi audio, a single reported band)
```
FILTER(VALUES(CQD[Second Network Connection Detail]), CQD[Second Network Connection Detail]="Wifi"), FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type] IN {"Conf","P2P"})
```

### Templates

`T1` — grouped aggregate:
```dax
EVALUATE SUMMARIZECOLUMNS( <GROUP>, @D, @T, <FILTERS>, <MEASURES> )
```

`T2` — ranked aggregate (use the stated `N` and the full ordering clause):
```dax
EVALUATE TOPN( <N>, SUMMARIZECOLUMNS( <GROUP>, @D, @T, <FILTERS>, <MEASURES> ), <ORDER> )
```
`TOPN` returns **every row tied at the cut-off**, so a single key over a mostly
zero measure can return hundreds of rows instead of `N`. Each ranked query below
therefore states a second ordering key; keep both.

Never wrap `SUMMARIZECOLUMNS` in an outer `FILTER(...)` on a measure alias: it
breaks query folding and silently returns zero rows. Rank with `TOPN` instead.

### Register

Run every query **twice — once with Week S dates, once with Week S−1 dates** —
except Q2 and Q3, which use `@D14` and run once, and Q15, which runs for Week S
only. Record each execution separately in `queries[]` with its id, period, exact
DAX, filters, status and `truncated: false`.
In `weekly-raw.json`, do not echo the DAX: `assemble_dashboard.py` rebuilds the
exact query from this register, while any recorded `"dax"` takes precedence.

Every cell below is literal DAX. Never copy a note or a comment into a query.

| id | Tpl | GROUP | FILTERS | MEASURES |
|----|-----|-------|---------|----------|
| Q1 | T1 | `CQD[Session Type]` | – | `@M1` |
| Q2 | T1 | `CQD[Date]` | – | `@M1` |
| Q3 | T1 | `CQD[Date]` | `@IN` | `@M1` |
| Q4 | T1 | `CQD[Media Type], CQD[Session Type]` | – | `@M2, @M3` |
| Q5 | T1 | `CQD[Media Type], CQD[Session Type], CQD[Second Inside Corp], CQD[Second Network Connection Detail]` | – | `@M1, @M2` |
| Q6 | T1 | `CQD[Connectivity Ice Pair], CQD[Inside Corp Pair]` | `FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="P2P")` | `@M1, @M2` |
| Q7 | T1 | `CQD[Second User Agent Category], CQD[Session Type]` | – | `@M1, @M2, @M3, @M5` |
| Q8 | T1 | `CQD[Second Transport Protocol]` | – | `@M1` |
| Q9 | T1 | `CQD[Second Wifi Band], CQD[Second Wifi Radio Type], CQD[Session Type]` | `FILTER(VALUES(CQD[Second Network Connection Detail]), CQD[Second Network Connection Detail]="Wifi")` | `@M1, @M2, @M4` |
| Q10 | T1 | `CQD[Second Network Connection Detail], CQD[Stream Direction], CQD[Session Type]` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio")` | `@M4` |
| Q11 | T1 | `CQD[Second VPN Estimated], CQD[Second Network Mapped VPN]` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio")` | `@M1, @M2` |
| Q12 | T1 | `CQD[Second Client VDI Mode], CQD[Second Client VDI Is Optimized], CQD[Second Client VDI Provider Version]` | – | `@M1` |
| Q13 | T2 N=30 | `CQD[Second Client App Version Age], CQD[Second Client App Version]` | `FILTER(VALUES(CQD[Second User Agent Category]), CQD[Second User Agent Category]="Microsoft Teams 2.1 Windows")` | `@M1, @M2, "Users",SUM(CQD[Second User Count])` — ORDER `[Streams], DESC` |
| Q14 | T2 N=10 | `CQD[Second Building Name], CQD[Second Country]` | `@IN` | `@M1, @M2` — ORDER `[Streams], DESC` |
| Q15 | T1 | `CQD[Date]` | `@IN`, `FILTER(VALUES(CQD[Second Building Name]), CQD[Second Building Name]="<focus site from Q14>")` | `@M1` |
| Q16 | T1 | `CQD[CDR Response Reason], CQD[Second Inside Corp], CQD[Second Network Connection Detail]` | `FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="Conf")` | `@M1` |
| Q17 | T2 N=25 | `CQD[Second Subnet], CQD[Second Building Name], CQD[Second Network Connection Detail], CQD[Stream Direction]` | `@IN` | `@M1, @M2, @M4` — ORDER `[Dropped] + [APoor], DESC, [Streams], DESC` |
| Q18 | T2 N=30 | `CQD[Second Subnet], CQD[Second Inside Corp]` | `FILTER(VALUES(CQD[Second Inside Corp]), CQD[Second Inside Corp] <> "Inside")` | `"Streams",SUM(CQD[Total Stream Count]),"APoor",SUM(CQD[Audio Poor Stream Count])` — ORDER `[Streams], DESC, [APoor], DESC` |
| Q19 | T2 N=30 | `CQD[Second Building Name], CQD[First ASN Country], CQD[Second ASN Country]` | `FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="Conf")`, `FILTER(VALUES(CQD[Stream Direction]), CQD[Stream Direction]="First-to-Second")` | `@M1, @M4` — ORDER `[Streams], DESC` |
| Q20 | T1 | `CQD[Second Feedback Rating]` | – | `"RatingCount",SUM(CQD[Second Feedback Rating Count]),"PoorCount",SUM(CQD[Second Feedback Rating Poor Count])` |
| Q21 | T1 | `CQD[Media Type], CQD[Stream Direction]` | – | `"FrameRate",SUM(CQD[Avg Video Frame Rate]),"FrameLoss",SUM(CQD[Avg Video Local Frame Loss Percentage]),"Streams",SUM(CQD[Total Stream Count])` |
| Q22 | T1 | `CQD[Second QoS Applied], CQD[Second QoS Value], CQD[Stream Direction]` | – | `@M1` |
| Q23 | T2 N=20 | `CQD[Second Capture Dev Name], CQD[Second Capture Device Form Factor]` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio")` | `@M1, @M2` — ORDER `[APoor], DESC, [Streams], DESC` |
| Q24 | T1 | `CQD[Poor Reason], CQD[Session Type], CQD[Media Type]` | – | `@M1` |
| Q25 | T1 | `CQD[Media Failure Type], CQD[Session Type]` | – | `"Calls",SUM(CQD[Total Call Count])` |
| Q26 | T2 N=20 | `CQD[Second BSSID], CQD[Second Building Name]` | `FILTER(VALUES(CQD[Second Network Connection Detail]), CQD[Second Network Connection Detail]="Wifi")` | `@M1, @M2, "Roaming",SUM(CQD[Total Second Roaming Count])` — ORDER `[APoor], DESC, [Streams], DESC` |
| Q28 | T2 N=20 | `@G1` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="Conf"), @F3` | `@M6, "Good",SUM(CQD[Audio Good Stream Count]),"Poor",SUM(CQD[Audio Poor Stream Count])` — ORDER `[Streams], DESC, [Poor], DESC, CQD[Second Subnet], ASC, CQD[Second Reflexive Local IP Network], ASC, CQD[Stream Direction], ASC` |
| Q29 | T2 N=20 | `@G1` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="P2P"), @F3` | `@M6, "Good",SUM(CQD[Audio Good Stream Count]),"Poor",SUM(CQD[Audio Poor Stream Count])` — ORDER `[Streams], DESC, [Poor], DESC, CQD[Second Subnet], ASC, CQD[Second Reflexive Local IP Network], ASC, CQD[Stream Direction], ASC` |
| Q30 | T2 N=20 | `@G1` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Video"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="Conf"), @F3` | `@M6, "Good",SUM(CQD[Video Good Stream Count]),"Poor",SUM(CQD[Video Poor Stream Count])` — ORDER `[Streams], DESC, [Poor], DESC, CQD[Second Subnet], ASC, CQD[Second Reflexive Local IP Network], ASC, CQD[Stream Direction], ASC` |
| Q31 | T2 N=20 | `@G1` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Video"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="P2P"), @F3` | `@M6, "Good",SUM(CQD[Video Good Stream Count]),"Poor",SUM(CQD[Video Poor Stream Count])` — ORDER `[Streams], DESC, [Poor], DESC, CQD[Second Subnet], ASC, CQD[Second Reflexive Local IP Network], ASC, CQD[Stream Direction], ASC` |
| Q32 | T2 N=20 | `@G1` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="VBSS"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="Conf"), @F3` | `@M6, "Good",SUM(CQD[VBSS Good Stream Count]),"Poor",SUM(CQD[VBSS Poor Stream Count])` — ORDER `[Streams], DESC, [Poor], DESC, CQD[Second Subnet], ASC, CQD[Second Reflexive Local IP Network], ASC, CQD[Stream Direction], ASC` |
| Q33 | T2 N=20 | `@G1` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="VBSS"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="P2P"), @F3` | `@M6, "Good",SUM(CQD[VBSS Good Stream Count]),"Poor",SUM(CQD[VBSS Poor Stream Count])` — ORDER `[Streams], DESC, [Poor], DESC, CQD[Second Subnet], ASC, CQD[Second Reflexive Local IP Network], ASC, CQD[Stream Direction], ASC` |
| Q34 | T1 | `CQD[Media Type], CQD[Session Type], CQD[Second Transport Protocol]` | `@F1` | `"Streams",SUM(CQD[Total Stream Count])` |
| Q35 | T2 N=20 | `CQD[Second User Agent Category], CQD[Second Client App Version], CQD[Second Compute Device Name], CQD[Second CPU Name], CQD[Session Type], CQD[Media Type]` | `@F1` | `@M7` — ORDER `[ComputeTrue], DESC, [Streams], DESC` |
| Q36 | T2 N=20 | `CQD[Second Subnet], CQD[Second Building Name], CQD[Second Country]` | `FILTER(VALUES(CQD[Second Network Connection Detail]), CQD[Second Network Connection Detail]="Wifi"), FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio")` | `"Streams",SUM(CQD[Total Stream Count]),"B24",CALCULATE(SUM(CQD[Total Stream Count]), CQD[Second Wifi Band]="2.4 Ghz"),"Good24",CALCULATE(SUM(CQD[Audio Good Stream Count]), CQD[Second Wifi Band]="2.4 Ghz"),"Poor24",CALCULATE(SUM(CQD[Audio Poor Stream Count]), CQD[Second Wifi Band]="2.4 Ghz")` — ORDER `[B24], DESC, [Streams], DESC` |
| Q44 | T1 | `CQD[Second Network Mapped VPN], CQD[Media Type]` | `@F1` | `"Streams",SUM(CQD[Total Stream Count])` |
| Q45 | T2 N=20 | `CQD[Second Subnet], CQD[Second Building Name]` | `FILTER(VALUES(CQD[Session Type]), CQD[Session Type]="Conf")` | `"Streams",SUM(CQD[Total Stream Count]),"Tcp",CALCULATE(SUM(CQD[Total Stream Count]), CQD[Second Transport Protocol] IN {"TCP","TurnTCP","MultiTurnTCP","CompoundTCP"})` — ORDER `[Tcp], DESC, [Streams], DESC` |
| Q46 | T1 | `CQD[Media Type], CQD[Stream Direction], CQD[Second Network Connection Detail]` | `@F1` | `"Streams",SUM(CQD[Total Stream Count]), @M2` |
| Q47 | T2 N=15 | `CQD[Second Feedback Tokens]` | `FILTER(VALUES(CQD[Second Feedback Tokens]), CQD[Second Feedback Tokens] <> "")` | `"RatingCount",SUM(CQD[Second Feedback Rating Count]),"PoorCount",SUM(CQD[Second Feedback Rating Poor Count])` — ORDER `[PoorCount], DESC, [RatingCount], DESC, CQD[Second Feedback Tokens], ASC` |
| Q48 | T2 N=30 | `CQD[Second Subnet], CQD[Second Network Name], CQD[Second Building Name], CQD[Second Inside Corp], CQD[Second Network Connection Detail]` | `FILTER(VALUES(CQD[Media Type]), CQD[Media Type]="Audio"), FILTER(VALUES(CQD[Session Type]), CQD[Session Type] IN {"Conf","P2P"})` | `"Streams",SUM(CQD[Total Stream Count]),"AGood",SUM(CQD[Audio Good Stream Count]),"APoor",SUM(CQD[Audio Poor Stream Count])` — ORDER `[APoor], DESC, [Streams], DESC, CQD[Second Subnet], ASC` |

**Q44** fills the Mapped VPN panel. `Second UPN` returns only blank and `*` in this model, so the per-user column stays honestly uncollected. The Teams 2.1 build-age panel needs no query of its own: Q13 is already filtered to that client category.

**Q28–Q35 are the bounded investigation pack.** They fill the subnet and compute-model panels without the exhaustive subnet sweep that made earlier runs unaffordable. Each batch is published as `status: "partial"`, `truncated: true` and reconciled against the matching Q34 control, so the report states a top-offender ranking and never claims exhaustive coverage.

**Q36 answers the 2.4 GHz question directly**: per second subnet it returns the whole Wi-Fi audio volume and, with `CALCULATE`, the 2.4 GHz subset and its good/poor counts. The share and the PSR are therefore exact and the earlier week compares on the same subnet key. The connector accepts at most three `CALCULATE` measures per query, which is why the 5 GHz split is not asked for here.

**Q45 answers the TCP question directly**: the subnets whose conference streams fell back to TCP, ranked on TCP volume, media types not split. One query returns both the TCP count and the subnet's whole conference volume, so the share is exact and the earlier week compares on the same subnet key.

**Column that the model rejects.** If an execution fails because a column does not
exist, remove only that measure, re-run once, and record the affected family as
`unsupported` with the verbatim error as schema evidence. Never substitute a
different column, and never fill the slot from another query.

**Empty result.** A query that legitimately returns no rows is recorded
`status: "complete"`, `rows: 0`, with a control query proving the population is
empty. Without that control it is `partial`, not a zero.

## Reading the results

Facts verified against the live model. They decide how a returned figure must be
interpreted, so they are part of the register rather than advice.

- **Packet loss is a 0–1 ratio, not a percentage.** Mobile broadband averages
  `0.01` and the worst subnets reach `0.97`, i.e. 1 % and 97 % loss. Loss measures
  carry `unit: "ratio"`; reading them as percent understates loss a hundredfold.
  `Avg Round Trip*` and `Avg Jitter*` are plain milliseconds.
- **`AVERAGE()` is refused by this connector.** Every `Avg …`, `P50 …`, `… Rate`
  and `… Percentage` column is already aggregated server-side and is read with
  `SUM`, exactly as the official QER 5.3 report does. `SUM` is a pass-through, not
  an addition: the weekly and the daily figure stay in the same range while the
  stream count differs. Never average an average, and never pool two cohorts.
- **`Media Type` has six values**: `Audio`, `Video`, `VBSS`, plus `AV Stream`,
  `AppSharing` and a blank bucket. Map only the three known media into the PSR
  slots; the tenant total is *not* their sum.
- **Client cohorts use these exact `Second User Agent Category` values**:
  `Microsoft Teams 2.1 Windows`, `Microsoft Teams 2.1 Web`,
  `Microsoft Teams Room 2.1 (Windows)`, `Microsoft Teams Room (Android)`,
  `Microsoft Teams Android`, `Microsoft Teams iOS`, `Microsoft Teams Citrix VDI`.
- **Q18 finds unmapped corporate ranges, not "orphan" subnets.** A subnet is
  `Inside` *because* it is in the Building File, so an Inside subnet without a
  building cannot exist. Q18 ranks the busiest non-Inside subnets: an RFC1918
  range (`10.*`, `172.16-31.*`) carrying thousands of streams is a gap in the
  Building File that distorts every Inside/Outside split. `192.168.*` is usually a
  home network and is expected Outside.
- **Reliability identity**: within one population, `Established = CDR − Failed`.
- **Transport partitions everything**: `blank` is `Q1 total streams − udp −
  tcpfamily`; `turntcp` is a subset of `tcpfamily`, never an extra slice.
- **Feedback**: only the `1` and `5` rating buckets carry responses; the null and
  `0` buckets are empty and are excluded from the weighted mean.
