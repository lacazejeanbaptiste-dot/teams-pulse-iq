# Running this plugin in Microsoft 365 Copilot Cowork

What actually constrains a Cowork run, measured on a live tenant in September
2026 while building the full Teams Pulse IQ report. Everything here was
observed, not inferred.

## 1. Never transcribe query outputs through the chat — use RunScript to disk

If you call `ExecuteQuery` directly in the conversation and try to copy the
returned rows by hand into `raw_results.json` or `weekly-raw.json`, the context
window fills up and stalls (especially on tenants with a Building File, where
Q4 and Q5 alone can exceed 25 KB).

**Always invoke `ExecuteQuery` programmatically from a Python `RunScript` and
write the returned rows directly to `raw_results.json` / `weekly-raw.json` on
disk:**

- In `RunScript`, pass `artifactId`, `daxQueries`, and an explicit integer
  `maxRows` to `ExecuteQuery`, parse the JSON response for `executionResult`
  rows, and persist the compact tabular JSON (`{"cols": [...], "rows": [...]}`)
  directly to disk after each query or batch.
- Both `assemble_kpis.py` and `assemble_dashboard.py` accept the unbracketed
  column names returned by `ExecuteQuery` (`"CQD Session Type"`, `"Streams"`)
  as well as bracketed ones (`"CQD[Session Type]"`, `"[Streams]"`).
- For the weekly 71-query collection, use `assemble_dashboard.load_weekly_register()`
  and `assemble_dashboard.expand_register_query(...)` inside your Python script,
  and split execution across **2 or 3 sequential `RunScript` calls** (saving
  `weekly-raw.json` after each batch) so you never hit the 600-second per-script
  timeout.

If `RunScript` programmatic tool calling is unavailable in a given environment
and you must fall back to chat transcription, the payload budget below applies:

| Payload to transcribe | Outcome |
|---|---|
| 8 KB — daily collection, 19 executions | completes comfortably, every day |
| 126 KB — weekly collection, 71 executions | — |
| 326 KB — the same weekly collection, before section 2 | completed 71 of 71 |
| 807 KB — weekly, before the tabular shape | stopped at 39 of 71, no report |

**A Monday carries both**, about 131 KB across 90 executions — less than half of
what a single weekly collection already carried to completion. Step 6 of the
skill still orders the run so that a stall costs the attachment rather than the
mail, because the margin is now comfortable rather than guaranteed.

**When extending it:** adding a query is cheap, adding returned *columns* and
*rows* is not. Budget the payload, not the query count.

## 2. Three rules that cut a payload by two thirds

Each was measured, not guessed.

**Column names once.** In an 807 KB `raw_results.json`, the composition was:

| Component | Share |
|---|---|
| Column names repeated on every row | **72%** |
| Actual values | 19% |
| JSON punctuation | 9% |

Declaring columns once per query cuts the file to roughly a third with no data
removed. Verified equivalent: rebuilding the same run in both shapes produced an
identical result and a report of exactly the same byte length.

**No indentation.** A weekly file written by Cowork was **44% whitespace** —
140 KB of indentation, typed one space at a time. Compact JSON is the same data.

**No DAX echo.** Copying the executed query back into the results file was
**19%** of a weekly run and **33%** of a daily one. The register already holds
the text, keyed by id, and the only thing that varies is the date, which the
result key states. The field is worth writing in exactly one case: when the
query executed differed from the register because a column was rejected.

**And ask only for columns that are read.** The daily register once returned 41
columns from Q4 where the assembler reads 14, grouped Q13 by build number and
Q34 by transport where neither is ever displayed. Trimming it took a day from
43 KB to 8 KB with byte-identical indicators — verified by running the assembler
on both shapes and comparing every field.

## 3. Values arrive as displayed, not as returned

The Fabric IQ tool hands back what the report renders, not what the model
computed. Observed on a live run:

| Returned as | Actually |
|---|---|
| `"24,986"` | the integer 24 986 |
| `"3 696"` | the integer 3 696 |
| `"0%"` | the ratio 0.0 |
| `"0,5%"` | the ratio 0.005 |

Every one of these is a **string**. An earlier `assemble_kpis.py` accepted only
real numbers and percent strings, so a formatted count was read as `None` —
indistinguishable from a query that returned nothing. The figure vanished from
the page with no error anywhere.

`num()` now parses grouped thousands, both decimal notations and percent
strings, and **reports anything it still cannot read** instead of dropping it:
the assembler exits non-zero and names the value.

Two things follow for a run:

- **Do not convert values yourself.** Paste what the tool returned. Stripping a
  comma by hand is a transformation, and `"1,5"` is ambiguous in a way the
  parser resolves by rule rather than by guess.
- **Precision already lost stays lost.** `0.0437` displayed as `"4%"` cannot be
  recovered. Ask for the raw numeric value where the tool offers the choice, and
  treat a percent string as a recovered value rather than a faithful one.

## 4. Batches silently drop queries

Running four queries per call, several batches came back with three results.
Cowork noticed and re-issued the missing ones, but nothing in the tool signalled
the omission.

**Reconcile the key count before assembling.** `assemble_kpis.py` refuses to
continue and names any missing key, which is the check that catches this.

## 5. Delegating the bulk work does not help

Observed twice, in the same project.

The first version of the weekly report was run with a fleet of eleven workers,
on the reasonable assumption that seventy-one queries divide well. It cost over
a hundred dollars and produced no report. The cost is in the transcription, and
a fleet **multiplies** it: every worker reads the register into its own context,
and the results still have to come back through one conversation to be written
down.

The second time was milder and more instructive. An agent reached the weekly
half, measured the companion files, weighed doing it itself against dispatching
one background sub-agent — explicitly noting it was unsure the sub-agent would
share the working directory — and dispatched it anyway. The run stayed cheap;
the problem was never the price of one agent.

Two reasons hold even for a single sub-agent:

- `build_dashboard.py` reads `dashboard-data.json` from the current folder. A
  file written elsewhere is a run that fails at the last step with nothing to
  show for seventy-one executions, and the dispatching thread has no way to know
  until it looks.
- **A report whose figures you did not paste is one you cannot vouch for.** The
  rule that nothing is invented holds because the thread that transcribed the
  values is the thread that delivers them. The validator checks structure and
  arithmetic; it cannot tell a plausible fabrication from a measurement.

And a third that is simply arithmetic: moving sequential transcription to
another context does not make it shorter. It only makes it invisible.

**So: run both halves in the primary thread, in sequence.** Ninety executions is
the intended cost, and at 131 KB it is less than half of what one conversation
has already carried to completion.

The rule now appears at the branch in `SKILL.md`, not only in the companion.
That placement is itself the lesson: the agent decided after reading the file
sizes and before reading the procedure, so a rule inside the procedure was a
rule it had already passed.

## 6. A scheduled task still asks before it sends

Observed on the first run of a daily scheduled task, September 2026: Cowork
stopped before sending the mail and asked for approval, even though the standing
instruction named the recipient and said to run to the end without asking.

Sending mail is gated by Cowork's own consent layer, not by the conversation.
Nothing written in a skill or a prompt can pre-authorise it, and nothing should
try to: an agent that could silently mail on behalf of a user, from a schedule
created once, is a thing worth having a gate in front of.

**What to do:** approve it once, choosing *always approve*, so the following
runs go through unattended. Do this on a manual run before creating the
schedule, so the grant is already in place when the first automatic run fires
and nobody is watching.

**What to watch:** a run that produced its outputs but sent nothing usually
means the approval was never granted, or was granted for that run only. The
files are in the conversation; the mail is what is missing.

## 7. Failures that are not the plugin's fault

**Expired connector credentials.** Every query fails with:

> The credentials provided for the MicrosoftCallQuality source are invalid.
> (Source at MicrosoftCallQuality.)

Fix in Power BI: dataset → Settings → Data source credentials → Edit. Until that
is done no run can succeed.

**Model-side query limits**, established by probing:

- At most **three `CALCULATE` measures** per query. A fourth returns
  `10 keys were specified, but 7 values were provided`.
- `AVERAGE()` is rejected on every column. Pre-aggregated columns (`Avg …`,
  `… Rate`, `… Percentage`) are read with `SUM`, which passes the native value
  through. This is why the register uses `SUM` on `Avg Round Trip`.
- One `EVALUATE` per query.
- `TOPN` returns **every row tied at the cut-off**, so a single sort key over a
  mostly-zero measure can return hundreds of rows.

## 8. What the agent must never be asked to do

Do not compute, round, reorder or reconcile anything. Collect and paste;
`assemble_kpis.py` derives every rate from the collected counts.

An earlier version asked the agent to build the whole data file itself. It
filled 105 of 170 slots with plausible formulas and invented subnet addresses.
Nothing in the output distinguished those from measured values.

## 9. Checking a run before trusting it

Every day:

1. `raw_results.json` holds **19 keys**, each with `cols` and `rows`.
2. No entry carries an `error`, and none has zero rows without a stated reason.
3. `assemble_kpis.py` exits zero and reports no missing query.
4. Spot-check one figure: a rate on the page should match the counts in the raw
   result it came from.

On a Monday, additionally:

5. `weekly-raw.json` holds **71 keys**.
6. `build_dashboard.py` exited zero and `report.html` exists. It refuses to
   write the file when validation fails, so its presence is the check.
7. The mail carries the attachment. A Monday mail without it means the weekly
   half did not finish — which is the designed failure, not a silent one.
