"""Direct dashboard generator for Cowork.

Usage:
  python build_dashboard.py [--allow-unfinished-preview]

Reads dashboard-data.json, injects it into dashboard-template.html and writes
report.html -- but only after the same enrichment and validation that
render_dashboard.py performs. This is a convenience wrapper, never a shortcut:
there is exactly one way to produce a report, and it always goes through the
validator. A dataset that fails validation produces no HTML at all, so an
unverified or fabricated figure can never reach a deliverable.
"""
import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from render_dashboard import (  # noqa: E402  (path must be set first)
    DashboardError,
    enrich_report_data,
    load_json,
    render_html,
    validate_report,
)

DATA_CANDIDATES = (
    Path("dashboard-data.json"),
    Path("working/dashboard-data.json"),
    Path(".build/dashboard-data.json"),
)


def _first_existing(candidates):
    return next((path for path in candidates if path.is_file()), None)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--allow-unfinished-preview", action="store_true",
                        help="Labelled preview of an incomplete run; never a completed assessment.")
    args = parser.parse_args(argv)

    data_file = _first_existing(DATA_CANDIDATES)
    if data_file is None:
        print("ERROR: dashboard-data.json not found.", file=sys.stderr)
        return 1

    template_file = _first_existing((
        HERE / "dashboard-template.html",
        ROOT / "web" / "dashboard-template.html",
        Path("dashboard-template.html"),
    ))
    if template_file is None:
        print("ERROR: dashboard-template.html not found.", file=sys.stderr)
        return 1

    try:
        data = load_json(data_file)
        # Enrichment only reshapes and reconciles collected evidence. A failure
        # here is a real defect in the dataset and must stop the build, never be
        # swallowed so that an unverified report still gets written.
        data = enrich_report_data(data)
        data_file.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

        result = validate_report(data, args.allow_unfinished_preview)
        if not result["ok"]:
            print(json.dumps(result, ensure_ascii=True, allow_nan=False))
            print("\nNo report.html was written: fix the collected data or the query "
                  "coverage listed above. Do not relax the validator and do not fill "
                  "a slot with an estimated value.", file=sys.stderr)
            return 3 if result["structurally_valid"] and not result["finished"] else 2

        html = render_html(data, template_file.read_text(encoding="utf-8-sig"),
                           allow_unfinished_preview=args.allow_unfinished_preview)
        output_file = Path("report.html")
        output_file.write_text(html, encoding="utf-8")
        result["output"] = str(output_file)
        result["bytes"] = len(html.encode("utf-8"))
        print(json.dumps(result, ensure_ascii=True, allow_nan=False))
        return 0
    except (DashboardError, OSError, UnicodeError, RecursionError, ValueError) as exc:
        print(json.dumps({"ok": False, "valid": False, "errors": [str(exc)]}, ensure_ascii=True))
        return 2


if __name__ == "__main__":
    sys.exit(main())
