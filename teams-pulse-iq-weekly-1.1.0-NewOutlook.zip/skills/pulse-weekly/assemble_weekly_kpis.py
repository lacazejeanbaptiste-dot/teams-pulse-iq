"""Turn the weekly collected results into visual executive indicators.

Reads `weekly-raw.json` (the exact same file `assemble_dashboard.py` consumes)
and produces `weekly-kpis.json` for `build_weekly_note.py`:
- usage volumes (Meetings, 1:1 calls, user feedback, media streams);
- top distressed Audio subnets with `Second Network Name` and week-over-week PSR delta;
- headline 6 indicators;
- Audio, Video and Screen Sharing (VBSS) health details split by Inbound / Outbound
  across Overall, Wired and Wifi (Wi-Fi frequency bands omitted);
- top reasons for poor feedback (`Second Feedback Tokens`, with clean fallback);
- reliability, experience, network/transport and endpoint health tiles.

Nothing is estimated or invented: missing cohorts stay `None` with their reason.

    python assemble_weekly_kpis.py --raw weekly-raw.json --out weekly-kpis.json
"""
import argparse
import json
import re
from pathlib import Path

PERIOD_KEY = {'current': 'S', 'previous': 'S1'}

FLOOR = {'percent': 0.01, 'ms': 1.0, 'rating': 0.05, 'count': 0.0}
RELATIVE = 0.05

# Microsoft published targets + client >5% red threshold on one-star feedback.
LOWER_IS_BETTER = {
    'net.rtt': (100.0, 300.0),
    'net.jitter': (30.0, 50.0),
    'net.loss': (1.0, 5.0),
    'psr.audio': (2.0, 5.0),
    'psr.video': (2.0, 5.0),
    'psr.vbss': (2.0, 5.0),
    'clf.inbound': (5.0, 10.0),
    'clf.uplink': (5.0, 10.0),
    'setup': (1.0, 3.0),
    'drop': (2.0, 5.0),
    'transport.tcp': (2.0, 5.0),
    'feedback.poor': (2.0, 5.0),
}
HIGHER_IS_BETTER = {
    'vdi.optimized': (90.0, 70.0),
    'clients.current': (90.0, 70.0),
    'feedback.rating': (4.0, 3.0),
}

TCP_FAMILY = {'tcp', 'tls', 'turntcp', 'multiturntcp', 'compoundtcp'}
VDI_OPTIMISED = {'optimized', 'vdi 2.0 optimized'}
DIRECTION = {'First-to-Second': 'inbound', 'Second-to-First': 'outbound'}
MEDIA_GOOD_POOR = {
    'Audio': ('AGood', 'APoor'),
    'Video': ('VGood', 'VPoor'),
    'VBSS': ('SGood', 'SPoor'),
}
MEDIA_LABEL = {'Audio': 'Audio', 'Video': 'Video', 'VBSS': 'Sharing'}

FEEDBACK_TOKEN_LABELS = {
    'nosound': "People couldn't hear / No sound",
    'otherpartyhear': "People couldn't hear me",
    'icanthearyou': 'Could not hear participants',
    'audiohasecho': 'Audio echo heard on call',
    'echo': 'Audio echo heard on call',
    'distortedsound': 'Audio distorts / Robotic voice',
    'choppyaudio': 'Choppy / Cutting audio',
    'lowvolume': 'Low audio volume',
    'backgroundnoise': 'Background noise',
    'calldropped': 'Call dropped / Ended unexpectedly',
    'cannotjoin': 'Could not join / Setup delay',
    'videofroze': 'Video froze mid-call',
    'videoblurred': 'Video blurry / Low quality',
    'novideo': 'Video failed to start',
    'videosynch': 'Audio / Video out of sync',
    'screenshareblurred': 'Blurry screen sharing',
    'screensharestopped': 'Screen sharing lag / Stopped',
    'screensharelag': 'Screen sharing lag',
    'dialpad': 'Dialpad / DTMF issue',
}

_PERCENT_TEXT = re.compile(r'^\s*(-?[\d\s,.\u00a0\u202f]+?)\s*%\s*$')
_GROUPED = re.compile(r'^-?\d{1,3}(?:[,\s\u00a0\u202f]\d{3})+$')
_PLAIN = re.compile(r'^-?\d+(?:[.,]\d+)?$')

UNREADABLE = []


def _parse(text):
    cleaned = text.strip().replace('\u00a0', ' ').replace('\u202f', ' ')
    if not cleaned:
        return None
    if _GROUPED.match(cleaned):
        return float(re.sub(r'[,\s]', '', cleaned))
    compact = cleaned.replace(' ', '')
    if _PLAIN.match(compact):
        return float(compact.replace(',', '.'))
    return None


def num(row, alias):
    value = row.get('[' + alias + ']')
    if value is None:
        value = row.get(alias)
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return value
    if not isinstance(value, str):
        return None
    match = _PERCENT_TEXT.match(value)
    if match:
        parsed = _parse(match.group(1))
        return None if parsed is None else parsed / 100.0
    parsed = _parse(value)
    if parsed is None and value.strip():
        UNREADABLE.append(f'[{alias}]={value!r}')
    return parsed


def dim(row, column):
    for key in (f'CQD[{column}]', f"'CQD'[{column}]", f'CQD {column}', column):
        if key in row and row[key] is not None:
            text = str(row[key]).strip()
            return text or None
    return None


def ratio(numerator, denominator, scale=100.0):
    if numerator is None or not denominator:
        return None
    return scale * numerator / denominator


def is_rfc1918(subnet):
    parts = str(subnet or '').strip().split('.')
    if len(parts) < 2:
        return False
    if parts[0] == '10':
        return True
    return parts[0] == '172' and parts[1].isdigit() and 16 <= int(parts[1]) <= 31


def verdict(before, now, unit, direction):
    if before is None or now is None:
        return 'unknown', None, None
    delta = now - before
    relative = delta / abs(before) if before else None
    moved = (abs(delta) >= FLOOR.get(unit, 0.0)
             and (relative is None or abs(relative) >= RELATIVE))
    if not moved or direction == 'neutral':
        return 'stable', delta, relative
    improving = delta < 0 if direction == 'lower' else delta > 0
    return ('better' if improving else 'worse'), delta, relative


def level_of(key, value):
    if value is None:
        return 'unrated', None
    if key in LOWER_IS_BETTER:
        good, poor = LOWER_IS_BETTER[key]
        state = 'good' if value < good else 'poor' if value > poor else 'watch'
        return state, f'target below {good:g}'
    if key in HIGHER_IS_BETTER:
        good, poor = HIGHER_IS_BETTER[key]
        state = 'good' if value > good else 'poor' if value < poor else 'watch'
        return state, f'target above {good:g}'
    return 'unrated', None


def counts_of(before_pair, now_pair, noun):
    if now_pair is None and before_pair is None:
        return None

    def part(pair):
        if pair is None:
            return None
        numerator, denominator = pair
        if not denominator:
            return None
        return {'n': None if numerator is None else round(numerator),
                'd': round(denominator)}

    return {'noun': noun, 'before': part(before_pair), 'now': part(now_pair)}


def move(before, now, unit, direction, target_key=None):
    state, delta, relative = verdict(before, now, unit, direction)
    lvl, tgt = level_of(target_key, now) if target_key else ('unrated', None)
    return {
        'before': before, 'now': now, 'delta': delta, 'relative': relative,
        'verdict': state, 'direction': direction, 'unit': unit,
        'level': lvl, 'target': tgt,
    }


def _human_token(raw_token):
    cleaned = re.sub(r'[\[\]"]', '', str(raw_token or '')).strip()
    if not cleaned:
        return None
    slug = re.sub(r'[^a-z0-9]', '', cleaned.lower())
    if slug in FEEDBACK_TOKEN_LABELS:
        return FEEDBACK_TOKEN_LABELS[slug]
    # Split CamelCase tokens like "AudioDistorted" -> "Audio distorted"
    spaced = re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', cleaned).replace('_', ' ').strip()
    return spaced[0].upper() + spaced[1:] if spaced else cleaned


class WeeklyRun:
    def __init__(self, raw):
        self.raw = raw
        self.results = self._expand(raw.get('results') or {})
        self.periods = raw['periods']

    @staticmethod
    def _normalize_col(col):
        if not isinstance(col, str):
            return col
        if col.startswith('CQD ') and not col.startswith('CQD['):
            return f'CQD[{col[4:]}]'
        if not col.startswith(('CQD[', "'CQD'[", '[')):
            return f'[{col}]'
        return col

    @classmethod
    def _expand(cls, results):
        out = {}
        for key, entry in results.items():
            if not isinstance(entry, dict):
                continue
            entry = dict(entry)
            cols = entry.get('cols')
            if cols is not None:
                norm_cols = [cls._normalize_col(c) for c in cols]
                widened = []
                for idx, row in enumerate(entry.get('rows') or []):
                    if not isinstance(row, list) or len(row) != len(norm_cols):
                        raise SystemExit(
                            f"{key}: row {idx} does not match its {len(norm_cols)} columns")
                    widened.append(dict(zip(norm_cols, row)))
                entry['rows'] = widened
                entry.pop('cols', None)
            elif isinstance(entry.get('rows'), list):
                entry['rows'] = [
                    {cls._normalize_col(k): v for k, v in row.items()}
                    if isinstance(row, dict) else row
                    for row in entry['rows']
                ]
            out[key] = entry
        return out

    def rows(self, qid, period):
        entry = self.results.get(f'{qid}_{PERIOD_KEY[period]}')
        if not isinstance(entry, dict) or entry.get('error'):
            return []
        return entry.get('rows') or []

    def has_query(self, qid, period):
        entry = self.results.get(f'{qid}_{PERIOD_KEY[period]}')
        return isinstance(entry, dict) and not entry.get('error')

    def core_missing(self):
        expected = {
            f'{q}_{tag}'
            for q in ('Q1', 'Q4', 'Q8', 'Q10', 'Q12', 'Q13', 'Q20', 'Q34')
            for tag in ('S', 'S1')
        } | {'Q18_S'}
        return sorted(expected - set(self.results))

    def reliability(self, period):
        rows = self.rows('Q1', period)
        cdr = sum(num(r, 'CDR') or 0 for r in rows)
        failed = sum(num(r, 'Failed') or 0 for r in rows)
        established = sum(num(r, 'Established') or 0 for r in rows)
        dropped = sum(num(r, 'Dropped') or 0 for r in rows)
        calls = {'Conf': 0.0, 'P2P': 0.0} if self.has_query('Q1', period) else {}
        for r in rows:
            st = dim(r, 'Session Type')
            if st in ('Conf', 'P2P'):
                calls[st] = (calls.get(st) or 0) + (num(r, 'Calls') or 0)
        return {
            'setup': ratio(failed, cdr),
            'drop': ratio(dropped, established),
            'setup_counts': (failed, cdr),
            'drop_counts': (dropped, established),
            'calls': calls,
        }

    def media_and_classifiers(self, period):
        out, counts, classifiers, clf_counts = {}, {}, {}, {}
        q4 = self.rows('Q4', period)
        for media, (good_key, poor_key) in MEDIA_GOOD_POOR.items():
            good = poor = 0
            for row in q4:
                if dim(row, 'Media Type') != media:
                    continue
                if dim(row, 'Session Type') not in ('Conf', 'P2P', None):
                    continue
                good += num(row, good_key) or 0
                poor += num(row, poor_key) or 0
            out[media] = ratio(poor, good + poor)
            counts[media] = (poor, good + poor)
        for name, prefix in (('inbound', 'In'), ('uplink', 'Up')):
            true = false = 0
            for row in q4:
                if dim(row, 'Session Type') != 'Conf':
                    continue
                true += num(row, prefix + 'T') or 0
                false += num(row, prefix + 'F') or 0
            classifiers[name] = ratio(true, true + false)
            clf_counts[name] = (true, true + false)
        return out, counts, classifiers, clf_counts

    def streams(self, period):
        out = {}
        for row in self.rows('Q34', period):
            media = dim(row, 'Media Type')
            if media in ('Audio', 'Video', 'VBSS'):
                out[media] = out.get(media, 0) + (num(row, 'Streams') or 0)
        return out

    def modality_matrix(self, period):
        """Per modality: Inbound and Outbound poor rates across Overall, Wired, Wifi.

        Uses Q46 (`Media Type x Stream Direction x Second Network Connection Detail`).
        Falls back to Q4 if Q46 was not collected and Q4 carries Stream Direction.
        """
        source = self.rows('Q46', period)
        has_conn = bool(source)
        if not source:
            q4 = self.rows('Q4', period)
            if any(dim(r, 'Stream Direction') for r in q4):
                source = q4

        stream_totals = self.streams(period)
        matrix = {}
        for media, (good_key, poor_key) in MEDIA_GOOD_POOR.items():
            buckets = {
                way: {'overall': [0, 0], 'wired': [0, 0], 'wifi': [0, 0], 'streams': 0}
                for way in ('inbound', 'outbound')
            }
            counted_streams = 0
            for row in source:
                if dim(row, 'Media Type') != media:
                    continue
                st = num(row, 'Streams') or 0
                counted_streams += st
                way = DIRECTION.get(dim(row, 'Stream Direction') or '')
                if not way:
                    continue
                good = num(row, good_key) or 0
                poor = num(row, poor_key) or 0
                elig = good + poor
                buckets[way]['streams'] += st
                buckets[way]['overall'][0] += poor
                buckets[way]['overall'][1] += elig
                if has_conn:
                    conn = (dim(row, 'Second Network Connection Detail') or '').lower()
                    if conn == 'wired':
                        buckets[way]['wired'][0] += poor
                        buckets[way]['wired'][1] += elig
                    elif conn == 'wifi':
                        buckets[way]['wifi'][0] += poor
                        buckets[way]['wifi'][1] += elig

            total_streams = stream_totals.get(media)
            if total_streams is None and counted_streams:
                total_streams = counted_streams
            entry = {'streams': total_streams}
            for way in ('inbound', 'outbound'):
                b = buckets[way]
                way_data = {'streams': b['streams'] if source else None}
                for scope_key in ('overall', 'wired', 'wifi'):
                    if scope_key in ('wired', 'wifi') and not has_conn:
                        way_data[scope_key] = None
                        way_data[scope_key + '_counts'] = None
                    else:
                        p_cnt, e_cnt = b[scope_key]
                        way_data[scope_key] = ratio(p_cnt, e_cnt) if source else None
                        way_data[scope_key + '_counts'] = (p_cnt, e_cnt) if source else None
                entry[way] = way_data
            matrix[media] = entry
        return matrix

    def transport(self, period):
        udp = tcp = blank = 0
        for row in self.rows('Q8', period):
            protocol = (dim(row, 'Second Transport Protocol') or '').lower()
            streams = num(row, 'Streams') or 0
            if protocol in TCP_FAMILY:
                tcp += streams
            elif protocol == 'udp':
                udp += streams
            else:
                blank += streams
        total = udp + tcp + blank
        return {'udp': udp, 'tcpfamily': tcp, 'blank': blank,
                'share': ratio(tcp, total), 'counts': (tcp, total)}

    def network(self, period):
        for row in self.rows('Q10', period):
            if (dim(row, 'Session Type') == 'Conf'
                    and dim(row, 'Second Network Connection Detail') == 'Wifi'
                    and dim(row, 'Stream Direction') == 'First-to-Second'):
                loss = num(row, 'Loss')
                return {'rtt': num(row, 'RTT'), 'jitter': num(row, 'Jitter'),
                        'loss': None if loss is None else loss * 100.0}
        return {'rtt': None, 'jitter': None, 'loss': None}

    def vdi(self, period):
        optimised = total = 0
        for row in self.rows('Q12', period):
            state = (dim(row, 'Second Client VDI Is Optimized') or '').strip()
            mode = (dim(row, 'Second Client VDI Mode') or '').strip()
            if not state and not mode:
                continue
            if mode.lower() in ('non-vdi', 'not vdi', 'none') and not state:
                continue
            if not state:
                continue
            streams = num(row, 'Streams') or 0
            total += streams
            if state.lower() in VDI_OPTIMISED:
                optimised += streams
        return {'optimised_share': ratio(optimised, total), 'total': total,
                'counts': (optimised, total)}

    def clients(self, period):
        current = total = 0
        for row in self.rows('Q13', period):
            streams = num(row, 'Streams') or 0
            total += streams
            if (dim(row, 'Second Client App Version Age') or '') == 'Current':
                current += streams
        return {'current_share': ratio(current, total), 'total': total,
                'counts': (current, total)}

    def feedback(self, period):
        weighted = count = poor = 0
        for row in self.rows('Q20', period):
            rating = dim(row, 'Second Feedback Rating')
            ratings = num(row, 'RatingCount') or 0
            if not rating or rating == '0' or not ratings:
                continue
            count += ratings
            weighted += float(rating) * ratings
            poor += num(row, 'PoorCount') or 0
        return {'rating': weighted / count if count else None,
                'responses': count, 'poor': poor,
                'poor_share': ratio(poor, count)}

    def feedback_reasons(self):
        """Top user-reported reasons on poor ratings from Q47 (`Second Feedback Tokens`).

        If the model does not expose `Second Feedback Tokens`, falls back cleanly
        to technical CQD `Poor Reason` from Q24 (explicitly tagged as such).
        """
        q47 = self.rows('Q47', 'current')
        if q47:
            tallies = {}
            for row in q47:
                raw_tokens = dim(row, 'Second Feedback Tokens')
                if not raw_tokens:
                    continue
                cnt = num(row, 'PoorCount')
                if not cnt:
                    cnt = num(row, 'RatingCount') or 0
                if cnt <= 0:
                    continue
                parts = [p.strip() for p in re.split(r'[;|,]+', raw_tokens) if p.strip()]
                for part in (parts or [raw_tokens]):
                    label = _human_token(part)
                    if label:
                        tallies[label] = tallies.get(label, 0) + round(cnt)
            total_mentions = sum(tallies.values())
            ranked = sorted(tallies.items(), key=lambda kv: (-kv[1], kv[0]))[:5]
            return {
                'source': 'feedback_tokens',
                'title': 'Reasons for Poor Feedback',
                'total_mentions': total_mentions,
                'items': [
                    {'label': label, 'count': count,
                     'share': round(100.0 * count / total_mentions, 1) if total_mentions else 0.0}
                    for label, count in ranked
                ],
            }

        # Fallback to Q24 technical Poor Reason when Q47 is unavailable or empty
        q24 = self.rows('Q24', 'current')
        tallies = {}
        for row in q24:
            reason = dim(row, 'Poor Reason')
            if not reason or reason.lower() in ('none', 'notpoor', 'unknown', 'good'):
                continue
            cnt = num(row, 'Streams') or 0
            if cnt > 0:
                label = _human_token(reason)
                tallies[label] = tallies.get(label, 0) + round(cnt)
        if tallies:
            total_mentions = sum(tallies.values())
            ranked = sorted(tallies.items(), key=lambda kv: (-kv[1], kv[0]))[:5]
            return {
                'source': 'cqd_poor_reason',
                'title': 'Top Poor Stream Causes (CQD)',
                'total_mentions': total_mentions,
                'items': [
                    {'label': label, 'count': count,
                     'share': round(100.0 * count / total_mentions, 1) if total_mentions else 0.0}
                    for label, count in ranked
                ],
            }

        q47_entry = self.results.get('Q47_S') or {}
        return {
            'source': 'unavailable' if q47_entry.get('error') else 'empty',
            'title': 'Reasons for Poor Feedback',
            'total_mentions': 0,
            'items': [],
            'reason': (q47_entry.get('error')
                       or 'No poor-feedback reason tokens recorded in this week.'),
        }

    def _audio_subnets_for(self, period):
        """Aggregate Audio stream counts, Good/Poor and Second Network Name by subnet."""
        source = self.rows('Q48', period)
        good_alias, poor_alias = 'AGood', 'APoor'
        if not source:
            # Fallback to Q28 + Q29 (Audio Conf + Audio P2P investigation pack)
            source = self.rows('Q28', period) + self.rows('Q29', period)
            good_alias, poor_alias = 'Good', 'Poor'

        by_subnet = {}
        for row in source:
            subnet = dim(row, 'Second Subnet')
            if not subnet or subnet == '*':
                continue
            streams = num(row, 'Streams') or 0
            good = num(row, good_alias) or 0
            poor = num(row, poor_alias) or 0
            net_name = dim(row, 'Second Network Name')
            bldg = dim(row, 'Second Building Name')
            inside = dim(row, 'Second Inside Corp')
            conn = dim(row, 'Second Network Connection Detail')

            item = by_subnet.setdefault(subnet, {
                'subnet': subnet,
                'streams': 0, 'good': 0, 'poor': 0,
                'net_names': {}, 'buildings': {}, 'conns': {}, 'inside': set(),
            })
            item['streams'] += streams
            item['good'] += good
            item['poor'] += poor
            if net_name:
                item['net_names'][net_name] = item['net_names'].get(net_name, 0) + streams
            if bldg:
                item['buildings'][bldg] = item['buildings'].get(bldg, 0) + streams
            if conn:
                item['conns'][conn] = item['conns'].get(conn, 0) + streams
            if inside:
                item['inside'].add(inside)

        resolved = {}
        for subnet, item in by_subnet.items():
            elig = item['good'] + item['poor']
            psr = ratio(item['poor'], elig)
            top_net = max(item['net_names'].items(), key=lambda kv: kv[1])[0] if item['net_names'] else None
            top_bldg = max(item['buildings'].items(), key=lambda kv: kv[1])[0] if item['buildings'] else None
            top_conn = max(item['conns'].items(), key=lambda kv: kv[1])[0] if item['conns'] else None
            is_inside = 'Inside' in item['inside'] or bool(top_bldg)
            resolved[subnet] = {
                'subnet': subnet,
                'network_name': top_net,
                'building': top_bldg,
                'mapped': is_inside,
                'unmapped_rfc1918': (not is_inside) and is_rfc1918(subnet),
                'connection': top_conn or 'All',
                'streams': round(item['streams']),
                'eligible': round(elig),
                'poor': round(item['poor']),
                'psr': psr,
            }
        return resolved

    def audio_subnets(self, total_audio_streams):
        """Worst active Audio subnets in Week S compared with Week S-1."""
        cur_map = self._audio_subnets_for('current')
        prev_map = self._audio_subnets_for('previous')

        # Adaptive volume floor so noise (1/1 = 100%) is filtered out on large scopes
        # while small subsidiary scopes still surface their real active subnets.
        min_streams = 50 if (total_audio_streams or 0) >= 2000 else (
            15 if (total_audio_streams or 0) >= 300 else 5)

        candidates = [
            item for item in cur_map.values()
            if item['psr'] is not None and item['streams'] >= min_streams and item['poor'] > 0
        ]
        if not candidates:
            candidates = [
                item for item in cur_map.values()
                if item['psr'] is not None and item['streams'] >= max(3, min_streams // 2)
            ]

        candidates.sort(key=lambda x: (-(x['psr'] or 0.0), -x['poor'], -x['streams'], x['subnet']))

        enriched = []
        for item in candidates[:8]:
            prev = prev_map.get(item['subnet'])
            prev_psr = prev['psr'] if prev else None
            state, delta, rel = verdict(prev_psr, item['psr'], 'percent', 'lower')
            lvl, _ = level_of('psr.audio', item['psr'])
            enriched.append({
                **item,
                'before_psr': prev_psr,
                'before_poor': prev['poor'] if prev else None,
                'before_eligible': prev['eligible'] if prev else None,
                'before_streams': prev['streams'] if prev else None,
                'delta': delta,
                'relative': rel,
                'verdict': state,
                'level': lvl,
            })
        return {
            'min_streams': min_streams,
            'top_usage': enriched[:3],
            'detailed': enriched[:6],
        }

    def unmapped(self):
        rows = [r for r in self.rows('Q18', 'current')
                if is_rfc1918(dim(r, 'Second Subnet'))]
        return {'streams': sum(num(r, 'Streams') or 0 for r in rows),
                'subnets': len(rows)}


def headline_block(prev, cur):
    calls = {
        scenario: move((prev['calls'] or {}).get(scenario),
                       (cur['calls'] or {}).get(scenario),
                       'count', 'neutral')
        for scenario in ('Conf', 'P2P')
    }

    modalities = {}
    for media, label in MEDIA_LABEL.items():
        p_mod = prev['matrix'].get(media) or {}
        c_mod = cur['matrix'].get(media) or {}
        entry = {
            'label': label,
            'streams': move(p_mod.get('streams'), c_mod.get('streams'), 'count', 'neutral'),
        }
        for way in ('inbound', 'outbound'):
            p_way = p_mod.get(way) or {}
            c_way = c_mod.get(way) or {}
            way_out = {
                'streams': move(p_way.get('streams'), c_way.get('streams'), 'count', 'neutral'),
            }
            for scope_key in ('overall', 'wired', 'wifi'):
                m = move(p_way.get(scope_key), c_way.get(scope_key),
                         'percent', 'lower', target_key=f'psr.{media.lower()}')
                m['counts'] = counts_of(p_way.get(scope_key + '_counts'),
                                        c_way.get(scope_key + '_counts'), 'streams')
                way_out[scope_key] = m
            entry[way] = way_out
        modalities[media] = entry

    return {'calls': calls, 'modalities': modalities}


def build(raw):
    UNREADABLE.clear()
    run = WeeklyRun(raw)
    missing = run.core_missing()

    prev, cur = {}, {}
    for period, store in (('previous', prev), ('current', cur)):
        rel = run.reliability(period)
        psr, psr_counts, clf, clf_counts = run.media_and_classifiers(period)
        store.update({
            'setup': rel['setup'], 'drop': rel['drop'], 'calls': rel['calls'],
            'setup_counts': rel['setup_counts'], 'drop_counts': rel['drop_counts'],
            'psr': psr, 'psr_counts': psr_counts,
            'clf': clf, 'clf_counts': clf_counts,
            'transport': run.transport(period),
            'network': run.network(period),
            'vdi': run.vdi(period),
            'clients': run.clients(period),
            'feedback': run.feedback(period),
            'streams': run.streams(period),
            'matrix': run.modality_matrix(period),
        })

    spec = [
        ('feedback.rating', 'User rating', 'rating', 'higher', 'Experience',
         prev['feedback']['rating'], cur['feedback']['rating'],
         f"{cur['feedback']['responses']:,} ratings collected",
         (None, prev['feedback']['responses']),
         (None, cur['feedback']['responses']), 'ratings'),
        ('feedback.poor', 'One-star ratings', 'percent', 'lower', 'Experience',
         prev['feedback']['poor_share'], cur['feedback']['poor_share'],
         'Ratings at 1 star (target below 5%)',
         (prev['feedback']['poor'], prev['feedback']['responses']),
         (cur['feedback']['poor'], cur['feedback']['responses']), 'ratings'),
        ('psr.audio', 'Audio quality', 'percent', 'lower', 'Quality',
         prev['psr'].get('Audio'), cur['psr'].get('Audio'), 'Streams classified Poor',
         prev['psr_counts'].get('Audio'), cur['psr_counts'].get('Audio'), 'streams'),
        ('psr.video', 'Video quality', 'percent', 'lower', 'Quality',
         prev['psr'].get('Video'), cur['psr'].get('Video'), 'Streams classified Poor',
         prev['psr_counts'].get('Video'), cur['psr_counts'].get('Video'), 'streams'),
        ('psr.vbss', 'Sharing quality', 'percent', 'lower', 'Quality',
         prev['psr'].get('VBSS'), cur['psr'].get('VBSS'), 'Streams classified Poor',
         prev['psr_counts'].get('VBSS'), cur['psr_counts'].get('VBSS'), 'streams'),
        ('clf.inbound', 'Inbound network issues', 'percent', 'lower', 'Quality',
         prev['clf']['inbound'], cur['clf']['inbound'], 'Meetings classifier',
         prev['clf_counts']['inbound'], cur['clf_counts']['inbound'], 'streams'),
        ('clf.uplink', 'Outbound network issues', 'percent', 'lower', 'Quality',
         prev['clf']['uplink'], cur['clf']['uplink'], 'Meetings classifier',
         prev['clf_counts']['uplink'], cur['clf_counts']['uplink'], 'streams'),
        ('setup', 'Call setup failure', 'percent', 'lower', 'Reliability',
         prev['setup'], cur['setup'], 'Calls that never start',
         prev['setup_counts'], cur['setup_counts'], 'streams'),
        ('drop', 'Dropped calls', 'percent', 'lower', 'Reliability',
         prev['drop'], cur['drop'], 'Calls cut mid-conversation',
         prev['drop_counts'], cur['drop_counts'], 'streams'),
        ('net.rtt', 'Latency (RTT)', 'ms', 'lower', 'Network',
         prev['network']['rtt'], cur['network']['rtt'], 'Meetings · audio · Wi-Fi',
         None, None, None),
        ('net.jitter', 'Jitter', 'ms', 'lower', 'Network',
         prev['network']['jitter'], cur['network']['jitter'], 'Meetings · audio · Wi-Fi',
         None, None, None),
        ('net.loss', 'Packet loss', 'percent', 'lower', 'Network',
         prev['network']['loss'], cur['network']['loss'], 'Meetings · audio · Wi-Fi',
         None, None, None),
        ('transport.tcp', 'TCP fallback', 'percent', 'lower', 'Network',
         prev['transport']['share'], cur['transport']['share'],
         'Share of streams off UDP',
         prev['transport']['counts'], cur['transport']['counts'], 'streams'),
        ('vdi.optimized', 'VDI optimised', 'percent', 'higher', 'Endpoints',
         prev['vdi']['optimised_share'], cur['vdi']['optimised_share'],
         'Share of identified VDI estate',
         prev['vdi']['counts'], cur['vdi']['counts'], 'streams'),
        ('clients.current', 'Teams clients up to date', 'percent', 'higher', 'Endpoints',
         prev['clients']['current_share'], cur['clients']['current_share'],
         'New Teams 2.1 Windows version age',
         prev['clients']['counts'], cur['clients']['counts'], 'streams'),
    ]

    kpis = []
    for (key, label, unit, direction, family, before, now, detail,
         before_counts, now_counts, noun) in spec:
        state, delta, relative = verdict(before, now, unit, direction)
        level, target = level_of(key, now)
        attention = (level == 'poor'
                     or (level == 'watch' and state == 'worse')
                     or (level == 'unrated' and state == 'worse'
                         and abs(relative or 0) >= 0.20))
        kpis.append({
            'key': key, 'label': label, 'family': family, 'unit': unit,
            'direction': direction, 'before': before, 'now': now,
            'delta': delta, 'relative': relative, 'verdict': state,
            'level': level, 'target': target, 'attention': attention,
            'detail': detail, 'counts': counts_of(before_counts, now_counts, noun),
        })

    total_audio = cur['streams'].get('Audio') or (
        (cur['psr_counts'].get('Audio') or (0, 0))[1])

    return {
        'schema_version': 'teams-pulse-weekly-mail-v1',
        'scope': raw.get('scope') or raw.get('customer'),
        'customer': raw.get('customer'),
        'report': raw.get('report'),
        'periods': run.periods,
        'kpis': kpis,
        'headline': headline_block(prev, cur),
        'feedback_reasons': run.feedback_reasons(),
        'audio_subnets': run.audio_subnets(total_audio),
        'volumes': {
            'current': {'calls': cur['calls'], 'streams': cur['streams']},
            'previous': {'calls': prev['calls'], 'streams': prev['streams']},
        },
        'context': {'unmapped': run.unmapped()},
        'missing_queries': missing,
        'unreadable_values': sorted(set(UNREADABLE))[:20],
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--raw', type=Path, default=Path('weekly-raw.json'))
    parser.add_argument('--out', type=Path, default=Path('weekly-kpis.json'))
    args = parser.parse_args(argv)

    if not args.raw.is_file():
        raise SystemExit(f"weekly raw results not found: {args.raw}")
    data = build(json.loads(args.raw.read_text(encoding='utf-8')))
    args.out.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')

    kpis = data['kpis']
    attention = [k for k in kpis if k['attention']]
    print(f"{len(kpis)} weekly indicators: {len(attention)} need attention, "
          f"{sum(1 for k in kpis if k['level'] == 'good')} within target")
    if data['unreadable_values']:
        print("  UNREADABLE VALUES: " + ", ".join(data['unreadable_values']))
        return 1
    if data['missing_queries']:
        print("  MISSING CORE QUERIES: " + ", ".join(data['missing_queries']))
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
