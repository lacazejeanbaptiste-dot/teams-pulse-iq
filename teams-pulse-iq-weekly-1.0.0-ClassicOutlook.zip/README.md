# Teams Pulse IQ — Weekly Executive Edition

A dedicated weekly Microsoft Teams communication health report produced in
Microsoft 365 Copilot Cowork from a Power BI Call Quality Dashboard (CQD)
semantic model, supporting tenant-wide or per-entity/subsidiary scopes (e.g.
`Teams Media SEO`).

| Output | Delivery | Purpose |
|---|---|---|
| `weekly-note.html` | **Rich HTML email body** | Visual QER-style executive summary (`Teams Media <SCOPE>`, Volumes + Audio Subnets Watchlist with `Second Network Name` vs W−1, management `The week in short`, 6 gauges, row-aligned Audio/Video/Sharing Inbound vs Outbound across Overall/Wired/Wifi, red One-Star alert > 5%, Poor Feedback reasons, and detailed Subnets in Distress) |
| `report.html` | **Email attachment** | Validated 12-tab interactive week S vs week S−1 engineering deep-dive |

**Version 1.0.0.** Single weekly collection (40 queries / 77 executions across
weeks S and S−1) feeding both outputs deterministically.

## Install in Cowork

Import through **Cowork → Settings → Skills → Import**:
- `pulse-weekly-1.0.0.skill` — skill bundle.
- `teams-pulse-iq-weekly-1.0.0.zip` — full plugin archive.

Its skill identifier is `pulse-weekly`, so it can coexist cleanly with
`pulse-daily` if needed.

## Example Launch Prompt

```text
Use the pulse-weekly skill on the "<MODEL NAME>" semantic model to run the
weekly Teams analysis for SEO, filtering where CQD[Second Building Name]
contains "SEO", and mail it to <recipient@example.com>.
```

## Development & Verification

```bash
cd plugin-safran
python -m unittest discover -s tests
python tools/build_package.py
python tools/build_package.py --release
python tools/build_package.py --check
```
