"""Render the Classic Outlook Desktop (Word HTML engine) weekly executive mail.

Produces 100% table-based HTML with explicit `bgcolor` attributes, inline CSS,
`<br>` line breaks, `&nbsp;` spacing and pure-table QER gauges — guaranteed to
render with full background colors, crisp padding and fixed 880px width in
Microsoft Outlook Classic for Windows (Word rendering engine) as well as
New Outlook, Outlook Web and Mobile.

    python build_weekly_note.py --kpis weekly-kpis.json --narrative narrative.json --scope "SEO"
"""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from pulse_format import (arrow_mark, counts_phrase, esc, fmt_count, fmt_delta,
                          fmt_value, label_of, moved, n, period_label,
                          sound_analysis)

HERE = Path(__file__).resolve().parent
TEMPLATE_CANDIDATES = (
    HERE / 'weekly-note-classic-template.html',
    HERE.parent / 'web' / 'weekly-note-classic-template.html',
    HERE / 'weekly-note-template.html',
    HERE.parent / 'web' / 'weekly-note-template.html',
)

# (bg_hex, fg_hex, sub_hex, ico_hex, symbol)
PALETTE = {
    'good-dark': ('#1e821e', '#ffffff', '#e6f4ea', '#ffffff', '●'),
    'good':      ('#8cc63f', '#0f1419', '#1f2d16', '#196b24', '●'),
    'watch':     ('#ffc000', '#0f1419', '#3b2800', '#8a4b00', '▲'),
    'poor':      ('#e03e2d', '#ffffff', '#ffe8e6', '#ffffff', '■'),
    'unrated':   ('#eaeef2', '#57606a', '#6e7781', '#57606a', '·'),
}

VERDICT_COLOR = {
    'worse': '#cf222e',
    'better': '#1a7f37',
    'stable': '#8a9099',
    'unknown': '#8a9099',
}


def resolve_title(scope_arg, data):
    raw_scope = (scope_arg if scope_arg is not None
                 else data.get('scope') or data.get('customer') or '')
    scope = str(raw_scope).strip()
    if not scope:
        return 'Teams Media'
    if scope.lower().startswith('teams media'):
        return scope
    return f'Teams Media {scope}'


def as_kpi(measure):
    return {
        'key': '', 'unit': measure['unit'], 'direction': measure['direction'],
        'before': measure['before'], 'now': measure['now'],
        'delta': measure['delta'], 'relative': measure['relative'],
        'verdict': measure['verdict'],
        'level': measure.get('level', 'unrated'),
        'target': measure.get('target'),
    }


def arrow_html(measure, informational=False, leading_space=True):
    before, now = measure.get('before'), measure.get('now')
    if before is None or now is None:
        return ''
    pad = '&nbsp;&nbsp;' if leading_space else ''
    delta = now - before
    if informational:
        if not before:
            return ''
        relative = 100.0 * delta / abs(before)
        if abs(relative) < 1.0:
            return f'{pad}<span style="color:#8a9099;font-size:11.5px;font-weight:600;">=</span>'
        mark = '↑' if delta > 0 else '↓'
        return f'{pad}<span style="color:#57606a;font-size:11.5px;font-weight:600;">{mark}&nbsp;{abs(relative):.0f}&nbsp;%</span>'
    kpi = as_kpi(measure)
    mark = arrow_mark(kpi)
    if not mark:
        return f'{pad}<span style="color:#8a9099;font-size:11.5px;font-weight:600;">=</span>'
    col = VERDICT_COLOR.get(measure.get('verdict'), '#8a9099')
    return f'{pad}<span style="color:{col};font-size:11.5px;font-weight:700;">{mark}&nbsp;{fmt_delta(kpi)}</span>'


def stars_html(rating, out_of=5):
    if rating is None:
        return ''
    glyphs = []
    for idx in range(out_of):
        fill = max(0.0, min(1.0, rating - idx))
        if fill >= 0.75:
            glyphs.append('<span style="color:#e3a008;font-size:18px;">&#9733;</span>')
        elif fill >= 0.25:
            glyphs.append('<span style="color:#f0c45a;font-size:18px;">&#9733;</span>')
        else:
            glyphs.append('<span style="color:#d8dee4;font-size:18px;">&#9733;</span>')
    return '<div style="margin:3px 0 4px 0;line-height:1.2;">' + '&nbsp;'.join(glyphs) + '</div>'


def _box_head(left_text, right_text=''):
    right_cell = (
        f'<td align="right" style="padding:0 0 6px 0;font-size:10.5px;color:#8a9099;font-weight:500;">{esc(right_text)}</td>'
        if right_text else ''
    )
    return (
        '<table width="100%" cellpadding="0" cellspacing="0" border="0" '
        'style="border-bottom:1px solid #eef0f2;margin-bottom:8px;"><tr>'
        f'<td align="left" style="padding:0 0 6px 0;font-size:10.5px;letter-spacing:0.6px;'
        f'text-transform:uppercase;color:#6e7781;font-weight:700;">{esc(left_text)}</td>'
        f'{right_cell}</tr></table>'
    )


def volumes_top_html(data, by_key):
    calls = (data.get('headline') or {}).get('calls') or {}
    call_rows = []
    for key, label in (('Conf', 'Meetings'), ('P2P', '1:1 calls')):
        measure = calls.get(key)
        if not measure:
            continue
        call_rows.append(
            '<tr>'
            f'<td style="padding:4px 0;color:#2f353c;font-weight:600;font-size:13.5px;">{esc(label)}</td>'
            f'<td align="right" style="padding:4px 0;color:#15191e;font-weight:700;font-size:14px;">{n(measure["now"])}</td>'
            f'<td align="right" width="76" style="padding:4px 0;white-space:nowrap;">{arrow_html(measure, informational=True, leading_space=False)}</td>'
            '</tr>'
        )
    calls_inner = _box_head('Calls', 'vs W-1') + (
        f'<table width="100%" cellpadding="0" cellspacing="0" border="0">{"".join(call_rows)}</table>'
    )

    fb = by_key.get('feedback.rating')
    if not fb or fb['now'] is None:
        fb_inner = _box_head('User feedback') + (
            '<p style="font-size:13px;color:#8a9099;margin:6px 0 0 0;">No user rating returned for this week.</p>'
        )
    else:
        change, arrow = fmt_delta(fb), arrow_mark(fb)
        col = VERDICT_COLOR.get(fb['verdict'], '#8a9099')
        mark = (f'&nbsp;&nbsp;<span style="color:{col};font-size:12px;font-weight:700;">{arrow}&nbsp;{change}</span>'
                if arrow and change
                else '&nbsp;&nbsp;<span style="color:#8a9099;font-size:12px;font-weight:600;">=</span>')
        fb_inner = (
            _box_head('User feedback', 'Rate My Call')
            + f'<div><span style="font-size:25px;font-weight:700;color:#15191e;">{fmt_value(fb, fb["now"])}</span>{mark}</div>'
            + stars_html(fb['now'])
            + f'<div style="font-size:12px;color:#8a9099;">{esc(counts_phrase(fb))}</div>'
        )

    return (
        '<table width="100%" cellpadding="0" cellspacing="0" border="0">'
        '<tr>'
        f'<td width="48.5%" valign="top" bgcolor="#fbfcfd" style="background-color:#fbfcfd;border:1px solid #e6e9ec;padding:11px 14px 13px 14px;">{calls_inner}</td>'
        '<td width="3%" style="font-size:1px;line-height:1px;">&nbsp;</td>'
        f'<td width="48.5%" valign="top" bgcolor="#fbfcfd" style="background-color:#fbfcfd;border:1px solid #e6e9ec;padding:11px 14px 13px 14px;">{fb_inner}</td>'
        '</tr></table>'
    )


def _subnet_delta_html(item, leading_space=True):
    pad = '&nbsp;&nbsp;' if leading_space else ''
    if item.get('before_psr') is None or item.get('delta') is None:
        return f'{pad}<span style="color:#8a9099;font-size:11.5px;font-weight:600;">new</span>'
    kpi = {
        'unit': 'percent', 'direction': 'lower',
        'before': item['before_psr'], 'now': item['psr'],
        'delta': item['delta'], 'relative': item.get('relative'),
        'verdict': item.get('verdict', 'stable'),
    }
    mark = arrow_mark(kpi)
    if not mark:
        return f'{pad}<span style="color:#8a9099;font-size:11.5px;font-weight:600;">=</span>'
    col = VERDICT_COLOR.get(item.get('verdict'), '#8a9099')
    return f'{pad}<span style="color:{col};font-size:11.5px;font-weight:700;">{mark}&nbsp;{fmt_delta(kpi)}</span>'


def volumes_bottom_html(data):
    modalities = (data.get('headline') or {}).get('modalities') or {}
    stream_rows = []
    for key in ('Audio', 'Video', 'VBSS'):
        mod = modalities.get(key)
        if not mod:
            continue
        st = mod['streams']
        stream_rows.append(
            '<tr>'
            f'<td style="padding:3px 0;font-size:12.5px;color:#57606a;">{esc(mod["label"])}</td>'
            f'<td align="right" style="padding:3px 0;font-size:12.5px;color:#15191e;white-space:nowrap;">'
            f'<b>{n(st["now"])}</b>{arrow_html(st, informational=True)}</td>'
            '</tr>'
        )
    left_html = _box_head('Media streams', 'vs W-1') + (
        f'<table width="100%" cellpadding="0" cellspacing="0" border="0">{"".join(stream_rows)}</table>'
    )

    top_subnets = ((data.get('audio_subnets') or {}).get('top_usage')) or []
    if not top_subnets:
        right_body = '<p style="font-size:12.5px;color:#8a9099;margin:4px 0 0 0;">No active subnet reported poor audio streams this week.</p>'
    else:
        sub_rows = []
        for item in top_subnets:
            lvl = item.get('level', 'good')
            bg, fg, _, ico_col, ico = PALETTE.get(lvl, PALETTE['unrated'])
            net_label = (item.get('network_name')
                         or item.get('building')
                         or ('Unmapped RFC1918' if item.get('unmapped_rfc1918') else 'Unmapped network'))
            badge_tbl = (
                '<table cellpadding="0" cellspacing="0" border="0" align="right"><tr>'
                f'<td bgcolor="{bg}" style="background-color:{bg};color:{fg};padding:2px 7px;'
                f'font-size:11.5px;font-weight:700;white-space:nowrap;">'
                f'<span style="color:{ico_col};">{ico}</span>&nbsp;{item["psr"]:.2f} %</td>'
                f'<td style="padding-left:6px;white-space:nowrap;">{_subnet_delta_html(item, leading_space=False)}</td>'
                '</tr></table>'
            )
            sub_rows.append(
                '<tr>'
                f'<td style="padding:3px 6px 3px 0;font-size:12px;color:#15191e;">'
                f'<span style="font-family:Consolas,monospace;font-weight:700;">{esc(item["subnet"])}</span>'
                f'&nbsp;&middot;&nbsp;<span style="color:#424a53;font-weight:600;">{esc(net_label)}</span></td>'
                f'<td align="right" style="padding:3px 0;white-space:nowrap;">{badge_tbl}</td>'
                '</tr>'
            )
        right_body = f'<table width="100%" cellpadding="0" cellspacing="0" border="0">{"".join(sub_rows)}</table>'

    right_html = _box_head('Subnets in distress · Second Network Name', 'Audio Poor % vs W-1') + right_body
    return (
        '<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#fbfcfd" '
        'style="background-color:#fbfcfd;border:1px solid #e6e9ec;">'
        '<tr>'
        f'<td width="35%" valign="top" style="padding:10px 14px 12px 14px;border-right:1px solid #eef0f2;">{left_html}</td>'
        f'<td width="65%" valign="top" style="padding:10px 14px 12px 14px;">{right_html}</td>'
        '</tr></table>'
    )


def _exec_tag_table(label, bg, bdr, fg):
    return (
        '<table width="84" cellpadding="0" cellspacing="0" border="0"><tr>'
        f'<td bgcolor="{bg}" align="center" style="background-color:{bg};border:1px solid {bdr};'
        f'color:{fg};padding:3px 5px;font-size:10px;font-weight:700;text-transform:uppercase;'
        f'letter-spacing:0.4px;text-align:center;">{esc(label)}</td>'
        '</tr></table>'
    )


def week_in_short_html(data, narrative):
    clean_narrative, dropped = sound_analysis(data, narrative)
    analysis = clean_narrative.get('analysis') or {}
    bad = [str(t).strip() for t in (analysis.get('negative') or []) if str(t).strip()]
    good = [str(t).strip() for t in (analysis.get('positive') or []) if str(t).strip()]

    kpis = data.get('kpis') or []
    poor_kpis = [k for k in kpis if k.get('level') == 'poor']
    watch_kpis = [k for k in kpis if k.get('level') == 'watch']

    if poor_kpis:
        p_bg, p_fg = '#e03e2d', '#ffffff'
        pill_txt = (f'■ Action Required · {len(poor_kpis)} Critical'
                    + (f', {len(watch_kpis)} Watch' if watch_kpis else ''))
    elif watch_kpis:
        p_bg, p_fg = '#ffc000', '#0f1419'
        pill_txt = f'▲ Watch · {len(watch_kpis)} Indicator{"s" if len(watch_kpis) > 1 else ""} Above Target'
    else:
        p_bg, p_fg = '#8cc63f', '#0f1419'
        pill_txt = '● Healthy · All Targets Met'

    rows = []
    for text in bad:
        if poor_kpis:
            tag = _exec_tag_table('Action', '#ffe8e6', '#f5b3ad', '#b31d14')
        elif watch_kpis:
            tag = _exec_tag_table('Watch', '#fff4ce', '#e6be4c', '#7d4e00')
        else:
            tag = _exec_tag_table('Note', '#e8f0fe', '#93c5fd', '#1e40af')
        rows.append(
            '<tr>'
            f'<td width="94" valign="top" style="padding:3px 10px 8px 0;">{tag}</td>'
            f'<td valign="top" style="padding:2px 0 8px 0;font-size:13.5px;line-height:1.55;color:#1f2328;font-weight:500;">{esc(text)}</td>'
            '</tr>'
        )
    for text in good:
        tag = _exec_tag_table('Positive', '#dcfce7', '#86efac', '#146c2e')
        rows.append(
            '<tr>'
            f'<td width="94" valign="top" style="padding:3px 10px 8px 0;">{tag}</td>'
            f'<td valign="top" style="padding:2px 0 8px 0;font-size:13.5px;line-height:1.55;color:#1f2328;font-weight:500;">{esc(text)}</td>'
            '</tr>'
        )

    if dropped:
        tag = _exec_tag_table('Audit', '#fff4ce', '#e6be4c', '#7d4e00')
        rows.append(
            '<tr>'
            f'<td width="94" valign="top" style="padding:3px 10px 4px 0;">{tag}</td>'
            f'<td valign="top" style="padding:2px 0 4px 0;font-size:13px;line-height:1.5;color:#57606a;">'
            f'{len(dropped)} written finding{"s were" if len(dropped) > 1 else " was"} omitted because '
            'quoted counts did not match the named indicator.</td></tr>'
        )

    if not rows:
        attention = [label_of(k) for k in kpis if k.get('attention')]
        if attention:
            tag = _exec_tag_table('Watch', '#fff4ce', '#e6be4c', '#7d4e00')
            rows.append(
                '<tr>'
                f'<td width="94" valign="top" style="padding:3px 10px 0 0;">{tag}</td>'
                f'<td valign="top" style="padding:2px 0 0 0;font-size:13.5px;line-height:1.55;color:#1f2328;">'
                f'Indicators requiring management review this week: <b>{esc(", ".join(attention))}</b>.</td></tr>'
            )
        else:
            tag = _exec_tag_table('Healthy', '#dcfce7', '#86efac', '#146c2e')
            rows.append(
                '<tr>'
                f'<td width="94" valign="top" style="padding:3px 10px 0 0;">{tag}</td>'
                '<td valign="top" style="padding:2px 0 0 0;font-size:13.5px;line-height:1.55;color:#1f2328;">'
                'All measured Teams quality and reliability indicators sit within published Microsoft targets '
                'this week, with no material degradation against the prior week.</td></tr>'
            )

    status_pill_tbl = (
        '<table cellpadding="0" cellspacing="0" border="0" align="right"><tr>'
        f'<td bgcolor="{p_bg}" style="background-color:{p_bg};color:{p_fg};padding:4px 10px;'
        f'font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.4px;white-space:nowrap;">'
        f'{esc(pill_txt)}</td></tr></table>'
    )

    return (
        '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px solid #c5cdf5;">'
        '<tr>'
        '<td bgcolor="#27326b" align="left" style="background-color:#27326b;color:#ffffff;padding:10px 16px;'
        'font-size:12px;font-weight:700;letter-spacing:0.8px;text-transform:uppercase;">'
        '&#10022; The week in short &mdash; Executive Briefing</td>'
        f'<td bgcolor="#27326b" align="right" style="background-color:#27326b;padding:8px 16px;">{status_pill_tbl}</td>'
        '</tr>'
        '<tr>'
        '<td colspan="2" bgcolor="#f6f8ff" style="background-color:#f6f8ff;border-left:5px solid #4e5ac0;padding:14px 18px 10px 16px;">'
        f'<table width="100%" cellpadding="0" cellspacing="0" border="0">{"".join(rows)}</table>'
        '</td></tr></table>'
    )


def _gauge_pct(value, good_limit, poor_limit, max_scale):
    """Piecewise position (0..100%) across the 3 equal color zones (33% / 34% / 33%)."""
    if value is None or value <= 0:
        return 4
    if value < good_limit:
        frac = value / good_limit if good_limit else 0.0
        return max(4, min(31, round(33.0 * frac)))
    if value <= poor_limit:
        span = (poor_limit - good_limit) or 1.0
        frac = (value - good_limit) / span
        return max(35, min(65, round(33.0 + 34.0 * frac)))
    span = (max_scale - poor_limit) or 1.0
    frac = min(1.0, (value - poor_limit) / span)
    return max(69, min(95, round(67.0 + 33.0 * frac)))


def gauges_html(by_key):
    """Six pure-table QER gauges with dynamic pointer needle — 100% Word-safe."""
    specs = [
        ('psr.audio', 'Poor Audio Rate', 'Target < 2%', 2.0, 5.0, 10.0),
        ('psr.video', 'Poor Video Rate', 'Target < 2%', 2.0, 5.0, 10.0),
        ('psr.vbss', 'Poor Sharing Rate', 'Target < 2%', 2.0, 5.0, 10.0),
        ('drop', 'Drop Failure Rate', 'Target < 2%', 2.0, 5.0, 10.0),
        ('setup', 'Setup Failure Rate', 'Target < 1%', 1.0, 3.0, 5.0),
        ('feedback.poor', 'Poor Feedback (1★)', 'Target < 5%', 2.0, 5.0, 15.0),
    ]
    cells = []
    for idx, (key, title, target_lbl, good_lim, poor_lim, max_scale) in enumerate(specs):
        if idx > 0:
            cells.append('<td width="8" style="width:8px;font-size:1px;line-height:1px;">&nbsp;</td>')

        kpi = by_key.get(key) or {'now': None, 'before': None, 'delta': None,
                                  'relative': None, 'unit': 'percent',
                                  'direction': 'lower', 'verdict': 'unknown',
                                  'level': 'unrated', 'counts': None}
        val = kpi['now']
        lvl = kpi.get('level', 'unrated')
        card_bg = '#fff8f7' if lvl == 'poor' else ('#fffdf6' if lvl == 'watch' else '#ffffff')
        card_bdr = '#e03e2d' if lvl == 'poor' else ('#e5a93c' if lvl == 'watch' else '#e1e4e8')
        val_color = '#b31d14' if lvl == 'poor' else ('#9a5b00' if lvl == 'watch' else '#15191e')
        ptr_color = '#e03e2d' if lvl == 'poor' else ('#b35900' if lvl == 'watch' else '#1e821e')

        pct = _gauge_pct(val, good_lim, poor_lim, max_scale)
        left_w = max(1, pct - 5)
        right_w = max(1, 90 - left_w)

        pointer_tbl = (
            '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top:4px;"><tr>'
            f'<td width="{left_w}%" style="font-size:1px;line-height:1px;">&nbsp;</td>'
            f'<td width="10%" align="center" style="font-size:11px;line-height:11px;color:{ptr_color};font-weight:700;">&#9660;</td>'
            f'<td width="{right_w}%" style="font-size:1px;line-height:1px;">&nbsp;</td>'
            '</tr></table>'
        )
        bar_tbl = (
            '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin:1px 0 2px 0;"><tr>'
            '<td width="33%" height="9" bgcolor="#1e821e" style="background-color:#1e821e;height:9px;font-size:1px;line-height:1px;">&nbsp;</td>'
            '<td width="34%" height="9" bgcolor="#ffc000" style="background-color:#ffc000;height:9px;font-size:1px;line-height:1px;">&nbsp;</td>'
            '<td width="33%" height="9" bgcolor="#d83b01" style="background-color:#d83b01;height:9px;font-size:1px;line-height:1px;">&nbsp;</td>'
            '</tr></table>'
        )
        scale_tbl = (
            '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:5px;"><tr>'
            '<td width="33%" align="left" style="font-size:9px;color:#8a9099;">0</td>'
            f'<td width="34%" align="center" style="font-size:9px;color:#8a9099;">{good_lim:g}–{poor_lim:g}%</td>'
            f'<td width="33%" align="right" style="font-size:9px;color:#8a9099;">{max_scale:g}%</td>'
            '</tr></table>'
        )

        change, arrow = fmt_delta(kpi), arrow_mark(kpi)
        if arrow and change:
            col = VERDICT_COLOR.get(kpi['verdict'], '#8a9099')
            delta_part = f'<span style="color:{col};font-weight:700;">{arrow}&nbsp;{change}</span>'
        elif val is not None:
            delta_part = '<span style="color:#8a9099;font-weight:600;">= steady</span>'
        else:
            delta_part = '<span style="color:#8a9099;">not measured</span>'

        cnt = ((kpi.get('counts') or {}).get('now') or {}).get('n')
        cnt_part = f' &middot; {n(cnt)} poor' if cnt is not None else ''

        cells.append(
            f'<td width="16%" valign="top" align="center" bgcolor="{card_bg}" '
            f'style="background-color:{card_bg};border:1px solid {card_bdr};padding:9px 7px 9px 7px;text-align:center;">'
            f'<div style="font-size:11px;color:#424a53;font-weight:700;line-height:1.25;">{esc(title)}<br>'
            f'<span style="font-weight:400;color:#8a9099;font-size:10px;">({esc(target_lbl)})</span></div>'
            f'{pointer_tbl}{bar_tbl}{scale_tbl}'
            f'<div style="font-size:19px;font-weight:700;color:{val_color};line-height:1.15;">{fmt_value(kpi, val)}</div>'
            f'<div style="font-size:10px;color:#6e7781;margin-top:3px;">{delta_part}{cnt_part}</div>'
            '</td>'
        )
    return f'<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>{"".join(cells)}</tr></table>'


def _pill_cell(measure, border_bottom=False):
    bb = 'border-bottom:1px solid #f0f2f5;' if border_bottom else ''
    if not measure or measure.get('now') is None:
        bg, fg, sub_fg, ico_fg, ico = PALETTE['unrated']
        inner = (
            '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
            f'<td bgcolor="{bg}" align="center" style="background-color:{bg};color:{fg};padding:6px 6px;text-align:center;">'
            f'<span style="font-size:14.5px;font-weight:700;color:{fg};">{ico}&nbsp;&mdash;</span><br>'
            f'<span style="font-size:10px;font-weight:600;color:{sub_fg};">not measured</span>'
            '</td></tr></table>'
        )
        return f'<td valign="middle" style="padding:6px 7px;border-right:1px solid #eef0f2;{bb}">{inner}</td>'

    lvl = measure.get('level', 'good')
    bg, fg, sub_fg, ico_fg, ico = PALETTE.get(lvl, PALETTE['good'])
    kpi = as_kpi(measure)
    change, arrow = fmt_delta(kpi), arrow_mark(kpi)
    if arrow and change:
        sub = f'{arrow} {change} vs W-1'
    elif lvl == 'good':
        sub = 'within 2% target'
    elif lvl == 'watch':
        sub = 'above 2% target'
    else:
        sub = 'critical (> 5%)'

    inner = (
        '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        f'<td bgcolor="{bg}" align="center" style="background-color:{bg};color:{fg};padding:6px 6px;text-align:center;">'
        f'<span style="font-size:14.5px;font-weight:700;color:{fg};"><span style="color:{ico_fg};">{ico}</span>&nbsp;{fmt_value(kpi, measure["now"])}</span><br>'
        f'<span style="font-size:10px;font-weight:600;color:{sub_fg};">{esc(sub)}</span>'
        '</td></tr></table>'
    )
    return f'<td valign="middle" style="padding:6px 7px;border-right:1px solid #eef0f2;{bb}">{inner}</td>'


def _dir_button_html(label, level):
    if level == 'poor':
        bg, bdr, fg = '#fff0ee', '#cf222e', '#a40e26'
    elif level == 'watch':
        bg, bdr, fg = '#fffbe6', '#d48806', '#8a4b00'
    else:
        bg, bdr, fg = '#f8f9fa', '#6e7781', '#2f353c'
    return (
        '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        f'<td bgcolor="{bg}" align="center" style="background-color:{bg};border:1.5px solid {bdr};'
        f'color:{fg};padding:9px 4px;font-size:11.5px;font-weight:700;text-align:center;white-space:nowrap;">'
        f'{label}</td></tr></table>'
    )


def media_details_html(data):
    modalities = (data.get('headline') or {}).get('modalities') or {}
    configs = [
        ('Audio', 'Audio Health Details — Meetings & Calls', '#4e5ac0'),
        ('Video', 'Video Health Details — Meetings & Calls', '#3b4990'),
        ('VBSS', 'Screen Sharing (VBSS) Health Details — Meetings & Calls', '#5c4b8b'),
    ]
    blocks = []
    for idx, (key, title, hdr_bg) in enumerate(configs):
        mod = modalities.get(key) or {}
        st = mod.get('streams') or {'now': None, 'before': None}
        in_way = mod.get('inbound') or {}
        out_way = mod.get('outbound') or {}

        in_lvl = (in_way.get('overall') or {}).get('level', 'good')
        out_lvl = (out_way.get('overall') or {}).get('level', 'good')
        worst_lvl = ('poor' if 'poor' in (in_lvl, out_lvl)
                     else 'watch' if 'watch' in (in_lvl, out_lvl) else 'good')
        outer_bdr = '#e03e2d' if worst_lvl == 'poor' else ('#e5a93c' if worst_lvl == 'watch' else '#d0d7de')
        hdr_note = ('Target: below 2.00% · ■ Critical threshold exceeded' if worst_lvl == 'poor'
                    else 'Target: below 2.00% · ▲ Watch on Outbound' if out_lvl == 'watch'
                    else 'Target: below 2.00% poor streams')

        in_counts = ((in_way.get('overall') or {}).get('counts') or {}).get('now') or {}
        out_counts = ((out_way.get('overall') or {}).get('counts') or {}).get('now') or {}

        in_poor_str = (
            f'<b style="font-size:13.5px;color:#1f2328;">{n(in_counts.get("n"))}</b> '
            f'<span style="font-size:11px;color:#6e7781;">/ {n(in_counts.get("d"))}</span>'
            if in_counts.get('n') is not None else '&mdash;'
        )
        out_poor_str = (
            f'<b style="font-size:13.5px;color:#1f2328;">{n(out_counts.get("n"))}</b> '
            f'<span style="font-size:11px;color:#6e7781;">/ {n(out_counts.get("d"))}</span>'
            if out_counts.get('n') is not None else '&mdash;'
        )

        prev_st_note = (
            f'was {n(st["before"])} ({arrow_html(st, informational=True, leading_space=False)})'
            if st.get('before') is not None else ''
        )

        spacer = ('<table width="100%" cellpadding="0" cellspacing="0" border="0">'
                  '<tr><td height="12" style="font-size:1px;line-height:1px;">&nbsp;</td></tr></table>'
                  if idx > 0 else '')

        hdr_tbl = (
            f'<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="{hdr_bg}" style="background-color:{hdr_bg};"><tr>'
            f'<td align="left" bgcolor="{hdr_bg}" style="background-color:{hdr_bg};color:#ffffff;padding:7px 14px;font-size:13px;font-weight:700;">{esc(title)}</td>'
            f'<td align="right" bgcolor="{hdr_bg}" style="background-color:{hdr_bg};color:#ffffff;padding:7px 14px;font-size:11px;font-weight:400;">{esc(hdr_note)}</td>'
            '</tr></table>'
        )

        th_style = ('font-size:11px;font-weight:700;color:#424a53;text-align:center;'
                    'padding:6px 6px;background-color:#fafbfc;border-bottom:1px solid #eef0f2;border-right:1px solid #eef0f2;')

        grid_tbl = (
            '<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" style="background-color:#ffffff;">'
            '<tr>'
            '<td width="16%" rowspan="3" valign="middle" align="center" bgcolor="#fcfcfd" '
            'style="background-color:#fcfcfd;padding:10px 8px;border-right:1px solid #eef0f2;text-align:center;">'
            f'<span style="font-size:10.5px;color:#57606a;">Total {esc(mod.get("label", key))} Streams</span><br>'
            f'<span style="font-size:20px;font-weight:700;color:#15191e;">{n(st.get("now"))}</span><br>'
            f'<span style="font-size:10.5px;color:#6e7781;">{prev_st_note}</span>'
            '</td>'
            f'<th width="15%" bgcolor="#fafbfc" style="{th_style}">Poor Streams</th>'
            f'<th width="13%" bgcolor="#fafbfc" style="{th_style}">Direction</th>'
            f'<th width="18.6%" bgcolor="#fafbfc" style="{th_style}">Overall (%)</th>'
            f'<th width="18.6%" bgcolor="#fafbfc" style="{th_style}">Wired (%)</th>'
            f'<th width="18.8%" bgcolor="#fafbfc" style="{th_style}border-right:0;">Wifi (%)</th>'
            '</tr>'
            # Row 2: Strictly aligned Inbound row
            '<tr>'
            '<td valign="middle" align="center" style="padding:6px 6px;border-right:1px solid #eef0f2;border-bottom:1px solid #f0f2f5;text-align:center;">'
            f'<span style="font-size:10px;color:#6e7781;">Poor Inbound</span><br>{in_poor_str}</td>'
            '<td valign="middle" style="padding:6px 7px;border-right:1px solid #eef0f2;border-bottom:1px solid #f0f2f5;">'
            f'{_dir_button_html("&#11015; Inbound", in_lvl)}</td>'
            f'{_pill_cell(in_way.get("overall"), border_bottom=True)}'
            f'{_pill_cell(in_way.get("wired"), border_bottom=True)}'
            f'{_pill_cell(in_way.get("wifi"), border_bottom=True)}'
            '</tr>'
            # Row 3: Strictly aligned Outbound row
            '<tr>'
            '<td valign="middle" align="center" style="padding:6px 6px;border-right:1px solid #eef0f2;text-align:center;">'
            f'<span style="font-size:10px;color:#6e7781;">Poor Outbound</span><br>{out_poor_str}</td>'
            '<td valign="middle" style="padding:6px 7px;border-right:1px solid #eef0f2;">'
            f'{_dir_button_html("&#11014; Outbound", out_lvl)}</td>'
            f'{_pill_cell(out_way.get("overall"), border_bottom=False)}'
            f'{_pill_cell(out_way.get("wired"), border_bottom=False)}'
            f'{_pill_cell(out_way.get("wifi"), border_bottom=False)}'
            '</tr>'
            '</table>'
        )

        blocks.append(
            f'{spacer}<table width="100%" cellpadding="0" cellspacing="0" border="0" '
            f'style="border:1px solid {outer_bdr};"><tr><td>{hdr_tbl}{grid_tbl}</td></tr></table>'
        )
    return ''.join(blocks)


def _tile_card(kpi, title, help_line, target_bold, compact=False, dark_when_good=False,
               sub_override=None):
    val_fs = '16.5px' if compact else '20px'
    if not kpi or kpi.get('now') is None:
        bg, fg, sub_fg, _, ico = PALETTE['unrated']
        box_tbl = (
            '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
            f'<td bgcolor="{bg}" align="center" style="background-color:{bg};color:{fg};padding:11px 6px 9px 6px;text-align:center;">'
            f'<span style="font-size:{val_fs};font-weight:700;color:{fg};">{ico}&nbsp;&mdash;</span><br>'
            f'<span style="font-size:10px;font-weight:600;color:{sub_fg};">not measured</span>'
            '</td></tr></table>'
        )
        return (
            '<td valign="top" align="center">'
            f'<div style="font-size:11px;color:#424a53;font-weight:700;margin-bottom:5px;text-align:center;white-space:nowrap;">{esc(title)}</div>'
            f'{box_tbl}'
            f'<div style="font-size:10px;color:#6e7781;margin-top:5px;line-height:1.35;text-align:center;">{esc(help_line)}<br><b>{esc(target_bold)}</b></div>'
            '</td>'
        )

    lvl = kpi.get('level', 'good')
    pal_key = 'good-dark' if (lvl == 'good' and dark_when_good) else lvl
    bg, fg, sub_fg, ico_fg, ico = PALETTE.get(pal_key, PALETTE['good'])

    if sub_override is not None:
        sub = sub_override
    else:
        change, arrow = fmt_delta(kpi), arrow_mark(kpi)
        if kpi.get('unit') == 'ms' and kpi.get('delta') is not None:
            sign = '+' if kpi['delta'] >= 0 else '−'
            change = f"{sign}{abs(kpi['delta']):.0f} ms"
        if arrow and change:
            if compact:
                sub = f'{arrow} {change} vs W-1'
            else:
                prev_txt = fmt_value(kpi, kpi['before']).replace(' %', '%').replace(' / 5', '')
                sub = f'{arrow} {change} (was {prev_txt})'
        else:
            sub = '= steady'

    box_tbl = (
        '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        f'<td bgcolor="{bg}" align="center" style="background-color:{bg};color:{fg};padding:11px 6px 9px 6px;text-align:center;">'
        f'<span style="font-size:{val_fs};font-weight:700;color:{fg};white-space:nowrap;">'
        f'<span style="color:{ico_fg};">{ico}</span>&nbsp;{fmt_value(kpi, kpi["now"])}</span><br>'
        f'<span style="font-size:10px;font-weight:600;color:{sub_fg};white-space:nowrap;">{esc(sub)}</span>'
        '</td></tr></table>'
    )
    return (
        '<td valign="top" align="center">'
        f'<div style="font-size:11px;color:#424a53;font-weight:700;margin-bottom:5px;text-align:center;white-space:nowrap;">{esc(title)}</div>'
        f'{box_tbl}'
        f'<div style="font-size:10px;color:#6e7781;margin-top:5px;line-height:1.35;text-align:center;">{esc(help_line)}<br><b>{esc(target_bold)}</b></div>'
        '</td>'
    )


def _gap_td(px=8):
    return f'<td width="{px}" style="width:{px}px;font-size:1px;line-height:1px;">&nbsp;</td>'


def _feedback_reasons_html(fb_reasons):
    items = (fb_reasons or {}).get('items') or []
    title = (fb_reasons or {}).get('title') or 'Reasons for Poor Feedback'
    total = (fb_reasons or {}).get('total_mentions') or 0
    header = (
        f'<div style="font-size:11px;color:#424a53;font-weight:700;margin-bottom:6px;text-align:left;">'
        f'{esc(title)}'
        + (f' <span style="font-weight:400;color:#8a9099;">({n(total)})</span>' if total else '')
        + '</div>'
    )
    if not items:
        why = (fb_reasons or {}).get('reason') or 'No poor-feedback reasons reported.'
        return header + f'<p style="font-size:11.5px;color:#8a9099;margin:6px 0 0 0;">{esc(why)}</p>'

    max_share = max((it['share'] for it in items), default=100.0) or 100.0
    rows = []
    for it in items:
        fill_pct = max(8, min(100, round(100.0 * it['share'] / max_share)))
        rest_pct = max(0, 100 - fill_pct)
        bar_cells = (
            f'<td width="{fill_pct}%" height="9" bgcolor="#4e5ac0" '
            'style="background-color:#4e5ac0;height:9px;font-size:1px;line-height:1px;">&nbsp;</td>'
        )
        if rest_pct > 0:
            bar_cells += (
                f'<td width="{rest_pct}%" height="9" bgcolor="#eaeef2" '
                'style="background-color:#eaeef2;height:9px;font-size:1px;line-height:1px;">&nbsp;</td>'
            )
        rows.append(
            '<tr>'
            f'<td width="50%" style="padding:4px 6px 4px 0;font-size:11.5px;color:#2f353c;font-weight:500;">{esc(it["label"])}</td>'
            f'<td width="30%" style="padding:4px 6px 4px 0;"><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>{bar_cells}</tr></table></td>'
            f'<td width="20%" align="right" style="padding:4px 0;font-size:11.5px;font-weight:700;color:#15191e;white-space:nowrap;">'
            f'{n(it["count"])} <span style="font-weight:400;color:#6e7781;">({it["share"]:.0f}%)</span></td>'
            '</tr>'
        )
    return header + f'<table width="100%" cellpadding="0" cellspacing="0" border="0">{"".join(rows)}</table>'


def thematic_blocks_html(by_key, fb_reasons):
    drop = by_key.get('drop')
    setup = by_key.get('setup')
    fb_score = by_key.get('feedback.rating')
    fb_poor = by_key.get('feedback.poor')
    rtt = by_key.get('net.rtt')
    jitter = by_key.get('net.jitter')
    loss = by_key.get('net.loss')
    tcp = by_key.get('transport.tcp')
    clf_in = by_key.get('clf.inbound')
    clf_out = by_key.get('clf.uplink')
    clients = by_key.get('clients.current')
    vdi = by_key.get('vdi.optimized')

    def _pair_help(kpi, fallback):
        c = ((kpi or {}).get('counts') or {}).get('now')
        if c and c.get('n') is not None and c.get('d'):
            return f"{n(c['n'])} of {n(c['d'])}"
        if c and c.get('d'):
            return f"{n(c['d'])} {kpi['counts']['noun']}"
        return fallback

    vdi_sub = (f"VDI: {vdi['now']:.0f}% opt."
               if vdi and vdi.get('now') is not None else None)

    card_td = 'valign="top" bgcolor="#fbfcfd" style="background-color:#fbfcfd;border:1px solid #e1e4e8;padding:12px 14px 14px 14px;"'

    row1 = (
        '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        f'<td width="39%" {card_td}>'
        '<div style="font-size:12px;font-weight:700;color:#2f353c;text-align:center;margin-bottom:10px;">'
        'Audio &amp; Call Reliability<br>'
        '<span style="font-size:10.5px;font-weight:400;color:#6e7781;">Calls cut mid-conversation vs calls failing to connect</span></div>'
        '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        + _tile_card(drop, 'Drop Rate (%)', _pair_help(drop, 'Established streams'), 'Target: below 2%')
        + _gap_td(8)
        + _tile_card(setup, 'Setup Failure Rate (%)', _pair_help(setup, 'CDR streams'), 'Target: below 1%', dark_when_good=True)
        + '</tr></table></td>'
        + _gap_td(12)
        + f'<td width="59%" {card_td}>'
        '<div style="font-size:12px;font-weight:700;color:#2f353c;text-align:center;margin-bottom:10px;">'
        'User Experience &amp; Top Reasons for Poor Feedback<br>'
        '<span style="font-size:10.5px;font-weight:400;color:#6e7781;">Rate My Call score, 1-star share (red above 5%) &amp; reported causes</span></div>'
        '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        '<td width="46%" valign="top" style="padding-right:10px;border-right:1px solid #eef0f2;">'
        '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        + _tile_card(fb_score, 'Feedback Score', _pair_help(fb_score, 'Ratings'), 'Target > 4.0', compact=True, dark_when_good=True)
        + _gap_td(8)
        + _tile_card(fb_poor, 'One-Star (%)', _pair_help(fb_poor, '1★ ratings'), 'Target < 5%', compact=True)
        + '</tr></table></td>'
        '<td width="54%" valign="top" style="padding-left:12px;">'
        + _feedback_reasons_html(fb_reasons)
        + '</td></tr></table></td>'
        '</tr></table>'
    )

    spacer = ('<table width="100%" cellpadding="0" cellspacing="0" border="0">'
              '<tr><td height="12" style="font-size:1px;line-height:1px;">&nbsp;</td></tr></table>')

    row2 = (
        '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        f'<td width="57%" {card_td}>'
        '<div style="font-size:12px;font-weight:700;color:#2f353c;text-align:center;margin-bottom:10px;">'
        'Network &amp; Transport Health (Wi-Fi Meetings &amp; UDP Media)<br>'
        '<span style="font-size:10.5px;font-weight:400;color:#6e7781;">Network round-trip delay, jitter, packet loss &amp; firewall UDP fallback</span></div>'
        '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        + _tile_card(rtt, 'Latency (RTT)', 'Round-trip time', 'Target < 100 ms', compact=True)
        + _gap_td(8)
        + _tile_card(jitter, 'Jitter', 'Packet delay variation', 'Target < 30 ms', compact=True)
        + _gap_td(8)
        + _tile_card(loss, 'Packet Loss', 'Wi-Fi audio loss', 'Target < 1.00%', compact=True)
        + _gap_td(8)
        + _tile_card(tcp, 'TCP Fallback (%)', _pair_help(tcp, 'Streams off UDP'), 'Target < 2.00%', compact=True)
        + '</tr></table></td>'
        + _gap_td(12)
        + f'<td width="41%" {card_td}>'
        '<div style="font-size:12px;font-weight:700;color:#2f353c;text-align:center;margin-bottom:10px;">'
        'Network Classifiers &amp; Endpoints<br>'
        '<span style="font-size:10.5px;font-weight:400;color:#6e7781;">Share of meetings with network issues &amp; client estate</span></div>'
        '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        + _tile_card(clf_in, 'Inbound Issues', 'Download classifier', 'Target < 5%', compact=True,
                     sub_override=_pair_help(clf_in, 'Meetings'))
        + _gap_td(8)
        + _tile_card(clf_out, 'Outbound Issues', 'Uplink classifier', 'Target < 5%', compact=True,
                     sub_override=_pair_help(clf_out, 'Meetings'))
        + _gap_td(8)
        + _tile_card(clients, 'Clients Current', _pair_help(clients, 'Teams 2.1'), 'Target > 90%', compact=True,
                     dark_when_good=True, sub_override=vdi_sub)
        + '</tr></table></td>'
        '</tr></table>'
    )
    return row1 + spacer + row2


def subnets_section_html(data):
    subnet_data = data.get('audio_subnets') or {}
    rows_data = subnet_data.get('detailed') or []
    min_st = subnet_data.get('min_streams') or 5

    heading = (
        '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
        '<td class="sec-hdr">Subnets in Distress &mdash; Top Audio Subnets by Poor Rate &nbsp;'
        f'<span class="sec-sub">Active subnets (&ge; {min_st} audio streams) &middot; Second Network Name &amp; W-1 delta</span></td>'
        '</tr><tr><td height="10" style="font-size:1px;line-height:1px;">&nbsp;</td></tr></table>'
    )

    hdr_bar = (
        '<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#2f353c" style="background-color:#2f353c;"><tr>'
        '<td align="left" bgcolor="#2f353c" style="background-color:#2f353c;color:#ffffff;padding:7px 14px;font-size:12.5px;font-weight:700;">'
        'Worst Audio Subnets Requiring Investigation</td>'
        '<td align="right" bgcolor="#2f353c" style="background-color:#2f353c;color:#d0d7de;padding:7px 14px;font-size:11px;">'
        'Target: below 2.00% &middot; Watch: 2–5% &middot; Poor: above 5%</td>'
        '</tr></table>'
    )

    if not rows_data:
        return (
            heading
            + '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px solid #e1e4e8;">'
            f'<tr><td>{hdr_bar}</td></tr>'
            '<tr><td bgcolor="#ffffff" style="background-color:#ffffff;padding:12px 14px;font-size:12.5px;color:#57606a;">'
            'No active subnet recorded degraded audio streams during the selected week.</td></tr></table>'
        )

    th_s = ('font-size:10px;text-transform:uppercase;color:#57606a;background-color:#f6f8fa;'
            'padding:8px 10px;border-bottom:1px solid #e1e4e8;font-weight:700;')

    body_rows = []
    for r_idx, item in enumerate(rows_data):
        lvl = item.get('level', 'good')
        bg, fg, _, ico_fg, ico = PALETTE.get(lvl, PALETTE['good'])
        net_name = item.get('network_name') or '—'
        bldg = item.get('building')
        bb = 'border-bottom:1px solid #eef0f2;' if r_idx < len(rows_data) - 1 else ''

        if item.get('mapped'):
            bldg_html = (
                f'<span style="font-size:11.5px;color:#57606a;">{esc(bldg or "Mapped site")}</span>&nbsp;'
                '<span style="background-color:#eef1f4;color:#57606a;font-size:10px;font-weight:700;padding:1px 5px;">Inside</span>'
            )
        elif item.get('unmapped_rfc1918'):
            bldg_html = (
                '<span style="font-size:11.5px;color:#57606a;">Unmapped RFC1918</span><br>'
                '<span style="background-color:#fff8c5;color:#7d4e00;border:1px solid #eac54f;font-size:10px;font-weight:700;padding:1px 5px;">Missing in Building File</span>'
            )
        else:
            bldg_html = '<span style="font-size:11.5px;color:#57606a;">Outside / External</span>'

        psr_badge = (
            '<table width="84" cellpadding="0" cellspacing="0" border="0" align="center"><tr>'
            f'<td bgcolor="{bg}" align="center" style="background-color:{bg};color:{fg};padding:4px 7px;'
            f'font-size:12.5px;font-weight:700;text-align:center;white-space:nowrap;">'
            f'<span style="color:{ico_fg};">{ico}</span>&nbsp;{item["psr"]:.2f} %</td>'
            '</tr></table>'
        )
        conn_badge = (
            '<table cellpadding="0" cellspacing="0" border="0" align="center"><tr>'
            '<td bgcolor="#f0f3f6" align="center" style="background-color:#f0f3f6;color:#424a53;padding:2px 8px;'
            f'font-size:10.5px;font-weight:700;text-align:center;">{esc(item.get("connection") or "All")}</td>'
            '</tr></table>'
        )

        body_rows.append(
            '<tr>'
            f'<td style="padding:8px 10px;{bb}font-family:Consolas,monospace;font-weight:700;font-size:12px;color:#15191e;white-space:nowrap;">{esc(item["subnet"])}</td>'
            f'<td style="padding:8px 10px;{bb}font-weight:600;font-size:12px;color:#1f2328;">{esc(net_name)}</td>'
            f'<td style="padding:8px 10px;{bb}">{bldg_html}</td>'
            f'<td align="center" style="padding:8px 10px;{bb}">{conn_badge}</td>'
            f'<td align="right" style="padding:8px 10px;{bb}font-size:12px;color:#1f2328;">{n(item["streams"])}</td>'
            f'<td align="right" style="padding:8px 10px;{bb}font-size:12px;color:#15191e;"><b>{n(item["poor"])}</b></td>'
            f'<td align="center" style="padding:8px 10px;{bb}">{psr_badge}</td>'
            f'<td align="right" style="padding:8px 10px;{bb}white-space:nowrap;">{_subnet_delta_html(item, leading_space=False)}</td>'
            '</tr>'
        )

    table_html = (
        '<table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" style="background-color:#ffffff;">'
        '<tr>'
        f'<th width="13%" align="left" bgcolor="#f6f8fa" style="{th_s}">Subnet</th>'
        f'<th width="21%" align="left" bgcolor="#f6f8fa" style="{th_s}">Second Network Name</th>'
        f'<th width="21%" align="left" bgcolor="#f6f8fa" style="{th_s}">Building / Scope</th>'
        f'<th width="8%" align="center" bgcolor="#f6f8fa" style="{th_s}text-align:center;">Access</th>'
        f'<th width="9%" align="right" bgcolor="#f6f8fa" style="{th_s}text-align:right;">Audio</th>'
        f'<th width="7%" align="right" bgcolor="#f6f8fa" style="{th_s}text-align:right;">Poor</th>'
        f'<th width="12%" align="center" bgcolor="#f6f8fa" style="{th_s}text-align:center;">Audio PSR</th>'
        f'<th width="9%" align="right" bgcolor="#f6f8fa" style="{th_s}text-align:right;">vs W-1</th>'
        '</tr>'
        f'{"".join(body_rows)}</table>'
    )

    return (
        heading
        + '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px solid #e1e4e8;">'
        f'<tr><td>{hdr_bar}{table_html}</td></tr></table>'
    )


def build(data, narrative, scope=None):
    template_path = next((p for p in TEMPLATE_CANDIDATES if p.is_file()), None)
    if template_path is None:
        raise SystemExit('weekly-note-classic-template.html not found beside this script')

    by_key = {k['key']: k for k in (data.get('kpis') or [])}
    periods = data['periods']
    title = resolve_title(scope, data)

    unmapped = (data.get('context') or {}).get('unmapped') or {}
    footnote = (
        'Every figure comes from an executed Call Quality Dashboard weekly query; '
        'nothing is estimated. Inbound measures streams arriving at the reported '
        'endpoint and Outbound those leaving it; an elevated Outbound poor rate on '
        'Screen Sharing typically indicates constrained sender upload bandwidth rather '
        'than a service-wide incident.'
    )
    if unmapped.get('subnets'):
        footnote += (f" {fmt_count(unmapped['streams'])} streams came from "
                     f"{unmapped['subnets']} private subnets absent from the Building File.")

    html = (
        template_path.read_text(encoding='utf-8')
        .replace('{{TITLE}}', esc(title))
        .replace('{{WEEK}}', esc(period_label(periods['current'])))
        .replace('{{WEEK_PREV}}', esc(period_label(periods['previous'])))
        .replace('{{VOLUMES_TOP}}', volumes_top_html(data, by_key))
        .replace('{{VOLUMES_BOTTOM}}', volumes_bottom_html(data))
        .replace('{{WEEK_IN_SHORT}}', week_in_short_html(data, narrative))
        .replace('{{GAUGES}}', gauges_html(by_key))
        .replace('{{MEDIA_DETAILS}}', media_details_html(data))
        .replace('{{THEMATIC_BLOCKS}}', thematic_blocks_html(by_key, data.get('feedback_reasons')))
        .replace('{{SUBNETS_SECTION}}', subnets_section_html(data))
        .replace('{{FOOTNOTE}}', esc(footnote))
        .replace('{{GENERATED}}', datetime.now(timezone.utc).strftime('%d/%m/%Y %H:%M UTC'))
    )
    kpis = data.get('kpis') or []
    return html, {'total': len(kpis), 'moved': sum(1 for k in kpis if moved(k))}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--kpis', type=Path, default=Path('weekly-kpis.json'))
    parser.add_argument('--narrative', type=Path, default=Path('narrative.json'))
    parser.add_argument('--out', type=Path, default=Path('weekly-note.html'))
    parser.add_argument('--scope', default=None,
                        help='Scope or subsidiary label shown in "Teams Media <SCOPE>" (e.g. SEO).')
    parser.add_argument('--customer', default=None,
                        help='Alias for --scope if --scope is omitted.')
    args = parser.parse_args(argv)

    if not args.kpis.is_file():
        raise SystemExit(f"weekly-kpis.json not found: {args.kpis}. Run assemble_weekly_kpis.py first.")
    data = json.loads(args.kpis.read_text(encoding='utf-8'))
    narrative = (json.loads(args.narrative.read_text(encoding='utf-8'))
                 if args.narrative.is_file() else {})

    if data.get('missing_queries'):
        print("Refusing to render: the weekly run is missing "
              + ", ".join(data['missing_queries']))
        return 2

    chosen_scope = args.scope if args.scope is not None else args.customer
    html, counts = build(data, narrative, chosen_scope)
    args.out.write_text(html, encoding='utf-8')
    print(f"-> {args.out}  ({len(html) // 1024} KB, {counts['total']} indicators, "
          f"{counts['moved']} moved)")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
