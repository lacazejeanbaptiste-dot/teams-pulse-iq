"""Render the visual weekly executive mail (`weekly-note.html`).

Consumes `weekly-kpis.json` (produced by `assemble_weekly_kpis.py`) and
`narrative.json`, and writes an Outlook-ready visual HTML summary designed to
be forwarded directly to operations and production leadership every week.

    python build_weekly_note.py --kpis weekly-kpis.json --narrative narrative.json --scope "SEO"
"""
import argparse
import json
import math
from datetime import datetime, timezone
from pathlib import Path

from pulse_format import (arrow_mark, counts_phrase, esc, fmt_count, fmt_delta,
                          fmt_value, label_of, moved, n, period_label,
                          sound_analysis)

HERE = Path(__file__).resolve().parent
TEMPLATE_CANDIDATES = (
    HERE / 'weekly-note-template.html',
    HERE.parent / 'web' / 'weekly-note-template.html',
)

STAR_FULL = '★'
STAR_EMPTY = '☆'
STAR_COLOUR = '#e3a008'
STAR_PALE = '#f3e2c0'

LEVEL_BG = {
    'good': 'bg-good',
    'watch': 'bg-watch',
    'poor': 'bg-poor',
    'unrated': 'bg-na',
}
LEVEL_ICON = {
    'good': '●',
    'watch': '▲',
    'poor': '■',
    'unrated': '·',
}


def resolve_title(scope_arg, data):
    """Build `Teams Media <SCOPE>` from the prompt scope variable."""
    raw_scope = (scope_arg if scope_arg is not None
                 else data.get('scope') or data.get('customer') or '')
    scope = str(raw_scope).strip()
    if not scope:
        return 'Teams Media'
    if scope.lower().startswith('teams media'):
        return scope
    return f'Teams Media {scope}'


def as_kpi(measure):
    return {
        'key': '', 'unit': measure['unit'], 'direction': measure['direction'],
        'before': measure['before'], 'now': measure['now'],
        'delta': measure['delta'], 'relative': measure['relative'],
        'verdict': measure['verdict'],
        'level': measure.get('level', 'unrated'),
        'target': measure.get('target'),
    }


def arrow_html(measure, informational=False):
    before, now = measure.get('before'), measure.get('now')
    if before is None or now is None:
        return ''
    delta = now - before
    if informational:
        if not before:
            return ''
        relative = 100.0 * delta / abs(before)
        if abs(relative) < 1.0:
            return '<span class="arw flat">=</span>'
        mark = '↑' if delta > 0 else '↓'
        return f'<span class="arw info">{mark}\u202f{abs(relative):.0f}\u202f%</span>'
    kpi = as_kpi(measure)
    mark = arrow_mark(kpi)
    if not mark:
        return '<span class="arw flat">=</span>'
    return (f'<span class="arw {measure["verdict"]}">{mark}\u202f'
            f'{fmt_delta(kpi)}</span>')


def star(fill):
    if fill >= 0.995:
        return f'<span style="color:{STAR_COLOUR}">{STAR_FULL}</span>'
    if fill <= 0.005:
        return f'<span style="color:{STAR_COLOUR}">{STAR_EMPTY}</span>'
    stop = fill * 100.0
    return (f'<span style="color:{STAR_PALE};'
            f'background:linear-gradient(90deg,{STAR_COLOUR} 0 {stop:.1f}%,'
            f'{STAR_PALE} {stop:.1f}% 100%);'
            f'-webkit-background-clip:text;background-clip:text;'
            f'-webkit-text-fill-color:transparent">{STAR_FULL}</span>')


def stars(rating, out_of=5):
    if rating is None:
        return ''
    glyphs = ''.join(star(max(0.0, min(1.0, rating - idx))) for idx in range(out_of))
    return f'<div class="stars">{glyphs}</div>'


def volumes_top_html(data, by_key):
    calls = (data.get('headline') or {}).get('calls') or {}
    call_rows = []
    for key, label in (('Conf', 'Meetings'), ('P2P', '1:1 calls')):
        measure = calls.get(key)
        if not measure:
            continue
        call_rows.append(
            f'<tr><td class="lab">{esc(label)}</td>'
            f'<td class="r"><span class="big">{n(measure["now"])}</span></td>'
            f'<td class="arrcell">{arrow_html(measure, informational=True)}</td></tr>'
        )
    calls_box = ('<div class="boxhead">Calls <span>vs W-1</span></div>'
                 f'<table class="vol calls">{"".join(call_rows)}</table>')

    fb = by_key.get('feedback.rating')
    if not fb or fb['now'] is None:
        fb_box = ('<div class="boxhead">User feedback</div>'
                  '<p class="norate">No user rating returned for this week.</p>')
    else:
        change, arrow = fmt_delta(fb), arrow_mark(fb)
        mark = (f'<span class="arw {fb["verdict"]}">{arrow}\u202f{change}</span>'
                if arrow and change else '<span class="arw flat">=</span>')
        fb_box = (
            '<div class="boxhead">User feedback <span>Rate My Call</span></div>'
            f'<div class="rate"><span class="score">{fmt_value(fb, fb["now"])}</span>'
            f'{mark}</div>{stars(fb["now"])}'
            f'<div class="rnote">{esc(counts_phrase(fb))}</div>'
        )

    return f'<tr><td class="box">{calls_box}</td><td class="gap"></td><td class="box">{fb_box}</td></tr>'


def _subnet_delta_html(item):
    if item.get('before_psr') is None or item.get('delta') is None:
        return '<span class="arw flat">new</span>'
    kpi = {
        'unit': 'percent', 'direction': 'lower',
        'before': item['before_psr'], 'now': item['psr'],
        'delta': item['delta'], 'relative': item.get('relative'),
        'verdict': item.get('verdict', 'stable'),
    }
    mark = arrow_mark(kpi)
    if not mark:
        return '<span class="arw flat">=</span>'
    return f'<span class="arw {item["verdict"]}">{mark}\u202f{fmt_delta(kpi)}</span>'


def volumes_bottom_html(data):
    """Media streams on the left + Worst Audio Subnets & Second Network Name on the right."""
    modalities = (data.get('headline') or {}).get('modalities') or {}
    stream_rows = []
    for key in ('Audio', 'Video', 'VBSS'):
        mod = modalities.get(key)
        if not mod:
            continue
        st = mod['streams']
        stream_rows.append(
            f'<tr><td style="color:#57606a;">{esc(mod["label"])}</td>'
            f'<td class="vr"><b>{n(st["now"])}</b>{arrow_html(st, informational=True)}</td></tr>'
        )
    left_html = ('<div class="boxhead">Media streams <span>vs W-1</span></div>'
                 f'<table class="vlist">{"".join(stream_rows)}</table>')

    top_subnets = ((data.get('audio_subnets') or {}).get('top_usage')) or []
    if not top_subnets:
        right_body = '<p class="norate" style="margin:4px 0 0;">No active subnet reported poor audio streams this week.</p>'
    else:
        sub_rows = []
        for item in top_subnets:
            lvl = item.get('level', 'good')
            bg = LEVEL_BG.get(lvl, 'bg-na')
            ico = LEVEL_ICON.get(lvl, '·')
            net_label = (item.get('network_name')
                         or item.get('building')
                         or ('Unmapped RFC1918' if item.get('unmapped_rfc1918') else 'Unmapped network'))
            sub_rows.append(
                '<tr>'
                f'<td><span class="sub-mini-ip">{esc(item["subnet"])}</span>'
                f'<span class="sub-mini-net">· {esc(net_label)}</span></td>'
                f'<td class="vr"><span class="mini-pill {bg}">{ico} {item["psr"]:.2f} %</span>'
                f'{_subnet_delta_html(item)}</td>'
                '</tr>'
            )
        right_body = f'<table class="vlist">{"".join(sub_rows)}</table>'

    right_html = (
        '<div class="boxhead">Subnets in distress · Second Network Name '
        '<span>Audio Poor % vs W-1</span></div>'
        + right_body
    )
    return f'<tr><td class="vcell-left">{left_html}</td><td class="vcell-right">{right_html}</td></tr>'


def week_in_short_html(data, narrative):
    """High-visibility executive summary banner designed for management forwarding."""
    clean_narrative, dropped = sound_analysis(data, narrative)
    analysis = clean_narrative.get('analysis') or {}
    bad = [str(t).strip() for t in (analysis.get('negative') or []) if str(t).strip()]
    good = [str(t).strip() for t in (analysis.get('positive') or []) if str(t).strip()]

    kpis = data.get('kpis') or []
    poor_kpis = [k for k in kpis if k.get('level') == 'poor']
    watch_kpis = [k for k in kpis if k.get('level') == 'watch']

    if poor_kpis:
        pill_cls = 'exec-status-poor'
        pill_txt = (f'■ Action Required · {len(poor_kpis)} Critical'
                    + (f', {len(watch_kpis)} Watch' if watch_kpis else ''))
    elif watch_kpis:
        pill_cls = 'exec-status-watch'
        pill_txt = f'▲ Watch · {len(watch_kpis)} Indicator{"s" if len(watch_kpis) > 1 else ""} Above Target'
    else:
        pill_cls = 'exec-status-good'
        pill_txt = '● Healthy · All Targets Met'

    rows = []
    for text in bad:
        tag_cls = 'tag-risk' if poor_kpis else 'tag-watch'
        tag_lbl = 'Action' if poor_kpis else 'Watch'
        rows.append(
            f'<tr><td class="ei-tag"><span class="{tag_cls}">{tag_lbl}</span></td>'
            f'<td class="ei-txt">{esc(text)}</td></tr>'
        )
    for text in good:
        rows.append(
            '<tr><td class="ei-tag"><span class="tag-good">Positive</span></td>'
            f'<td class="ei-txt">{esc(text)}</td></tr>'
        )

    if dropped:
        rows.append(
            '<tr><td class="ei-tag"><span class="tag-watch">Audit</span></td>'
            f'<td class="ei-txt">{len(dropped)} written finding'
            f'{"s were" if len(dropped) > 1 else " was"} omitted because '
            'quoted counts did not match the named indicator.</td></tr>'
        )

    if not rows:
        attention = [label_of(k) for k in kpis if k.get('attention')]
        if attention:
            rows.append(
                '<tr><td class="ei-tag"><span class="tag-watch">Watch</span></td>'
                f'<td class="ei-txt">Indicators requiring management review this week: '
                f'<b>{esc(", ".join(attention))}</b>.</td></tr>'
            )
        else:
            rows.append(
                '<tr><td class="ei-tag"><span class="tag-good">Healthy</span></td>'
                '<td class="ei-txt">All measured Teams quality and reliability indicators '
                'sit within published Microsoft targets this week, with no material degradation '
                'against the prior week.</td></tr>'
            )

    return (
        '<table class="exec-box">'
        '<tr>'
        '<td class="exec-hdr">✦ The week in short — Executive Briefing</td>'
        f'<td class="exec-hdr-right"><span class="exec-status-pill {pill_cls}">{esc(pill_txt)}</span></td>'
        '</tr>'
        f'<tr><td colspan="2" class="exec-body"><table class="exec-items">{"".join(rows)}</table></td></tr>'
        '</table>'
    )


def _gauge_needle(value, good_limit, poor_limit, max_scale):
    """Map `value` piecewise onto the 3 equal 60-degree arcs (180° left to 0° right).

    Green zone [0..good_limit]      -> 180° .. 120°
    Amber zone [good_limit..poor]   -> 120° .. 60°
    Red zone   [poor_limit..max]    ->  60° .. 0°
    """
    if value is None:
        deg = 180.0
    elif value <= 0:
        deg = 176.0
    elif value < good_limit:
        frac = value / good_limit if good_limit else 0.0
        deg = 180.0 - 60.0 * frac
    elif value <= poor_limit:
        span = (poor_limit - good_limit) or 1.0
        frac = (value - good_limit) / span
        deg = 120.0 - 60.0 * frac
    else:
        span = (max_scale - poor_limit) or 1.0
        frac = min(1.0, (value - poor_limit) / span)
        deg = max(6.0, 60.0 - 60.0 * frac)

    rad = math.radians(deg)
    cx, cy, length = 60.0, 58.0, 41.0
    nx = cx + length * math.cos(rad)
    ny = cy - length * math.sin(rad)
    pct = max(3.0, min(97.0, (180.0 - deg) / 180.0 * 100.0))
    return nx, ny, pct


def gauges_html(by_key):
    specs = [
        ('psr.audio', 'Poor Audio Rate', 'Target < 2%', 2.0, 5.0, 10.0),
        ('psr.video', 'Poor Video Rate', 'Target < 2%', 2.0, 5.0, 10.0),
        ('psr.vbss', 'Poor Sharing Rate', 'Target < 2%', 2.0, 5.0, 10.0),
        ('drop', 'Drop Failure Rate', 'Target < 2%', 2.0, 5.0, 10.0),
        ('setup', 'Setup Failure Rate', 'Target < 1%', 1.0, 3.0, 5.0),
        ('feedback.poor', 'Poor Feedback (1★)', 'Target < 5%', 2.0, 5.0, 15.0),
    ]
    cells = []
    for key, title, target_lbl, good_lim, poor_lim, max_scale in specs:
        kpi = by_key.get(key) or {'now': None, 'before': None, 'delta': None,
                                  'relative': None, 'unit': 'percent',
                                  'direction': 'lower', 'verdict': 'unknown',
                                  'level': 'unrated', 'counts': None}
        val = kpi['now']
        lvl = kpi.get('level', 'unrated')
        card_cls = 'g-card g-poor' if lvl == 'poor' else ('g-card g-watch' if lvl == 'watch' else 'g-card')
        val_color = '#b31d14' if lvl == 'poor' else ('#9a5b00' if lvl == 'watch' else '#15191e')
        nx, ny, pct = _gauge_needle(val, good_lim, poor_lim, max_scale)

        change, arrow = fmt_delta(kpi), arrow_mark(kpi)
        if arrow and change:
            delta_part = f'<span class="arw {kpi["verdict"]}" style="margin:0;">{arrow}\u202f{change}</span>'
        elif val is not None:
            delta_part = '<span class="arw flat" style="margin:0;">= steady</span>'
        else:
            delta_part = '<span class="arw flat" style="margin:0;">not measured</span>'

        cnt = ((kpi.get('counts') or {}).get('now') or {}).get('n')
        cnt_part = f' · {n(cnt)} poor' if cnt is not None else ''

        mso_bar = (
            '<!--[if mso]>'
            '<table width="100%" cellpadding="0" cellspacing="0" style="margin:6px 0 8px;"><tr>'
            '<td width="33%" height="8" bgcolor="#1e821e" style="font-size:0;line-height:0;">&nbsp;</td>'
            '<td width="34%" height="8" bgcolor="#ffc000" style="font-size:0;line-height:0;">&nbsp;</td>'
            '<td width="33%" height="8" bgcolor="#d83b01" style="font-size:0;line-height:0;">&nbsp;</td>'
            '</tr></table>'
            '<![endif]-->'
        )
        svg = (
            '<!--[if !mso]><!-->'
            '<svg class="g-svg" viewBox="0 0 120 68">'
            '<path d="M 14 58 A 46 46 0 0 1 37 18" fill="none" stroke="#1e821e" stroke-width="14"/>'
            '<path d="M 37 18 A 46 46 0 0 1 83 18" fill="none" stroke="#ffc000" stroke-width="14"/>'
            '<path d="M 83 18 A 46 46 0 0 1 106 58" fill="none" stroke="#d83b01" stroke-width="14"/>'
            f'<line x1="60" y1="58" x2="{nx:.1f}" y2="{ny:.1f}" stroke="#424a53" stroke-width="2.6" stroke-linecap="round"/>'
            '<circle cx="60" cy="58" r="6" fill="#2f353c"/>'
            '<circle cx="60" cy="58" r="3" fill="#ffffff"/>'
            '</svg>'
            '<!--<![endif]-->'
        )
        cells.append(
            f'<td class="{card_cls}" data-gauge-pct="{pct:.0f}">'
            f'<div class="g-title">{esc(title)}<br>'
            f'<span style="font-weight:400;color:#8a9099;">({esc(target_lbl)})</span></div>'
            f'{mso_bar}{svg}'
            f'<div class="g-val" style="color:{val_color};">{fmt_value(kpi, val)}</div>'
            f'<div class="g-sub">{delta_part}{cnt_part}</div>'
            '</td>'
        )
    return f'<tr>{"".join(cells)}</tr>'


def _pill_cell(measure):
    if not measure or measure.get('now') is None:
        return ('<td><div class="qer-pill bg-na"><span class="ico">·</span>—'
                '<small>not measured</small></div></td>')
    lvl = measure.get('level', 'good')
    bg = LEVEL_BG.get(lvl, 'bg-good')
    ico = LEVEL_ICON.get(lvl, '●')
    kpi = as_kpi(measure)
    change, arrow = fmt_delta(kpi), arrow_mark(kpi)
    if arrow and change:
        sub = f'{arrow}\u202f{change} vs W-1'
    elif lvl == 'good':
        sub = 'within 2% target'
    elif lvl == 'watch':
        sub = 'above 2% target'
    else:
        sub = 'critical (> 5%)'
    return (
        f'<td><div class="qer-pill {bg}">'
        f'<span class="ico">{ico}</span>{fmt_value(kpi, measure["now"])}'
        f'<small>{esc(sub)}</small></div></td>'
    )


def media_details_html(data):
    """Three row-aligned modality tables: Inbound and Outbound each have their own `<tr>`."""
    modalities = (data.get('headline') or {}).get('modalities') or {}
    configs = [
        ('Audio', 'Audio Health Details — Meetings & Calls', '#4e5ac0'),
        ('Video', 'Video Health Details — Meetings & Calls', '#3b4990'),
        ('VBSS', 'Screen Sharing (VBSS) Health Details — Meetings & Calls', '#5c4b8b'),
    ]
    blocks = []
    for key, title, hdr_bg in configs:
        mod = modalities.get(key) or {}
        st = mod.get('streams') or {'now': None, 'before': None}
        in_way = mod.get('inbound') or {}
        out_way = mod.get('outbound') or {}

        in_lvl = (in_way.get('overall') or {}).get('level', 'good')
        out_lvl = (out_way.get('overall') or {}).get('level', 'good')
        worst_lvl = ('poor' if 'poor' in (in_lvl, out_lvl)
                     else 'watch' if 'watch' in (in_lvl, out_lvl) else 'good')
        border_style = (' style="border-color:#e03e2d;"' if worst_lvl == 'poor'
                        else ' style="border-color:#e5a93c;"' if worst_lvl == 'watch' else '')
        hdr_note = ('Target: below 2.00% · ■ Critical threshold exceeded' if worst_lvl == 'poor'
                    else 'Target: below 2.00% · ▲ Watch on Outbound' if out_lvl == 'watch'
                    else 'Target: below 2.00% poor streams')

        in_counts = ((in_way.get('overall') or {}).get('counts') or {}).get('now') or {}
        out_counts = ((out_way.get('overall') or {}).get('counts') or {}).get('now') or {}

        in_poor_str = (f'{n(in_counts.get("n"))} <span style="font-weight:400;font-size:11px;color:#6e7781;">'
                       f'/ {n(in_counts.get("d"))}</span>'
                       if in_counts.get('n') is not None else '—')
        out_poor_str = (f'{n(out_counts.get("n"))} <span style="font-weight:400;font-size:11px;color:#6e7781;">'
                        f'/ {n(out_counts.get("d"))}</span>'
                        if out_counts.get('n') is not None else '—')

        in_dir_cls = 'dir-badge dir-poor' if in_lvl == 'poor' else ('dir-badge dir-watch' if in_lvl == 'watch' else 'dir-badge')
        out_dir_cls = 'dir-badge dir-poor' if out_lvl == 'poor' else ('dir-badge dir-watch' if out_lvl == 'watch' else 'dir-badge')

        prev_st_note = (f'was {n(st["before"])} ({arrow_html(st, informational=True)})'
                        if st.get('before') is not None else '')

        blocks.append(
            f'<div class="mod-block"{border_style}>'
            f'<div class="mod-header" style="background:{hdr_bg};">'
            f'{esc(title)}<span>{esc(hdr_note)}</span></div>'
            '<table class="mod-grid">'
            '<colgroup>'
            '<col style="width:16%"><col style="width:15%"><col style="width:13%">'
            '<col style="width:18.6%"><col style="width:18.6%"><col style="width:18.8%">'
            '</colgroup>'
            # Row 1: Column headers + Total Streams spanning all 3 rows
            '<tr>'
            '<td rowspan="3" class="m-tot-cell">'
            f'<div class="m-tot-label">Total {esc(mod.get("label", key))} Streams</div>'
            f'<div class="m-tot-val">{n(st.get("now"))}</div>'
            f'<div style="font-size:10.5px;color:#6e7781;margin-top:4px;">{prev_st_note}</div>'
            '</td>'
            '<th class="m-col-hdr">Poor Streams</th>'
            '<th class="m-col-hdr">Direction</th>'
            '<th class="m-col-hdr">Overall (%)</th>'
            '<th class="m-col-hdr">Wired (%)</th>'
            '<th class="m-col-hdr">Wifi (%)</th>'
            '</tr>'
            # Row 2: Strictly aligned Inbound row
            '<tr class="m-row-in">'
            '<td class="m-poor-cell">'
            '<span class="m-poor-lbl">Poor Inbound</span>'
            f'<span class="m-poor-num">{in_poor_str}</span>'
            '</td>'
            f'<td><div class="{in_dir_cls}">⬇ Inbound</div></td>'
            f'{_pill_cell(in_way.get("overall"))}'
            f'{_pill_cell(in_way.get("wired"))}'
            f'{_pill_cell(in_way.get("wifi"))}'
            '</tr>'
            # Row 3: Strictly aligned Outbound row
            '<tr class="m-row-out">'
            '<td class="m-poor-cell">'
            '<span class="m-poor-lbl">Poor Outbound</span>'
            f'<span class="m-poor-num">{out_poor_str}</span>'
            '</td>'
            f'<td><div class="{out_dir_cls}">⬆ Outbound</div></td>'
            f'{_pill_cell(out_way.get("overall"))}'
            f'{_pill_cell(out_way.get("wired"))}'
            f'{_pill_cell(out_way.get("wifi"))}'
            '</tr>'
            '</table>'
            '</div>'
        )
    return ''.join(blocks)


def _tile_card(kpi, title, help_line, target_bold, compact=False, dark_when_good=False,
               sub_override=None):
    if not kpi or kpi.get('now') is None:
        cls = 'qer-tile-lg compact bg-na' if compact else 'qer-tile-lg bg-na'
        return (
            f'<td><div class="it-lbl">{esc(title)}</div>'
            f'<div class="{cls}"><div class="val">· —</div>'
            '<div class="sub">not measured</div></div>'
            f'<div class="it-help">{esc(help_line)}<br><b>{esc(target_bold)}</b></div></td>'
        )
    lvl = kpi.get('level', 'good')
    if lvl == 'good' and dark_when_good:
        bg = 'bg-good-dark'
    else:
        bg = LEVEL_BG.get(lvl, 'bg-good')
    ico = LEVEL_ICON.get(lvl, '●')
    size_cls = 'qer-tile-lg compact' if compact else 'qer-tile-lg'

    if sub_override is not None:
        sub = sub_override
    else:
        change, arrow = fmt_delta(kpi), arrow_mark(kpi)
        if kpi.get('unit') == 'ms' and kpi.get('delta') is not None:
            sign = '+' if kpi['delta'] >= 0 else '−'
            change = f"{sign}{abs(kpi['delta']):.0f} ms"
        if arrow and change:
            if compact:
                sub = f'{arrow}\u202f{change} vs W-1'
            else:
                prev_txt = fmt_value(kpi, kpi['before']).replace(' %', '%').replace(' / 5', '')
                sub = f'{arrow}\u202f{change} (was {prev_txt})'
        else:
            sub = '= steady'

    return (
        f'<td><div class="it-lbl">{esc(title)}</div>'
        f'<div class="{size_cls} {bg}">'
        f'<div class="val"><span class="ico">{ico}</span>{fmt_value(kpi, kpi["now"])}</div>'
        f'<div class="sub">{esc(sub)}</div>'
        '</div>'
        f'<div class="it-help">{esc(help_line)}<br><b>{esc(target_bold)}</b></div></td>'
    )


def _feedback_reasons_html(fb_reasons):
    items = (fb_reasons or {}).get('items') or []
    title = (fb_reasons or {}).get('title') or 'Reasons for Poor Feedback'
    total = (fb_reasons or {}).get('total_mentions') or 0
    header = (f'<div class="it-lbl" style="text-align:left;margin-bottom:6px;">'
              f'{esc(title)}'
              + (f' <span style="font-weight:400;color:#8a9099;">({n(total)})</span>'
                 if total else '')
              + '</div>')
    if not items:
        why = (fb_reasons or {}).get('reason') or 'No poor-feedback reasons reported.'
        return header + f'<p class="norate" style="font-size:11.5px;margin:6px 0 0;">{esc(why)}</p>'

    max_share = max((it['share'] for it in items), default=100.0) or 100.0
    rows = []
    for it in items:
        fill_pct = max(6.0, min(100.0, 100.0 * it['share'] / max_share))
        rest_pct = max(0.0, 100.0 - fill_pct)
        bar_cells = f'<td style="width:{fill_pct:.0f}%;background:#4e5ac0;"></td>'
        if rest_pct > 0.5:
            bar_cells += f'<td style="width:{rest_pct:.0f}%;background:#eaeef2;"></td>'
        rows.append(
            '<tr>'
            f'<td class="fb-lbl">{esc(it["label"])}</td>'
            f'<td class="fb-bar-cell"><table class="fb-bar"><tr>{bar_cells}</tr></table></td>'
            f'<td class="fb-cnt">{n(it["count"])} '
            f'<span style="font-weight:400;color:#6e7781;">({it["share"]:.0f}%)</span></td>'
            '</tr>'
        )
    return header + f'<table class="fb-reasons">{"".join(rows)}</table>'


def thematic_blocks_html(by_key, fb_reasons):
    drop = by_key.get('drop')
    setup = by_key.get('setup')
    fb_score = by_key.get('feedback.rating')
    fb_poor = by_key.get('feedback.poor')
    rtt = by_key.get('net.rtt')
    jitter = by_key.get('net.jitter')
    loss = by_key.get('net.loss')
    tcp = by_key.get('transport.tcp')
    clf_in = by_key.get('clf.inbound')
    clf_out = by_key.get('clf.uplink')
    clients = by_key.get('clients.current')
    vdi = by_key.get('vdi.optimized')

    def _pair_help(kpi, fallback):
        c = ((kpi or {}).get('counts') or {}).get('now')
        if c and c.get('n') is not None and c.get('d'):
            return f"{n(c['n'])} of {n(c['d'])}"
        if c and c.get('d'):
            return f"{n(c['d'])} {kpi['counts']['noun']}"
        return fallback

    vdi_sub = (f"VDI: {vdi['now']:.0f}% opt."
               if vdi and vdi.get('now') is not None else None)

    row1 = (
        '<table class="theme-row"><tr>'
        '<td class="theme-card" style="width:40%;">'
        '<div class="theme-title">Audio &amp; Call Reliability'
        '<span>Calls cut mid-conversation vs calls failing to connect</span></div>'
        '<table class="inner-tiles"><tr>'
        + _tile_card(drop, 'Drop Rate (%)', _pair_help(drop, 'Established streams'), 'Target: below 2%')
        + _tile_card(setup, 'Setup Failure Rate (%)', _pair_help(setup, 'CDR streams'), 'Target: below 1%', dark_when_good=True)
        + '</tr></table></td>'
        '<td class="theme-card" style="width:60%;">'
        '<div class="theme-title">User Experience &amp; Top Reasons for Poor Feedback'
        '<span>Rate My Call score, 1-star share (red above 5%) &amp; reported causes</span></div>'
        '<table style="width:100%;border-collapse:collapse;"><tr>'
        '<td style="width:46%;vertical-align:top;padding-right:12px;border-right:1px solid #eef0f2;">'
        '<table class="inner-tiles"><tr>'
        + _tile_card(fb_score, 'Feedback Score', _pair_help(fb_score, 'Ratings'), 'Target > 4.0', compact=True, dark_when_good=True)
        + _tile_card(fb_poor, 'One-Star (%)', _pair_help(fb_poor, '1★ ratings'), 'Target < 5%', compact=True)
        + '</tr></table></td>'
        '<td style="width:54%;vertical-align:top;padding-left:12px;">'
        + _feedback_reasons_html(fb_reasons)
        + '</td></tr></table></td>'
        '</tr></table>'
    )

    row2 = (
        '<table class="theme-row"><tr>'
        '<td class="theme-card" style="width:58%;">'
        '<div class="theme-title">Network &amp; Transport Health (Wi-Fi Meetings &amp; UDP Media)'
        '<span>Network round-trip delay, jitter, packet loss &amp; firewall UDP fallback</span></div>'
        '<table class="inner-tiles"><tr>'
        + _tile_card(rtt, 'Latency (RTT)', 'Round-trip time', 'Target < 100 ms', compact=True)
        + _tile_card(jitter, 'Jitter', 'Packet delay variation', 'Target < 30 ms', compact=True)
        + _tile_card(loss, 'Packet Loss', 'Wi-Fi audio loss', 'Target < 1.00%', compact=True)
        + _tile_card(tcp, 'TCP Fallback (%)', _pair_help(tcp, 'Streams off UDP'), 'Target < 2.00%', compact=True)
        + '</tr></table></td>'
        '<td class="theme-card" style="width:42%;">'
        '<div class="theme-title">Network Classifiers &amp; Endpoints'
        '<span>Share of meetings with network issues &amp; client estate</span></div>'
        '<table class="inner-tiles"><tr>'
        + _tile_card(clf_in, 'Inbound Issues', 'Download classifier', 'Target < 5%', compact=True,
                     sub_override=_pair_help(clf_in, 'Meetings'))
        + _tile_card(clf_out, 'Outbound Issues', 'Uplink classifier', 'Target < 5%', compact=True,
                     sub_override=_pair_help(clf_out, 'Meetings'))
        + _tile_card(clients, 'Clients Current', _pair_help(clients, 'Teams 2.1'), 'Target > 90%', compact=True,
                     dark_when_good=True, sub_override=vdi_sub)
        + '</tr></table></td>'
        '</tr></table>'
    )
    return row1 + row2


def subnets_section_html(data):
    subnet_data = data.get('audio_subnets') or {}
    rows_data = subnet_data.get('detailed') or []
    min_st = subnet_data.get('min_streams') or 5

    heading = (
        f'<h2>Subnets in Distress — Top Audio Subnets by Poor Rate '
        f'<span>Active subnets (&ge; {min_st} audio streams) · Second Network Name &amp; W-1 delta</span></h2>'
    )
    if not rows_data:
        return (
            heading
            + '<div class="subnet-card"><div class="subnet-hdr">'
            'Worst Audio Subnets Requiring Investigation'
            '<span>Target: below 2.00%</span></div>'
            '<p style="padding:12px 14px;margin:0;font-size:12.5px;color:#57606a;">'
            'No active subnet recorded degraded audio streams during the selected week.</p></div>'
        )

    body_rows = []
    for item in rows_data:
        lvl = item.get('level', 'good')
        bg = LEVEL_BG.get(lvl, 'bg-good')
        ico = LEVEL_ICON.get(lvl, '●')
        net_name = item.get('network_name') or '—'
        bldg = item.get('building')
        if item.get('mapped'):
            bldg_html = (f'<span class="sub-site">{esc(bldg or "Mapped site")}</span>'
                         '<span class="sub-tag mapped">Inside</span>')
        elif item.get('unmapped_rfc1918'):
            bldg_html = ('<span class="sub-site">Unmapped RFC1918</span>'
                         '<span class="sub-tag unmapped">Missing in Building File</span>')
        else:
            bldg_html = '<span class="sub-site">Outside / External</span>'

        body_rows.append(
            '<tr>'
            f'<td class="sub-ip">{esc(item["subnet"])}</td>'
            f'<td class="sub-net">{esc(net_name)}</td>'
            f'<td>{bldg_html}</td>'
            f'<td class="c"><span class="conn-pill">{esc(item.get("connection") or "All")}</span></td>'
            f'<td class="r">{n(item["streams"])}</td>'
            f'<td class="r"><b>{n(item["poor"])}</b></td>'
            f'<td class="c"><span class="qer-badge {bg}">{ico} {item["psr"]:.2f} %</span></td>'
            f'<td class="r">{_subnet_delta_html(item)}</td>'
            '</tr>'
        )

    return (
        heading
        + '<div class="subnet-card">'
        '<div class="subnet-hdr">Worst Audio Subnets Requiring Investigation'
        '<span>Target: below 2.00% · Watch: 2–5% · Poor: above 5%</span></div>'
        '<table class="subnets"><thead><tr>'
        '<th style="width:14%;">Subnet</th>'
        '<th style="width:20%;">Second Network Name</th>'
        '<th style="width:21%;">Building / Scope</th>'
        '<th class="c" style="width:9%;">Access</th>'
        '<th class="r" style="width:10%;">Audio</th>'
        '<th class="r" style="width:7%;">Poor</th>'
        '<th class="c" style="width:11%;">Audio PSR</th>'
        '<th class="r" style="width:8%;">vs W-1</th>'
        '</tr></thead>'
        f'<tbody>{"".join(body_rows)}</tbody></table></div>'
    )


def build(data, narrative, scope=None):
    template_path = next((p for p in TEMPLATE_CANDIDATES if p.is_file()), None)
    if template_path is None:
        raise SystemExit('weekly-note-template.html not found beside this script')

    by_key = {k['key']: k for k in (data.get('kpis') or [])}
    periods = data['periods']
    title = resolve_title(scope, data)

    unmapped = (data.get('context') or {}).get('unmapped') or {}
    footnote = (
        'Every figure comes from an executed Call Quality Dashboard weekly query; '
        'nothing is estimated. Inbound measures streams arriving at the reported '
        'endpoint and Outbound those leaving it; an elevated Outbound poor rate on '
        'Screen Sharing typically indicates constrained sender upload bandwidth rather '
        'than a service-wide incident.'
    )
    if unmapped.get('subnets'):
        footnote += (f" {fmt_count(unmapped['streams'])} streams came from "
                     f"{unmapped['subnets']} private subnets absent from the Building File.")

    html = (
        template_path.read_text(encoding='utf-8')
        .replace('{{TITLE}}', esc(title))
        .replace('{{WEEK}}', esc(period_label(periods['current'])))
        .replace('{{WEEK_PREV}}', esc(period_label(periods['previous'])))
        .replace('{{VOLUMES_TOP}}', volumes_top_html(data, by_key))
        .replace('{{VOLUMES_BOTTOM}}', volumes_bottom_html(data))
        .replace('{{WEEK_IN_SHORT}}', week_in_short_html(data, narrative))
        .replace('{{GAUGES}}', gauges_html(by_key))
        .replace('{{MEDIA_DETAILS}}', media_details_html(data))
        .replace('{{THEMATIC_BLOCKS}}', thematic_blocks_html(by_key, data.get('feedback_reasons')))
        .replace('{{SUBNETS_SECTION}}', subnets_section_html(data))
        .replace('{{FOOTNOTE}}', esc(footnote))
        .replace('{{GENERATED}}', datetime.now(timezone.utc).strftime('%d/%m/%Y %H:%M UTC'))
    )
    kpis = data.get('kpis') or []
    return html, {'total': len(kpis), 'moved': sum(1 for k in kpis if moved(k))}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--kpis', type=Path, default=Path('weekly-kpis.json'))
    parser.add_argument('--narrative', type=Path, default=Path('narrative.json'))
    parser.add_argument('--out', type=Path, default=Path('weekly-note.html'))
    parser.add_argument('--scope', default=None,
                        help='Scope or subsidiary label shown in "Teams Media <SCOPE>" (e.g. SEO).')
    parser.add_argument('--customer', default=None,
                        help='Alias for --scope if --scope is omitted.')
    args = parser.parse_args(argv)

    if not args.kpis.is_file():
        raise SystemExit(f"weekly-kpis.json not found: {args.kpis}. Run assemble_weekly_kpis.py first.")
    data = json.loads(args.kpis.read_text(encoding='utf-8'))
    narrative = (json.loads(args.narrative.read_text(encoding='utf-8'))
                 if args.narrative.is_file() else {})

    if data.get('missing_queries'):
        print("Refusing to render: the weekly run is missing "
              + ", ".join(data['missing_queries']))
        return 2

    chosen_scope = args.scope if args.scope is not None else args.customer
    html, counts = build(data, narrative, chosen_scope)
    args.out.write_text(html, encoding='utf-8')
    print(f"-> {args.out}  ({len(html) // 1024} KB, {counts['total']} indicators, "
          f"{counts['moved']} moved)")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
