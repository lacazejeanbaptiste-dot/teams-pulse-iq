---
name: pulse-weekly
description: "Run the weekly executive Teams quality analysis for a tenant or subsidiary scope (e.g. SEO) and mail it, from a Power BI CQD semantic model, using Microsoft 365 Copilot Cowork with native Fabric IQ. Produces a visual QER-style HTML mail body (Teams Media <SCOPE>) and attaches the detailed week-over-week report.html. Triggers on: run the weekly Teams analysis, weekly Teams report, lance l'analyse weekly, rapport hebdomadaire Teams, Teams Media weekly, pulse-weekly."
---

# Teams Pulse IQ — Weekly Executive Analysis

One weekly run from a single CQD collection (`weekly-raw.json`), producing two
deliverables sent together in one Outlook message:

| Output | Role | What it contains |
|---|---|---|
| `weekly-note.html` | **Rich HTML email body** | `Teams Media <SCOPE>`, Volumes + Audio Subnets Watchlist (`Second Network Name` vs W−1), executive `The week in short`, 6 headline gauges, row-aligned Audio/Video/Sharing Inbound vs Outbound across Overall/Wired/Wifi, Poor Feedback reasons, and detailed Subnets in Distress |
| `report.html` | **Email attachment** | Validated 12-tab interactive week S vs week S−1 deep-dive report |

**Absolute rule — no invented data.** Every figure in both outputs comes from an
executed query in [weekly-register.md](weekly-register.md). If a query returns
nothing, or a column does not exist in the model, leave the slot empty with its
reason. Never scale, split, interpolate, infer or carry a value across weeks,
cohorts, media or scenarios. An unmeasured slot is a gap, never a zero and never
a green status.

**Do not write your own DAX.** Read [cowork-constraints.md](cowork-constraints.md),
[contract.md](contract.md), [dashboard-collection.json](dashboard-collection.json),
and [weekly-reference.md](weekly-reference.md).

## Run it on a bare instruction

“Run the weekly Teams analysis for SEO” or “Lance l'analyse weekly pour SEO en
filtrant sur Second Building Name contient SEO et envoie le mail à …” is a
complete instruction. Work through every step to the end, in order, **without
asking anything**:

| Question | Settled answer |
|---|---|
| Which weeks? | Last fully completed Monday–Sunday UTC week (**S**) vs the week immediately before it (**S−1**) |
| Which model? | The CQD semantic model named in the prompt, or the single visible model carrying a `CQD` table |
| Which `<SCOPE>` title? | The entity/subsidiary label given in the prompt (e.g. `SEO` → `Teams Media SEO`), or blank (`Teams Media`) |
| Which language? | **English** in every rendered output and narrative, whatever language the prompt used |
| Send the mail? | Yes, to the recipients named in the prompt, without asking (step 6) |

Stop and ask in only **one** case: multiple distinct CQD semantic models are
visible and the prompt does not identify which one to query.

**Run everything yourself in the primary thread. Do not delegate to a sub-agent,
a background task or a worker fleet:**
- A sub-agent may not share this filesystem (`build_dashboard.py` reads
  `dashboard-data.json` from the current working directory).
- You cannot verify what you did not collect yourself.
- Parallelism does not help: programmatic `RunScript` execution directly to disk
  is already fast and compact.

## 1. Resolve the model, the `<SCOPE>` variable, any filter, and the two weeks

1. **Semantic model**: discover the Power BI semantic model containing table
   `CQD` via native Fabric IQ discovery (or use the exact model named by the user).
2. **`<SCOPE>` label and optional DAX population filter**:
   - Extract the scope/entity name from the prompt if one is mentioned (for
     example `"lance l'analyse weekly pour SEO"` → `SCOPE = "SEO"`). This drives
     the header **`Teams Media SEO`** and the email subject.
   - If the prompt asks to narrow the model to a subset (for example filtering
     where `Second Building Name` contains `"SEO"` or starts with `"SEO"`),
     translate ONLY that predicate into a clean DAX `FILTER(VALUES(...), ...)`
     expression — for example:
     `FILTER(VALUES(CQD[Second Building Name]), CONTAINSSTRING(CQD[Second Building Name], "SEO"))`
     Store this exact string as `scope_filter` so every query in the register
     receives the exact same filter.
3. **Weeks S and S−1**:
   - `End_S` is the most recent completed Sunday strictly before today UTC;
     `Start_S = End_S − 6 days` (Monday–Sunday UTC, 7 calendar days).
   - Week **S−1** is the 7 days immediately preceding `Start_S`. Never compare a
     week still in progress.

## 2. Execute the weekly register via Python `RunScript` directly to disk

[weekly-register.md](weekly-register.md) defines 40 queries (`Q1`–`Q48`).
Run each query **twice — once for Week S (`_S`), once for Week S−1 (`_S1`)** —
except `Q2` and `Q3` which use `@D14` across all 14 days once (`Q2`, `Q3`), and
`Q15` which runs for Week S only (`Q15_S`) using the top building from `Q14_S`.
That is **77 executions** (76 when no Building File is populated and `Q15_S` is
omitted).

**Mandatory — collect programmatically via `RunScript` into `weekly-raw.json`,
never by hand-copying rows through the chat context window:**

1. In Python inside `RunScript`, import `assemble_dashboard`:
   - `reg = assemble_dashboard.load_weekly_register()`
   - `dax = assemble_dashboard.expand_register_query(reg, qid, dates, focus=focus, extra_filter=scope_filter)`
   This generates the literal DAX for all 40 queries (`Q1`–`Q48`), automatically
   injecting `scope_filter` when one was requested.
2. Call Fabric IQ `ExecuteQuery` programmatically from Python (with `artifactId`,
   `daxQueries`, and an explicit integer `maxRows`), extract the returned rows,
   and save them directly to `weekly-raw.json` on disk.
3. Split the 77 executions across **2 or 3 sequential `RunScript` calls** (for
   example Batch 1 = `Q1`–`Q14` + determine `focus_site` + `Q15_S`; Batch 2 =
   `Q16`–`Q33`; Batch 3 = `Q34`–`Q48`), reloading and saving `weekly-raw.json`
   after each batch so no call approaches the 600-second script timeout.
4. **Picking `focus_site` from `Q14`**: `TOPN` does not guarantee sorted output
   and a Building File may list one building code under two country spellings
   (`"FR"` and `"France"`). Group `Q14` rows by `Second Building Name`, sum
   `[Streams]`, and select the building with the highest total for `S` and `S1`.
   If `Q14` returns no named building or `Q3` returns no Inside rows over the
   14 days, omit `focus_site` and skip `Q15_S`.
5. **Column rejected by an older custom model**: if a query fails because a
   column does not exist (for example `Second QoS Applied` in `Q22`,
   `Total Second Roaming Count` in `Q26`, `Second Feedback Tokens` in `Q47`, or
   `Second Network Name` in `Q48`), remove only that column/measure, re-run once,
   and record the modified `"dax"` (or keep `"rows": []` with the verbatim
   `"error"` when the whole query is unsupported). Never substitute a different
   column.

## 3. Write `weekly-raw.json` compactly (no indentation, no DAX echo)

Save `weekly-raw.json` in compact tabular JSON:

```json
{"scope":"SEO","customer":"SEO","report":"<source model identity>","scope_filter":"<optional DAX FILTER or omit>","periods":{"current":["2026-11-09","2026-11-15"],"previous":["2026-11-02","2026-11-08"]},"focus_site":{"S":"<top building S>","S1":"<top building S-1>"},"results":{"Q1_S":{"cols":["CQD[Session Type]","[Streams]","[Calls]"],"rows":[["Conf",504468,109486],["P2P",155766,60038]]},"Q1_S1":{"cols":["..."],"rows":[["..."]]},"Q2":{"cols":["..."],"rows":[["..."]]}}}
```

- **Column names once** (`cols` + `rows`), **no indentation**, **do not echo the
  DAX** (unless a query was modified after a column rejection).
- Paste returned values unchanged (`"24,986"`, `"4%"`, `null`); both assemblers
  parse formatted counts and percent strings deterministically.

## 4. Build the visual executive mail (`weekly-note.html`) FIRST

Always render the email body before running the heavy attachment validator, so
the weekly executive mail is safe even if an attachment check stops:

```bash
python assemble_weekly_kpis.py --raw weekly-raw.json --out weekly-kpis.json
```

Read `weekly-kpis.json`, then write **`narrative.json`** for **“The week in short”**.
This section will be forwarded directly to operations and production leadership:

```json
{"analysis": {
   "negative": ["Clear management-level risk or watch point, quoting exact measured rates and counts from weekly-kpis.json."],
   "positive": ["Clear management-level improvement or stability highlight, quoting exact measured rates and counts from weekly-kpis.json."]}}
```

Rules for `narrative.json`:
- **Write in crisp, executive English** (2 to 3 concise sentences total across
  `negative` and `positive`, focused on operational impact: e.g. whether core
  Audio/Video meet the 2% Microsoft target, whether Screen Sharing degradation is
  isolated to user uplink, which network/subnet needs attention, or how call
  drops and TCP fallback moved week over week).
- **Quote only measured figures from `weekly-kpis.json`.** `build_weekly_note.py`
  arithmetically verifies every `N of M` count pair you quote against the rate
  beside it and removes any mismatched sentence.
- **Read the counts before judging a swing** on small subsidiary scopes.

Then render `weekly-note.html`, passing `--scope "<SCOPE>"` (for example `"SEO"`
so the header displays **`Teams Media SEO`**):

```bash
python build_weekly_note.py --kpis weekly-kpis.json --narrative narrative.json \
    --scope "<SCOPE>" --out weekly-note.html
```

## 5. Assemble and validate the detailed report (`report.html`)

From the same `weekly-raw.json`, run in order:

```bash
python assemble_dashboard.py --raw weekly-raw.json --out dashboard-data.json
python build_dashboard.py
```

`build_dashboard.py` enriches, validates, and writes `report.html`. It refuses to
write `report.html` when validation fails. Never hand-edit `dashboard-data.json`
to bypass validation.

## 6. Deliver and send the mail

Hand back `weekly-note.html` and `report.html` (alongside `weekly-raw.json`,
`weekly-kpis.json`, and `narrative.json`).

**If the request names recipients, send the mail immediately without asking:**
- **Body**: `weekly-note.html` sent directly as the **rich HTML body of the
  message** — never as an attachment, never summarised, never rewritten into
  plain text.
- **Attachment**: attach `report.html` (and nothing else).
- **Subject**:
  - With a scope variable (e.g. `SEO`): `Teams Media SEO — <Start_S> → <End_S>`
  - Without a scope variable: `Teams Media — <Start_S> → <End_S>`
- **Recipients**: send to the exact addresses named in the prompt or schedule;
  never add, guess, or substitute a recipient.

Cowork gates sending behind its own consent prompt; nothing here can
pre-authorise it. If the send is left pending approval, state plainly that the
outputs exist and the mail awaits approval (*always approve* unlocks unattended
runs). If no recipient is named, hand back the files and ask in one line who
should receive the mail.

### Failure handling

- If `assemble_weekly_kpis.py` or `build_weekly_note.py` refuses because core
  queries are missing, **do not send a partial report**; send a short plain-text
  notice naming the failed queries so a broken run is never silent.
- If `weekly-note.html` succeeded but `build_dashboard.py` failed to produce
  `report.html`, append one plain warning line just above the footer of
  `weekly-note.html` naming the validation step that stopped, and send the visual
  weekly mail without the attachment; do not delay the mail while retrying.
